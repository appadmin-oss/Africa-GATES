<?php
declare(strict_types=1);
namespace AfricaGates\Controllers;
use AfricaGates\Support\Env;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Views\Twig;
use Illuminate\Database\Capsule\Manager as DB;
use AfricaGates\Services\{CacheService, AwardService, PointsService, PaidVoteService, PaymentService, RuleEngine};

class VoteController {

    /**
     * Nominee states that have a public page.
     *
     * 'approved' is the state a nominee is in only while the cycle is unfinished.
     * The moment {@see \AfricaGates\Services\CycleMaterialiser} seals the standings
     * it writes 'winner' or 'runner_up' onto the row — so filtering on 'approved'
     * alone means WINNING DELETES A NOMINEE'S PAGE, and every link shared during the
     * whole campaign breaks at the exact moment it starts to mean something.
     *
     * The filter exists to hide pending, rejected and archived entries. A winner is
     * none of those.
     */
    private const PUBLIC_STATUSES = ['approved', 'winner', 'runner_up'];

    public function __construct(
        private readonly Twig            $view,
        private readonly CacheService    $cache,
        private readonly AwardService    $awards,
        private readonly ?PaymentService $payments = null
    ) {}

    /**
     * The community/judge split, as the scorer currently computes it.
     *
     * ── WHY A BALLOT NEEDS THIS ─────────────────────────────────────────────
     *
     * The vote pages told a voter "community votes are 45% of the final score" in
     * typed prose, while /integrity one click away read the figure out of
     * RuleEngine — which an operator can change per programme and per cycle. The
     * two could disagree, and the page that would have been wrong is the one a
     * person reads immediately before deciding whether to pay.
     *
     * Same engine, same numbers, everywhere the split is quoted.
     *
     * @return array{community:int, judge:int}
     */
    private function splitPct(): array {
        try {
            $w = (new RuleEngine())->weights();
            return [
                'community' => (int) round($w['community'] * 100),
                'judge'     => (int) round($w['judge'] * 100),
            ];
        } catch (\Throwable) {
            // A ballot must still render if the rules table is unreachable. The code
            // defaults are the same ones RuleEngine would have returned.
            return [
                'community' => (int) round(RuleEngine::DEFAULTS['community_weight'] * 100),
                'judge'     => (int) round(RuleEngine::DEFAULTS['judge_weight'] * 100),
            ];
        }
    }

    /** /vote — the HUB: browse the live programmes, then drill into one to vote. */
    public function index(Request $req, Response $res): Response {
        $hub = $this->cache->remember('vote:hub', 600, fn() => $this->awards->voteHub());

        $front = \AfricaGates\Services\VoteFront::hub($hub, (string) ($req->getQueryParams()['f'] ?? 'all'));

        // Phase 5 (VoteHub.dc.html): one view-model, so the live total, the rows and the
        // rail cannot contradict each other — the reported failure this method's comment
        // above records ("Voting open", "0 Days left" and a past close date at once).
        return $this->view->render($res, 'pages/vote.twig', [
            // Free voting can be switched off; then "one vote per category" is not the rule.
            'paid_only'        => PaidVoteService::freeVotingDisabled(),
            'page_title'       => \AfricaGates\Support\Translator::t('Vote') . ' — Africa GATES',
            'meta_description' => 'Cast your verified vote in the Africa GATES awards. Browse the live programmes and back the African excellence you believe deserves continental recognition.',
            'gates_page'       => 'awards',
            'front'            => $front,
            'split'            => $this->splitPct(),
            // The community pride board (CommunityBoard): the places backing their own, by people.
            'communities'      => array_slice(\AfricaGates\Services\CommunityBoard::current(), 0, 6),
            // The vote hub's one ad (Services\Ads). Picked per request, never cached with the
            // hub: frequency, pacing and the nominee rule are all decided now.
            'ad'               => \AfricaGates\Services\Ads\AdDelivery::forRequest('vote_hub', $req),
            'breadcrumbs' => [
                ['label' => 'Africa GATES', 'url' => '/'],
                ['label' => 'Vote',         'url' => '/vote'],
            ],
        ]);
    }

    /**
     * /vote/{program} — a PAGE FOR EACH PROGRAMME: its approved nominees grouped by
     * category, each linking to that nominee's own individual page. The {program}
     * segment is the admin-editable programme slug. A bookmarked legacy /vote/{id}
     * link (segment starts with a digit) is gracefully redirected to its canonical
     * nested URL; an unknown slug falls back to the hub — never a 404.
     */
    public function program(Request $req, Response $res, array $args): Response {
        $seg = (string) ($args['program'] ?? '');
        if ($seg !== '' && ctype_digit($seg[0])) {
            return $this->nomineeRedirect($res, (int) $seg); // legacy /vote/{id}
        }
        $p = $this->awards->getProgrammeBySlug($seg);
        if (!$p) return $res->withHeader('Location', '/vote')->withStatus(302);
        // A volunteer's voter-drive link (Volunteer\VoterDrive): kept for this browser until a
        // counted vote spends it. It opens the ballot and names no nominee.
        $drive = (string) ($req->getQueryParams()['drive'] ?? '');
        if ($drive !== '') \AfricaGates\Services\Volunteer\VoterDrive::capture($drive);

        $year = (int) ($p['cycle']['year'] ?? date('Y'));
        $noms = $this->awards->getNominees((int) $p['id'], 0, $year);
        $byCat = [];
        foreach ($p['categories'] as $c) { $byCat[(int) $c['id']] = ['category' => $c, 'nominees' => []]; }
        foreach ($noms as $n) {
            $cid = (int) $n['category_id'];
            if (!isset($byCat[$cid])) $byCat[$cid] = ['category' => ['id' => $cid, 'title' => $n['category'], 'description' => null], 'nominees' => []];
            $n['url'] = $this->nomineeUrl((int) $n['id'], (string) $n['name'], (string) $p['slug']); // canonical nested link
            $byCat[$cid]['nominees'][] = $n;
        }
        $cats = array_values(array_filter($byCat, fn($c) => count($c['nominees']) > 0));

        // Race framing. Rank, the gap to the position above and a share-of-leader bar,
        // computed once per category in memory rather than by asking StandingsService
        // per nominee — which would be one full category scan for every card on the page.
        foreach ($cats as &$c) {
            $c['nominees'] = \AfricaGates\Services\RaceService::annotate($c['nominees']);
        }
        unset($c);

        // ── THE SHORTLIST BADGE ──────────────────────────────────────────────
        //
        // ONE query for the whole page, not one per card. `shortlistedIn()` returns an
        // id-keyed set, so marking sixty cards is sixty array lookups rather than sixty
        // round trips — the same reason the race framing above is computed in memory.
        //
        // Read from the PUBLISHED snapshot and never recomputed here: a badge derived from
        // a live threshold would appear and disappear as votes landed, telling a nominee
        // they were shortlisted and then that they were not, on a page they did not reload.
        $shortlisted = \AfricaGates\Services\ShortlistService::shortlistedIn((int) ($p['cycle']['id'] ?? 0));
        if ($shortlisted !== []) {
            foreach ($cats as &$c) {
                foreach ($c['nominees'] as &$n) {
                    $n['shortlisted'] = isset($shortlisted[(int) $n['id']]);
                }
                unset($n);
            }
            unset($c);
        }

        // ── ALL: THE WHOLE EDITION AS ONE LIST ───────────────────────────────
        //
        // The award is decided across the edition (the community half is scored against
        // the edition's field, never a category's — see EditionScaleTest), so a voter
        // reading one category at a time never saw the race the prize is actually about.
        // "All" ranks every nominee by public votes in one list, each row naming its
        // category. Same RaceService arithmetic, over the edition instead of a category.
        // It is a list of VOTES, not the overall standing — the judges' half is not in it,
        // and the page says so under the list. One category has nothing to add: no All.
        $overall = null;
        if (count($cats) > 1) {
            $all = [];
            foreach ($cats as $c) {
                foreach ($c['nominees'] as $n) {
                    $n['category_title'] = (string) ($c['category']['title'] ?? '');
                    $all[] = $n;
                }
            }
            $overall = ['nominees' => \AfricaGates\Services\RaceService::annotate($all)];
        }

        $q   = $req->getQueryParams();
        $tab = ($q['tab'] ?? '') === 'about' ? 'about' : 'vote';
        $catId = isset($q['cat']) && ctype_digit((string) $q['cat']) ? (int) $q['cat'] : null;
        // The view drawn on arrival: a category only when ?cat= names one on this page.
        $catView = null;
        foreach ($cats as $c) { if ($catId !== null && (int) $c['category']['id'] === $catId) { $catView = $catId; break; } }

        // The award's campaign (Support\AwardCampaign) and, where the host turned it on, the
        // Supporter Spotlight for this edition. Both draw nothing until an operator says so.
        $campaign  = \AfricaGates\Support\AwardCampaign::forProgramme((int) $p['id']);
        $cycleId   = (int) (($p['cycle']['id'] ?? null) ?: ($p['cycle_id'] ?? 0));
        $price     = PaidVoteService::enabled() ? PaidVoteService::pricePerVote() : 0;
        $sharePer  = $campaign['beneficiary'] !== '' && $campaign['share_pct'] > 0 ? intdiv($price * $campaign['share_pct'], 100) : 0;
        $spotlight = ($campaign['spotlight'] || $sharePer > 0) && $cycleId > 0 && $tab === 'vote'
            ? \AfricaGates\Services\SupporterSpotlight::forCycle($cycleId) : null;
        // What the band can say that is TRUE: the beneficiary's share of every verified,
        // settled contributed vote so far — counted from the ledger, never an estimate.
        $raised    = $spotlight ? (int) $spotlight['paid'] * $sharePer : 0;

        return $this->view->render($res, 'pages/vote-program.twig', [
            'campaign'         => $campaign,
            'impact'           => \AfricaGates\Support\AwardCampaign::impact($campaign),
            'spotlight'        => $campaign['spotlight'] ? $spotlight : null,
            'raised'           => $raised,
            'supporters'       => $spotlight ? (int) $spotlight['people'] : 0,
            'champion'         => $spotlight['champion'] ?? null,
            'vote_price'       => $price,
            'paid_only'        => PaidVoteService::freeVotingDisabled(),
            // A voting extension on this edition (VotingExtension), stated beside the close.
            'extension'        => \AfricaGates\Services\VotingExtension::notice($cycleId),
            'page_title'       => $p['title'] . ' — Vote — Africa GATES',
            'meta_description' => 'Vote in ' . $p['title'] . ' — browse the nominees by category and back the African excellence you believe deserves continental recognition.',
            'gates_page'       => 'awards',
            'programme'        => $p,
            'categories'       => $cats,
            'overall'          => $overall,
            'cat_view'         => $catView,
            'front'            => \AfricaGates\Services\VoteFront::programme($p, $cats, $catId),
            'tab'              => $tab,
            'breadcrumbs'      => [
                ['label' => 'Vote',      'url' => '/vote'],
                ['label' => $p['title'], 'url' => null],
            ],
        ]);
    }

    /**
     * /vote/{program}/spotlight — THE SUPPORTER SPOTLIGHT, ON ITS OWN PAGE (owner, 16 Nov 2026:
     * "create a page for the supporter spotlight instead. UX is terrible there. SPA, no full
     * reload").
     *
     * It was a section at the foot of the ballot, under every category's race: a wall of sixty
     * faces, two honours and a top five that a voter scrolled through to reach the questions,
     * and that nobody arriving from a Spotlight email could land on. Here it is a page with an
     * address, two tabs (?tab=everybody is the wall, ranked) and the person's own place when
     * they are signed in. It is an ordinary public page, so site-nav swaps it in place.
     *
     * A host who switched the Spotlight off gets the ballot, not a 404: the link may be in an
     * email from before they did.
     */
    public function spotlight(Request $req, Response $res, array $args): Response {
        $p = $this->awards->getProgrammeBySlug((string) ($args['program'] ?? ''));
        if (!$p) return $res->withHeader('Location', '/vote')->withStatus(302);
        $base = '/vote/' . $p['slug'];
        $campaign = \AfricaGates\Support\AwardCampaign::forProgramme((int) $p['id']);
        $cycleId  = (int) (($p['cycle']['id'] ?? null) ?: ($p['cycle_id'] ?? 0));
        if (!$campaign['spotlight'] || $cycleId < 1) return $res->withHeader('Location', $base)->withStatus(302);
        $tab = ($req->getQueryParams()['tab'] ?? '') === 'everybody' ? 'everybody' : 'honours';
        $spot = \AfricaGates\Services\SupporterSpotlight::forCycle($cycleId);

        // The signed-in supporter's own place, by the board's own rule — the thing they most
        // want to know, and true: SupporterSpotlight::standingOf counts as the board counts.
        $uid = (int) ($_SESSION['user_id'] ?? 0);
        $me = null;
        if ($uid > 0) {
            $email = (string) (DB::table('gates_users')->where('id', $uid)->where('email_verified', 1)->value('email') ?? '');
            if ($email !== '') {
                $st = \AfricaGates\Services\SupporterSpotlight::standingOf($cycleId, $email, $uid);
                if ($st['votes'] > 0) $me = $st + ['standing' => \AfricaGates\Support\AwardCampaign::standing($campaign, $st['votes'])];
            }
        }
        $edition = $p['cycle'] ? \AfricaGates\Support\EditionName::label((object) $p['cycle']) : '';

        return $this->view->render($res, 'pages/vote-spotlight.twig', [
            'programme'        => $p,
            'campaign'         => $campaign,
            'spotlight'        => $spot,
            'tab'              => $tab,
            'me'               => $me,
            'edition'          => $edition,
            'my_keys'          => \AfricaGates\Services\SupporterSpotlight::keysForUser($uid),
            'community_place'  => \AfricaGates\Services\CommunityBoard::placeOf((int) $p['id']),
            'page_title'       => 'Supporter spotlight — ' . $p['title'] . ' — Africa GATES',
            'meta_description' => 'The people backing their own in ' . $p['title'] . ': today’s champion, the mobiliser of the week, the top supporters and everybody else.',
            'gates_page'       => 'awards',
        ]);
    }

    /**
     * /vote/{program}/{id-slug}/backed.png — "I backed …", the supporter's card (BackedCard).
     * Cached ten minutes, as the nominee's own card is: long enough to make a shared link
     * cheap to preview, short enough that the count on it is not yesterday's.
     */
    public function backed(Request $req, Response $res, array $args): Response {
        $nid = (int) (string) ($args['slug'] ?? '0');
        $f = \AfricaGates\Services\BackedCard::facts($nid);
        if ($f === null) throw new \Slim\Exception\HttpNotFoundException($req);
        $b64 = '';
        try {
            $b64 = (string) (new CacheService())->remember('backed-card:' . $nid, 600,
                static fn () => base64_encode((string) ((new \AfricaGates\Services\BackedCard())->png($f) ?? '')), ['nominees']);
        } catch (\Throwable) {
            $b64 = base64_encode((string) ((new \AfricaGates\Services\BackedCard())->png($f) ?? ''));
        }
        $png = (string) base64_decode($b64, true);
        if ($png === '') return $res->withHeader('Location', \AfricaGates\Support\NomineeUrl::path($nid) . '/card.png')->withStatus(302);
        $res->getBody()->write($png);
        return $res->withHeader('Content-Type', 'image/png')->withHeader('Content-Length', (string) strlen($png))
            ->withHeader('Cache-Control', 'public, max-age=600, stale-while-revalidate=1800')->withHeader('X-Content-Type-Options', 'nosniff')
            ->withHeader('Content-Disposition', 'inline; filename="i-backed-' . (\AfricaGates\Support\Slug::make((string) $f['name'], 48) ?: 'nominee') . '.png"');
    }

    /** /vote/{program}/{id-slug}/milestone/{kind}-{value}.png — a milestone the nominee reached, as their card (MilestoneCard). */
    public function milestoneCard(Request $req, Response $res, array $args): Response {
        $nid = (int) (string) ($args['slug'] ?? '0');
        $kind = (string) ($args['kind'] ?? ''); $value = (int) ($args['value'] ?? 0);
        $png = \AfricaGates\Services\MilestoneCard::png($nid, $kind, $value);
        if ($png === null || $png === '') throw new \Slim\Exception\HttpNotFoundException($req);
        $res->getBody()->write($png);
        return $res->withHeader('Content-Type', 'image/png')->withHeader('Content-Length', (string) strlen($png))
            ->withHeader('Cache-Control', 'public, max-age=3600')->withHeader('X-Content-Type-Options', 'nosniff')
            ->withHeader('Content-Disposition', 'inline; filename="milestone-' . $kind . '-' . $value . '.png"');
    }

    /**
     * /vote/{program}/{id-slug}/voice — the nominee's voice thank-you (NomineeVoice). Served by
     * PHP from outside the web root, so taking it down takes it off the internet at once; only
     * for a nominee on a live award, never the sandbox.
     */
    public function voice(Request $req, Response $res, array $args): Response {
        $nid = (int) (string) ($args['slug'] ?? '0');
        $live = $nid > 0 && \AfricaGates\Services\DemoSeeder::liveAwardOnly(DB::table('gates_nominees')->where('gates_nominees.id', $nid))->exists();
        $v = $live ? \AfricaGates\Services\NomineeVoice::forNominee($nid) : null;
        $f = $v ? \AfricaGates\Services\NomineeVoice::fileFor($v) : null;
        if ($f === null) throw new \Slim\Exception\HttpNotFoundException($req);
        return \AfricaGates\Support\RangeFile::respond($req, $res, $f, \AfricaGates\Services\NomineeVoice::mimeFor($f), 'public, max-age=300')
            ->withHeader('X-Robots-Tag', 'noindex');
    }

    /**
     * /vote/{program}/offer — WHAT YOUR SUPPORT UNLOCKS (owner, 17 Nov 2026). Everything on it
     * is what the award's campaign settings say, and nothing else: a section the host has not
     * filled in is not drawn, because these are promises to the public (AwardCampaign).
     *
     * A signed-in member, or anybody arriving by their personal link (OfferLink), is shown
     * their own votes, what they have unlocked and what is next, and any day they were
     * Champion of the Day with the code to claim the gift.
     */
    public function offer(Request $req, Response $res, array $args): Response {
        $p = $this->awards->getProgrammeBySlug((string) ($args['program'] ?? ''));
        if (!$p) return $res->withHeader('Location', '/vote')->withStatus(302);
        $c = \AfricaGates\Support\AwardCampaign::forProgramme((int) $p['id']);
        $cycleId = (int) (($p['cycle']['id'] ?? null) ?: ($p['cycle_id'] ?? 0));
        $keys = $this->viewerKeys($req);
        $me = null; $mine = [];
        if ($keys !== [] && $cycleId > 0) {
            $st = \AfricaGates\Services\SupporterSpotlight::standingOfKeys($cycleId, $keys);
            if ($st['votes'] > 0) $me = $st + ['standing' => \AfricaGates\Support\AwardCampaign::standing($c, $st['votes'])];
            foreach (\AfricaGates\Services\DailyChampion::forKeys($cycleId, $keys) as $d) {
                $mine[] = ['day' => $d->day, 'kind' => $d->kind, 'title' => $d->title, 'words' => $d->date_words, 'gift' => (int) $d->gift === 1, 'code' => \AfricaGates\Services\DailyChampion::code($d)];
            }
        }
        $board = $cycleId > 0 && $c['spotlight'] ? \AfricaGates\Services\SupporterSpotlight::forCycle($cycleId) : [];
        $live = $board['champion'] ?? null;
        return $this->view->render($res, 'pages/vote-offer.twig', [
            'programme' => $p, 'campaign' => $c, 'impact' => \AfricaGates\Support\AwardCampaign::impact($c),
            'me' => $me, 'my_days' => $mine, 'leader' => $live,
            'champions' => $c['spotlight'] ? \AfricaGates\Services\DailyChampion::recent($cycleId, 7) : [],
            'week_leader' => $board['week_champion'] ?? null,
            'week_champions' => $c['spotlight'] ? \AfricaGates\Services\DailyChampion::recent($cycleId, 4, 'week') : [],
            'award_champion' => $c['spotlight'] ? (\AfricaGates\Services\DailyChampion::recent($cycleId, 1, 'award')[0] ?? null) : null,
            'award_leader' => $board['top'][0] ?? null,
            'claim' => \AfricaGates\Support\AwardCampaign::claimLink($c, 'Champion: claiming my gift'),
            'capital_url' => \AfricaGates\Support\AwardCampaign::safeUrl($c['capital_url']),
            'announce_hour' => \AfricaGates\Services\DailyChampion::ANNOUNCE_HOUR,
            'page_title' => 'What your support unlocks — ' . $p['title'] . ' — Africa GATES',
            'meta_description' => $c['promise'] !== '' ? $c['promise'] : 'What voting in ' . $p['title'] . ' unlocks for you and your community.',
        ]);
    }

    /**
     * /vote/{program}/champion/{day} — THE CHAMPION OF THE DAY, ANNOUNCED: the page a champion
     * shares. Its link preview is their card. The champion themselves (signed in, or by their
     * personal link) also sees how to claim the gift.
     */
    public function champion(Request $req, Response $res, array $args): Response {
        $p = $this->awards->getProgrammeBySlug((string) ($args['program'] ?? ''));
        $d = $p ? \AfricaGates\Services\DailyChampion::forProgrammeDay((int) $p['id'], (string) ($args['day'] ?? '')) : null;
        if (!$p || !$d) throw new \Slim\Exception\HttpNotFoundException($req);
        $c = \AfricaGates\Support\AwardCampaign::forProgramme((int) $p['id']);
        $isMe = in_array((string) $d->person_key, $this->viewerKeys($req), true);
        $site = \AfricaGates\Support\SiteUrl::base($req);
        $path = '/vote/' . $p['slug'] . '/champion/' . $d->day;
        $who = $d->display ?? 'A proud supporter';
        $when = self::championWhen($d, (string) $p['title']);
        return $this->view->render($res, 'pages/vote-champion.twig', [
            'programme' => $p, 'campaign' => $c, 'd' => $d, 'is_me' => $isMe, 'path' => $path,
            'gifts' => self::giftLists($c)[$d->kind] ?? [],
            'code' => $isMe ? \AfricaGates\Services\DailyChampion::code($d) : '',
            'claim' => $isMe ? \AfricaGates\Support\AwardCampaign::claimLink($c, $d->title . ': claiming my gift') : null,
            'share_text' => ($c['community'] !== '' ? $c['community'] . '’s' : $p['title']) . ' ' . $d->title . ($d->kind === 'award' ? '' : ', ' . $d->date_words) . ': ' . $who . '. ' . $site . $path,
            'page_title' => $who . ' — ' . $d->title . ' — ' . $p['title'],
            'meta_description' => $who . ' gave the most votes of anybody ' . $when . '.',
            'og_image' => $site . $path . '.png', 'og_image_w' => \AfricaGates\Services\BackedCard::W, 'og_image_h' => \AfricaGates\Services\BackedCard::H,
            'og_image_alt' => $who . ', ' . $d->title,
        ]);
    }

    /** /vote/{program}/champion/{day}.png — the champion's card, the page's link preview. */
    public function championCard(Request $req, Response $res, array $args): Response {
        $p = $this->awards->getProgrammeBySlug((string) ($args['program'] ?? ''));
        $d = $p ? \AfricaGates\Services\DailyChampion::forProgrammeDay((int) $p['id'], (string) ($args['day'] ?? '')) : null;
        if (!$p || !$d) throw new \Slim\Exception\HttpNotFoundException($req);
        $c = \AfricaGates\Support\AwardCampaign::forProgramme((int) $p['id']);
        $png = (new \AfricaGates\Services\BackedCard())->draw([
            'photo' => (string) ($d->photo ?? ''), 'initials_of' => $d->display ?? 'Proud Supporter',
            'kicker' => $c['community'] !== '' ? $c['community'] . ' is celebrating its own' : (string) $p['title'],
            'lead' => $d->title, 'title' => $d->display ?? 'A proud supporter',
            'sub' => match ($d->kind) {
                'day' => \Illuminate\Support\Carbon::parse((string) $d->day)->format('j F Y') . ' · ',
                'week' => ucfirst($d->date_words) . ' · ',
                default => '',
            } . $p['title'],
            'foot' => number_format((int) $d->votes) . ((int) $d->votes === 1 ? ' vote' : ' votes') . ($d->backing ? ' backing ' . $d->backing : ''),
        ]);
        if ($png === null || $png === '') throw new \Slim\Exception\HttpNotFoundException($req);
        $res->getBody()->write($png);
        return $res->withHeader('Content-Type', 'image/png')->withHeader('Content-Length', (string) strlen($png))
            ->withHeader('Cache-Control', 'public, max-age=3600')->withHeader('X-Content-Type-Options', 'nosniff');
    }

    /**
     * /champions/{code} — the check behind a gift claim: whoever the champion contacts opens
     * the code and sees, from our own record, that it is genuine, which day, and whether this
     * is their gift (once per person per campaign) or a repeat celebration.
     */
    public function championCheck(Request $req, Response $res, array $args): Response {
        $d = \AfricaGates\Services\DailyChampion::byCode((string) ($args['code'] ?? ''));
        $p = $d ? DB::table('gates_award_programmes')->where('id', (int) $d->programme_id)->where('is_active', 1)->first(['title', 'slug']) : null;
        return $this->view->render($res->withStatus($d && $p ? 200 : 404), 'pages/champion-check.twig', [
            'd' => $d && $p ? $d : null, 'award' => $p ? (string) $p->title : '', 'slug' => $p ? (string) $p->slug : '',
            'page_title' => 'Check a champion’s claim — Africa GATES',
        ])->withHeader('X-Robots-Tag', 'noindex');
    }

    /** Each champion kind's prizes, from the award's settings. @return array<string,list<string>> */
    private static function giftLists(array $c): array
    {
        return ['day' => $c['champion_gifts'] ?? [], 'week' => $c['week_gifts'] ?? [], 'award' => $c['award_gifts'] ?? []];
    }

    /** "on Monday 16 November 2026 in X", "in the week of … in X", "across the whole of X". */
    private static function championWhen(object $d, string $award): string
    {
        return match ($d->kind) {
            'day' => 'on ' . $d->date_words . ' in ' . $award,
            'week' => 'in ' . $d->date_words . ' in ' . $award,
            default => 'across the whole of ' . $award,
        };
    }

    /**
     * The person keys of whoever is looking: a signed-in member's (their address and their
     * points), or the one their personal link carries. @return list<string>
     */
    private function viewerKeys(Request $req): array
    {
        $uid = (int) ($_SESSION['user_id'] ?? 0);
        if ($uid > 0) {
            $email = (string) (DB::table('gates_users')->where('id', $uid)->where('email_verified', 1)->value('email') ?? '');
            if ($email !== '') return [\AfricaGates\Services\VoteService::voterHash($email), 'points:' . $uid];
        }
        $k = \AfricaGates\Services\OfferLink::key($req->getQueryParams());
        return $k !== null ? [$k] : [];
    }

    /**
     * /vote/{program}/{id-slug}/poster — an A4 poster to print: the nominee, the award and a QR
     * code to their ballot, for the places a campaign actually happens here — a church, a market,
     * a school notice board. The flier already carries a QR, but no page printed on A4.
     */
    public function poster(Request $req, Response $res, array $args): Response {
        $nid = (int) (string) ($args['slug'] ?? '0');
        $f = \AfricaGates\Services\BackedCard::facts($nid);
        if ($f === null) throw new \Slim\Exception\HttpNotFoundException($req);
        $path = \AfricaGates\Support\NomineeUrl::path($nid);
        $link = \AfricaGates\Support\SiteUrl::base($req) . $path;
        return $this->view->render($res, 'pages/vote-poster.twig', [
            'f' => $f, 'link' => $link, 'path' => $path, 'qr' => \AfricaGates\Support\Qr::svgBytes($link, 8),
            'page_title' => 'Poster — ' . $f['name'] . ' — Africa GATES',
        ])->withHeader('X-Robots-Tag', 'noindex');
    }

    /** POST /vote/follow — "tell me when they reach a milestone" (NomineeMilestones::follow). */
    public function follow(Request $req, Response $res): Response {
        $b = (array) $req->getParsedBody();
        $nid = (int) ($b['nominee'] ?? 0);
        $r = \AfricaGates\Services\NomineeMilestones::follow($nid, (string) ($b['email'] ?? ''));
        $_SESSION['vote_follow'] = $r['ok'] ? ['ok' => true, 'msg' => 'Done. We will tell you when they reach a milestone, at most three times this edition.']
                                            : ['ok' => false, 'msg' => (string) $r['error']];
        return $res->withHeader('Location', \AfricaGates\Support\NomineeUrl::path($nid) . '#follow')->withStatus(303);
    }

    /**
     * /vote/{program}/tallies — the live figures, as JSON.
     *
     * ── WHY POLLING AND NOT A SOCKET ─────────────────────────────────────────
     *
     * Shared cPanel hosting with no persistent process. A websocket or SSE stream holds
     * a PHP worker open per viewer, and this platform's audience arrives in bursts when
     * a nominee posts a flier — the exact moment holding connections open would exhaust
     * the pool and take the ballot down. A cached poll degrades instead: more viewers
     * hit the same cached payload.
     *
     * Cached for a few seconds, so a thousand people watching one category cost roughly
     * one query rather than a thousand. Votes are not a trading price; nobody is harmed
     * by seeing a tally that is five seconds old, and the alternative is a page that
     * takes the database down at precisely the moment it matters.
     *
     * Returns the SAME shape RaceService puts in the template, so the client patches
     * numbers it already knows how to render rather than re-deriving standings — a
     * second implementation of rank arithmetic in JavaScript is how the page and its
     * updates start disagreeing.
     */
    public function tallies(Request $req, Response $res, array $args): Response {
        $seg = (string) ($args['program'] ?? '');
        $p   = $this->awards->getProgrammeBySlug($seg);
        if (!$p) {
            $res->getBody()->write('{"ok":false}');
            return $res->withHeader('Content-Type', 'application/json')->withStatus(404);
        }

        $key  = 'tallies:' . $seg . ':' . (int) ($p['cycle']['year'] ?? 0);
        $body = (new \AfricaGates\Services\CacheService())->remember($key, 5, function () use ($p) {
            $year  = (int) ($p['cycle']['year'] ?? date('Y'));
            $byCat = [];
            foreach ($this->awards->getNominees((int) $p['id'], 0, $year) as $n) {
                $byCat[(int) $n['category_id']][] = $n;
            }
            $out = [];
            foreach ($byCat as $cid => $list) {
                $ranked = \AfricaGates\Services\RaceService::annotate($list);
                $out[] = [
                    'category_id' => $cid,
                    'nominees'    => array_map(static fn (array $n) => [
                        'id'    => (int) $n['id'],
                        'votes' => (int) $n['vote_count'],
                        'rank'  => (int) $n['rank'],
                        'gap'   => $n['gap'],
                        'next'  => $n['next_rank'] ?? null,
                        'pct'   => (int) $n['pct'],
                    ], $ranked),
                ];
            }
            // The All list ranks across the edition, so its rank and bar are not any one
            // category's; sent separately so the page patches each list from its own race.
            $overall = [];
            if (count($byCat) > 1) {
                foreach (\AfricaGates\Services\RaceService::annotate(array_merge(...array_values($byCat))) as $n) {
                    $overall[] = ['id' => (int) $n['id'], 'votes' => (int) $n['vote_count'], 'rank' => (int) $n['rank'], 'gap' => $n['gap'], 'next' => $n['next_rank'] ?? null, 'pct' => (int) $n['pct']];
                }
            }
            return ['ok' => true, 'at' => date('c'), 'categories' => $out, 'overall' => $overall];
        });

        // CacheService stores and returns ARRAYS (it json_decodes on read), so the
        // encoding happens here rather than inside the callback — otherwise the payload
        // is a JSON string inside a JSON string and the client parses twice.
        $res->getBody()->write((string) json_encode(is_array($body) ? $body : ['ok' => false]));
        return $res
            ->withHeader('Content-Type', 'application/json')
            // Let a CDN or the browser absorb a rally too. Short enough that the page
            // still feels live, long enough that a burst does not reach PHP at all.
            ->withHeader('Cache-Control', 'public, max-age=5');
    }

    /**
     * /vote/{program}/{slug} — ALWAYS one nominee's individual page. {slug} is
     * "{id}-{name}", resolved by the leading id; if the {program} segment doesn't
     * match the nominee's real programme, we 302 to the canonical URL.
     */
    public function nominee(Request $req, Response $res, array $args): Response {
        $slug = (string) ($args['slug'] ?? '');
        $prog = (string) ($args['program'] ?? '');
        if ($slug === '' || !ctype_digit($slug[0])) {
            return $res->withHeader('Location', '/vote/' . rawurlencode($prog))->withStatus(302);
        }
        return $this->nomineeBallot($req, $res, (int) $slug, $prog);
    }

    /** Canonical nominee URL: /vote/{programme-slug}/{id}-{name}. */
    private function nomineeUrl(int $id, string $name, string $programmeSlug): string {
        // Slug::idSegment, not a local expression. The five copies of
        // `preg_replace('/[^a-z0-9]+/i', ...)` in this codebase DELETED accented letters
        // instead of folding them, so "Ọlásùnkànmí Adébáyọ̀" became "l-s-nk-nm-ad-b-y" —
        // fourteen of twenty letters gone. It still resolved, because the id leads the
        // segment, which is exactly why it survived: the failure is a link that looks
        // like corruption everywhere a nominee shares it.
        return '/vote/' . $programmeSlug . '/' . \AfricaGates\Support\Slug::idSegment($id, $name);
    }

    /** Bounce a legacy /vote/{id} link to its canonical nested URL. */
    private function nomineeRedirect(Response $res, int $id): Response {
        $row = DB::table('gates_nominees as n')
            ->join('gates_award_categories as c', 'c.id', '=', 'n.category_id')
            ->join('gates_award_cycles as cy', 'cy.id', '=', 'c.cycle_id')
            ->join('gates_award_programmes as p', 'p.id', '=', 'cy.programme_id')
            // The demo programme carries `is_active = 0`, and that one column is the whole
            // thing keeping the sandbox off the public site. Without this, /vote/{id}
            // resolved ANY id — so it handed the canonical URL of a sandbox nominee to
            // anybody who guessed a number. Full account on nomineeBallot() below.
            ->where('p.is_active', 1)
            ->where('n.id', $id)->whereIn('n.status', self::PUBLIC_STATUSES)
            ->where(fn($q) => \AfricaGates\Services\MergeService::notMerged($q, 'n.merged_into'))
            ->select(['n.id', 'n.name', 'p.slug as programme_slug'])->first();
        if (!$row) {
            $to = \AfricaGates\Services\MergeService::survivorOf($id);
            if ($to !== null) return $this->nomineeRedirect($res, $to);
            return $res->withHeader('Location', '/vote')->withStatus(302);
        }
        return $res->withHeader('Location', $this->nomineeUrl($id, (string) $row->name, (string) $row->programme_slug))->withStatus(302);
    }

    /**
     * Human-readable reason a paid-vote checkout bounced back here.
     *
     * PaidVoteController emits eight of these as a `?paid=` query parameter and
     * NO template read any of them, so a supporter refused because voting had
     * closed — or because their email was invalid, or the provider was off — was
     * returned to an unchanged page with no message at all.
     */
    private const PAID_REASONS = [
        'off'         => 'Paid voting is not enabled right now.',
        // "from this network" is gone, and so is the policy that produced it. That
        // wording was accusing a supporter of behaviour that belonged to a Cloudflare
        // edge address shared by the whole internet — see CheckoutThrottle. What is
        // left is a queue notice, and the caller appends when to come back.
        'rate'        => 'We are processing a burst of payments right now. Your details are saved — press pay again',
        'nominee'     => 'That nominee is not open for votes.',
        // The quantity is echoed back by the caller, so a bulk buyer is told the actual
        // limit instead of having their order quietly cut down to it.
        'toomany'     => 'That is more votes than one order can carry. The maximum is',
        'closed'      => 'Voting has closed for this category, so no votes could be purchased.',
        // The last few minutes belong to the free ballot. Card payments stop a
        // little earlier because they have to travel to a bank and back, and an
        // order that cannot finish in time is one we should never have taken.
        'cutoff'      => 'Card payment for this category has closed so payments in progress can finish. '
                       . 'Free voting is still open — use the ballot above.',
        // Replaced by VotingExtension::paidClosedSentence() in nomineeBallot(), which has the dates.
        'extended'    => 'Paid voting for this edition closed when voting was extended; free voting stays open.',
        'unavailable' => 'That payment method is unavailable right now. Please try another.',
        'email'       => 'Please enter a valid email address for your receipt.',
        'terms'       => 'Please accept the award terms before contributing. No payment was taken.',
        'start'       => 'We could not start the checkout. No payment was taken — please try again.',
        'error'       => 'Something went wrong starting the checkout. No payment was taken.',
        'failed'      => 'That payment did not complete, so no votes were added.',
    ];

    /**
     * Read-and-clear the bounced paid-vote order.
     *
     * Cleared on read so it prefills exactly the one page load it was written for. A
     * flash that lingers would re-open a supporter's email address on a ballot they
     * later return to from a shared phone, and would silently re-arm a quantity they
     * had already decided against.
     *
     * @return array{qty:int, email:string, name:string, detail:string}
     */
    private function takePaidRetry(): array
    {
        $blank = ['qty' => 0, 'email' => '', 'name' => '', 'detail' => ''];
        if (!isset($_SESSION) || !is_array($_SESSION)) return $blank;
        $r = $_SESSION['paid_vote_retry'] ?? null;
        unset($_SESSION['paid_vote_retry']);
        if (!is_array($r)) return $blank;
        return [
            'qty'    => max(0, (int) ($r['qty'] ?? 0)),
            'email'  => mb_substr(trim((string) ($r['email'] ?? '')), 0, 191),
            'name'   => mb_substr(trim((string) ($r['name'] ?? '')), 0, 120),
            'detail' => mb_substr(trim((string) ($r['detail'] ?? '')), 0, 60),
        ];
    }

    /** The individual nominee vote page (profile-style with the OTP ballot inline). */
    private function nomineeBallot(Request $req, Response $res, int $id, string $programSeg = ''): Response {
        if ($id < 1) throw new \Slim\Exception\HttpNotFoundException($req);

        $nom = DB::table('gates_nominees as n')
            ->join('gates_award_categories as c', 'c.id', '=', 'n.category_id')
            ->join('gates_award_cycles as cy', 'cy.id', '=', 'c.cycle_id')
            ->join('gates_award_programmes as p', 'p.id', '=', 'cy.programme_id')
            // ── A WINNER STILL HAS A PAGE ────────────────────────────────────
            //
            // This read `status = 'approved'`, which is the state a nominee is in
            // for exactly as long as the cycle is unfinished. CycleMaterialiser
            // writes 'winner' and 'runner_up' onto the nominee row the moment the
            // standings are sealed — so the promotion that is supposed to be the
            // high point of a nominee's cycle DELETED THEIR PUBLIC PAGE.
            //
            // Every link anybody had shared for the whole campaign 404s at the
            // moment it finally means something, and the supporters being told
            // "see the roll of honour" would have arrived at a not-found. The
            // filter is there to hide pending and rejected entries; a winner is
            // neither.
            //
            // ── AND THE SANDBOX IS NOT PUBLIC ────────────────────────────────
            //
            // DemoSeeder contains the demo by construction rather than by flag: its
            // programme carries `is_active = 0`, and that single column is the whole
            // public-invisibility mechanism. Its nominees, though, are seeded
            // 'approved' inside a cycle at 'voting' — so every other filter on this
            // query waves them through, and this is THE BALLOT. A sandbox nominee had
            // a live, votable page at its direct URL: real ballots landing on a row
            // that exists to be deleted, and a real voter's OTP spent against it.
            //
            // The hub and the programme page were never affected — AwardService and
            // SitemapService both require 1 already. This reader did not, which is
            // exactly why the containment note in DemoSeeder says "both public
            // readers" and there were three.
            //
            // Note what this means beyond the sandbox, because it is a real change:
            // "Active" is an operator checkbox, so deactivating a REAL programme now
            // takes its nominee pages down too. That was already true of the hub, the
            // programme page and the sitemap — so the only state this removes is a
            // nominee page that outlives the programme it belongs to, reachable by
            // direct link and de-indexed on the same day. Filtering on the slug
            // instead would keep that state alive and hard-code the sandbox besides;
            // `is_active` is the mechanism DemoSeeder deliberately chose so that
            // nothing new has to know the demo exists.
            ->where('p.is_active', 1)
            ->where('n.id', $id)->whereIn('n.status', self::PUBLIC_STATUSES)
            ->where(fn($q) => \AfricaGates\Services\MergeService::notMerged($q, 'n.merged_into'))
            // `organisation` joins the SELECT only when the column exists.
            //
            // A bare `n.organisation` would throw on any database whose migrations have
            // not been applied — and this is THE BALLOT, so the failure would be the
            // whole voting page rather than one missing line. Exactly the outage
            // `show_name` caused on the paid path; a new column is optional until every
            // deployment actually has it.
            ->select(array_merge([
                // `status` is SELECTED, not just filtered on. The celebration block
                // keys off it, and a column that is only in the WHERE clause reads
                // back as null — so the section silently never rendered for anybody.
                'n.id', 'n.name', 'n.status', 'n.tagline', 'n.photo_path', 'n.vote_count', 'n.country_code', 'n.profile_id',
                'c.id as category_id', 'c.title as category',
                'cy.id as cycle_id', 'cy.status as cycle_status', 'cy.year as year',
                'p.id as programme_id', 'p.title as programme_title', 'p.slug as programme_slug',
            ],
                \AfricaGates\Support\OptionalColumn::on('gates_nominees', 'organisation') ? ['n.organisation'] : [],
                // `story` is the nominator's FULL case for this person. Optional in the
                // same way and for the same reason as `organisation`: a bare column name
                // would throw on any deployment whose migrations have not been applied,
                // and this is THE BALLOT — the failure would be the whole voting page
                // rather than one missing paragraph.
                \AfricaGates\Support\OptionalColumn::on('gates_nominees', 'story') ? ['n.story'] : [],
                // ── THE OTHER VOTE FIGURE ────────────────────────────────────
                //
                // This page prints `vote_count` under the word "Votes" — the full public
                // tally, purchased and awarded votes included. The award's result page
                // prints the organic subset, because that is the only part the index
                // reads. So one nominee carried two different vote numbers on two pages
                // of this platform and neither said why, which reads as a figure being
                // quietly revised down where the award is decided.
                //
                // Optional, like the two above and for the same reason: this is THE
                // BALLOT, and a bare column name on a deployment whose migrations have
                // not run takes down the whole voting page rather than one line of it.
                \AfricaGates\Support\OptionalColumn::on('gates_nominees', 'organic_vote_count')
                    ? ['n.organic_vote_count'] : []))
            ->first();
        if (!$nom) {
            // ── A MERGED ENTRY'S LINK GOES TO THE ENTRY IT WAS MERGED INTO ─────────
            //
            // A duplicate exists because somebody campaigned on it: its link is on posters,
            // in WhatsApp groups and in the nominee's own bio, and its votes now count on
            // the survivor. A 404 there tells every supporter who follows it that the
            // nominee was removed, on the day their votes were in fact added together.
            // 302, not 301: a merge can be undone, and a permanent redirect would be
            // cached by every browser that ever followed it. The survivor's own lookup
            // (nomineeRedirect) carries the sandbox and status rules, so this opens nothing.
            $to = \AfricaGates\Services\MergeService::survivorOf($id);
            if ($to !== null) return $this->nomineeRedirect($res, $to);
            throw new \Slim\Exception\HttpNotFoundException($req);
        }

        // Canonical URL: the {program} segment must match the nominee's programme.
        if ($programSeg !== '' && $programSeg !== (string) $nom->programme_slug) {
            return $res->withHeader('Location', $this->nomineeUrl($id, (string) $nom->name, (string) $nom->programme_slug))->withStatus(302);
        }

        // Enrich from the linked registry profile when one exists (portrait, CPI, bio).
        $profile = null;
        if (!empty($nom->profile_id)) {
            $profile = DB::table('gates_profiles')->where('id', $nom->profile_id)->where('status', 'approved')
                ->select(['slug', 'avatar_path', 'bio', 'cpi_score', 'cpi_tier', 'region', 'view_count'])->first();
        }

        // Rank within the category (by votes) + others to discover.
        $catList = $this->awards->getNominees((int) $nom->programme_id, (int) $nom->category_id, (int) $nom->year);
        $rank = 0;
        foreach ($catList as $i => $o) { if ((int) $o['id'] === $id) { $rank = $i + 1; break; } }

        // Standing, gaps and 24-hour momentum. Computed in one place so the ballot, the
        // flier and anything added later cannot describe the same position three
        // different ways — which is how a nominee ends up with a share card that
        // contradicts the page it came from. Note this uses COMPETITION rank (ties share
        // a position) where $rank above is a list index; the two differ on a tie, and
        // the standing is the one that is defensible if a nominee disputes it.
        $standing = (new \AfricaGates\Services\StandingsService())
            ->forNominee($id, (int) $nom->category_id);

        // Absolute, because an og:image must be — a relative path is silently ignored by
        // every crawler and the preview falls back to nothing.
        $flierBase = \AfricaGates\Support\SiteUrl::base($req);
        $nomPath   = $this->nomineeUrl((int) $nom->id, (string) $nom->name, (string) $nom->programme_slug);
        // The og:image is the CARD, not the flier. Both are server-rendered rasters; the
        // difference is the aspect ratio, and it decides whether the preview works.
        $cardPng   = $flierBase . $nomPath . '/card.png';
        $others = array_values(array_filter($catList, fn($o) => (int) $o['id'] !== $id));

        // The one phase view-model for this ballot, from the nominee's own cycle.
        $phase = \AfricaGates\Services\BallotGuard::stateForCategory((int) $nom->category_id);

        // A bounced paid-vote checkout, read-and-cleared. PaidVoteController stashes
        // the buyer's quantity/email/name here rather than in the query string (see
        // its rememberOrder()), so the form they are sent back to arrives filled in
        // instead of blank — the difference between one retry and an abandoned sale.
        $retry = $this->takePaidRetry();
        $paidNotice = self::PAID_REASONS[trim((string) ($req->getQueryParams()['paid'] ?? ''))] ?? null;
        // A wallet purchase says its own sentence (what it cost, the reference, or why
        // not), kept for exactly the one page load it was written for.
        if (($req->getQueryParams()['paid'] ?? '') === 'wallet' && isset($_SESSION['wallet_vote_notice'])) {
            $paidNotice = (string) $_SESSION['wallet_vote_notice'];
            unset($_SESSION['wallet_vote_notice']);
        }
        // Refused by a voting extension's paid cutoff: the sentence carries both dates.
        if (($req->getQueryParams()['paid'] ?? '') === 'extended') {
            $paidNotice = \AfricaGates\Services\VotingExtension::paidClosedSentence((int) $nom->cycle_id)
                ?? self::PAID_REASONS['cutoff'];
        }
        if ($paidNotice !== null && ($retry['detail'] ?? '') !== '') {
            $paidNotice .= ' ' . $retry['detail'] . '.';
        }

        // Member voting-points context (for the redeem-a-vote control).
        $memberId      = (int) ($_SESSION['user_id'] ?? 0);
        $pointsEnabled = PointsService::enabled();
        $memberPoints  = ($memberId > 0 && $pointsEnabled) ? PointsService::balance($memberId) : 0;

        // ── Phase 5 additions (NomineePage + VoteBallot DCs) ────────────────────
        //
        // A vote this browser just confirmed: written by ApiController::castVote() only
        // after the vote counted, read and cleared here, so the inline `vote` celebration
        // is drawn as CONFIRMED by the server (Services\Celebration) and plays once. Fifteen
        // minutes, so a stale flag from yesterday's session cannot congratulate anybody.
        $castAt = (int) ($_SESSION['vote_cast'][$id] ?? 0);
        if (isset($_SESSION['vote_cast'][$id])) unset($_SESSION['vote_cast'][$id]);
        $voteConfirmed = $castAt > 0 && (time() - $castAt) < 900;
        // The moment right after a vote is when a person should feel it mattered: how many
        // people are celebrating this community's own with them (SupporterSpotlight), counted
        // fresh — they have just joined, and a cached count would leave them out.
        $cheer = null;
        if ($voteConfirmed) {
            try {
                $cheer = ['people' => (int) \AfricaGates\Services\SupporterSpotlight::build((int) $nom->cycle_id)['people'],
                          'place'  => \AfricaGates\Support\AwardCampaign::forProgramme((int) $nom->programme_id)['community']];
            } catch (\Throwable) {
                $cheer = null;
            }
        }

        // "Bring your people" (VoteRecruit). Arriving through somebody's link keeps their code
        // for this browser until a vote spends it; having voted here, this browser holds its
        // own link for this nominee and the count of people it has brought.
        $via = (string) ($req->getQueryParams()['via'] ?? '');
        if ($via !== '') \AfricaGates\Services\VoteRecruit::capture($via);
        $drive = (string) ($req->getQueryParams()['drive'] ?? '');
        if ($drive !== '') \AfricaGates\Services\Volunteer\VoterDrive::capture($drive);
        $recruit = null;
        $myCode  = (string) ($_SESSION['vote_recruit'][$id] ?? '');
        if ($myCode !== '') {
            $brought = \AfricaGates\Services\VoteRecruit::broughtByCode($myCode);
            if ($brought !== null) {
                // The link is the nominee's own short URL plus the code — short enough for the
                // QR code and for a person to read off a phone — and the share buttons are the
                // same kit every nominee gets (ShareKit), carrying this voter's link instead.
                $link = \AfricaGates\Support\SiteUrl::base($req) . '/vote/' . $nom->programme_slug . '/' . (int) $nom->id . '?via=' . rawurlencode($myCode);
                $kit  = \AfricaGates\Services\ShareKit::for(['name' => (string) $nom->name, 'category' => (string) $nom->category,
                    'programme' => (string) $nom->programme_title, 'url' => $link,
                    'community' => \AfricaGates\Support\AwardCampaign::forProgramme((int) $nom->programme_id)['community']], $link);
                $recruit = ['code' => $myCode, 'brought' => $brought, 'link' => $link, 'links' => array_slice($kit['links'], 0, 3)];
            }
        }

        // The panel's reviewed evidence, as COUNTS by kind and nothing more. The rows are
        // the judges' dossier (`visible_to_judges`); titles and links can be private, and no
        // column says a row may be published — so the page says what was reviewed, never
        // what it said (docs/handoff/PHASE-5.md, blocked question B-3).
        $evidence = [];
        try {
            foreach (DB::table('gates_nominee_evidence')->where('nominee_id', $id)->where('verified', 1)
                         ->selectRaw('kind, COUNT(*) AS n')->groupBy('kind')->get() as $e) {
                $evidence[(string) $e->kind] = (int) $e->n;
            }
        } catch (\Throwable) {}

        $nomShortlisted = isset(\AfricaGates\Services\ShortlistService::shortlistedIn((int) $nom->cycle_id)[(int) $nom->id]);

        return $this->view->render($res, 'pages/vote-nominee.twig', [
            // "Vote for Ada", never "Vote for Chief" or "Vote for Glow" (Name::addressAs).
            'first'            => \AfricaGates\Support\Name::addressAs((string) $nom->name),
            'terms'            => \AfricaGates\Services\AwardTerms::current((int) $nom->programme_id),
            'paid_sentence'    => \AfricaGates\Services\PaidVoteCopy::sentence((int) $nom->programme_id, (int) $nom->cycle_id),
            'vote_confirmed'   => $voteConfirmed,
            // The voter's own "what your votes unlock" link, keyed on who just voted (OfferLink).
            'offer_url'        => \AfricaGates\Services\OfferLink::path((string) $nom->programme_slug, $voteConfirmed ? (string) ($_SESSION['vote_key'] ?? '') : ''),
            'cheer'            => $cheer,
            'recruit'          => $recruit,
            // The nominee's thank-you to their backers, once it is final (sent, or past its
            // edit window): a draft is theirs until then (Services\NomineeThanks).
            'thanks'           => (static function (int $id) {
                $t = \AfricaGates\Services\NomineeThanks::forNominee($id);
                return $t && !\AfricaGates\Services\NomineeThanks::editable($t) ? $t : null;
            })((int) $nom->id),
            // Their voice thank-you and their own updates (NomineeVoice, NomineeUpdates).
            'voice'            => \AfricaGates\Services\NomineeVoice::forNominee((int) $nom->id),
            'updates'          => \AfricaGates\Services\NomineeUpdates::shown((int) $nom->id),
            'evidence'         => $evidence,
            // Every photograph, the portrait first: the page used to draw photo_path alone.
            'photos'           => \AfricaGates\Services\NomineePortrait::gallery((int) $nom->id, (string) ($nom->photo_path ?? '')),
            'shortlisted'      => $nomShortlisted,
            'result_url'       => '/results/' . \AfricaGates\Services\PublicResults::slug((int) $nom->category_id, (string) $nom->category),
            'tier_prices'      => array_map(static fn (array $t): array => $t + ['price' => PaidVoteService::price((int) $t['qty'])],
                                            array_values(array_filter(PaidVoteService::tiers(), static fn (array $t): bool => (int) $t['qty'] <= PaidVoteService::maxQtyForOrder()))),
            'edition_label'    => \AfricaGates\Support\EditionName::label(DB::table('gates_award_cycles')->where('id', (int) $nom->cycle_id)->first() ?? []),
            // A link pasted into WhatsApp previews this title and description. Where the award
            // has named its community, both lead with it (Support\AwardCampaign).
            'page_title'       => (($own = \AfricaGates\Support\AwardCampaign::celebrating(\AfricaGates\Support\AwardCampaign::forProgramme((int) $nom->programme_id), (string) $nom->name)) !== ''
                                    ? $own : 'Vote for ' . $nom->name) . ' — Africa GATES',
            'meta_description' => ($own !== '' ? $own . '. ' : '') . 'Cast your verified vote for ' . $nom->name . ' in ' . $nom->category . ' — Africa GATES, the continental Cultural Power Index.',
            'gates_page'       => 'awards',
            'nominee'          => $nom,
            'profile'          => $profile,
            'rank'             => $rank,
            'cat_count'        => count($catList),
            // The competitive layer. A vote total on its own answers no question a
            // supporter has — whether their vote would matter, how close the race is,
            // whether the last push worked — so the page had no reason to be visited
            // twice and no reason to be shared, on a platform whose whole mechanic is
            // rallying support. Every figure is computed from real rows; where one
            // cannot be (momentum on a category with no timestamped votes, a gap when
            // the nominee leads) it comes back null and the template omits the element
            // rather than printing a zero that reads as a measurement.
            'standing'         => $standing,
            // ── WHAT WE PUT ON THIS TALLY OURSELVES ──────────────────────────
            //
            // Vote recovery mints votes on behalf of people whose code this platform
            // failed to deliver. Its doctrine lists six controls and calls none of them
            // ceremony; five were enforced in code and the sixth — "public disclosure of
            // every applied batch" — was a method nothing called, while the index stated
            // as settled fact that a batch "is disclosed publicly per nominee".
            //
            // Here, beside the number it changed, because that is the only place the
            // disclosure answers the question somebody actually has. `total` is 0 for
            // every nominee on a platform that has never run a recovery, and the template
            // omits the block entirely — a permanent "0 recovered votes" would be noise
            // on 100% of pages to be honest about 0% of them.
            'recovered'        => \AfricaGates\Services\VoteRecoveryService::disclosureFor((int) $nom->id),
            'standing_headline'=> \AfricaGates\Services\StandingsService::headline($standing),
            'standing_cta'     => \AfricaGates\Services\StandingsService::callToAction($standing),
            'flier_url'        => $nomPath . '/flier',
            'video_url'        => $nomPath . '/video',
            'others'           => array_slice($others, 0, 5),
            // Same trail the page prints above the hero. The category has no page of
            // its own, so it is a label with no `item` — a BreadcrumbList entry
            // pointing at a URL that does not exist is an invalid item, and Google
            // drops the whole trail rather than the one entry.
            'breadcrumbs'      => [
                ['label' => 'Vote', 'url' => '/vote'],
                ['label' => (string) $nom->programme_title,
                 'url'   => '/vote/' . rawurlencode((string) $nom->programme_slug)],
                ['label' => (string) $nom->category, 'url' => null],
                ['label' => (string) $nom->name,     'url' => null],
            ],
            // Person JSON-LD on the ballot. This is the page people reach by typing a
            // NOMINEE'S NAME, and it was the one content page on the site with no
            // structured data at all — the registry profile had it, the leaderboard
            // had an ItemList, and the highest-intent page of the three had nothing.
            // `category_title` is mapped from the category so Schema::person emits the
            // award line; the key names differ because that helper serves both
            // profiles and nominees.
            'schema'           => \AfricaGates\Support\Schema::person(
                [
                    'name'           => (string) $nom->name,
                    'tagline'        => (string) ($nom->tagline ?? ''),
                    'story'          => (string) ($nom->story ?? ''),
                    'organisation'   => (string) ($nom->organisation ?? ''),
                    'country_code'   => (string) ($nom->country_code ?? ''),
                    'category_title' => (string) $nom->category,
                ],
                \AfricaGates\Support\SiteUrl::base($req),
                \AfricaGates\Support\SiteUrl::base($req) . $nomPath,
                (string) ($cardPng ?? '')
            ),
            // COMPUTED phase, so a stale status column cannot present an open
            // ballot for a closed cycle.
            'phase'            => $phase,
            'voting_open'      => (bool) ($phase['is_voting_open'] ?? false),
            'paid_notice'      => $paidNotice,
            // A voting extension on this edition (VotingExtension): the public notice, and —
            // once its paid cutoff has passed — the sentence that replaces the paid option.
            'extension'        => \AfricaGates\Services\VotingExtension::notice((int) $nom->cycle_id),
            'paid_ext_closed'  => \AfricaGates\Services\VotingExtension::paidClosedSentence((int) $nom->cycle_id),
            // Repopulates the buy-votes form after a bounce. Empty on a normal visit.
            'paid_retry'       => $retry,
            'turnstile_site_key' => Env::get('TURNSTILE_SITE_KEY', ''),
            'member_points'    => $memberPoints,
            'points_per_vote'  => PointsService::pointsPerVote(),
            'can_redeem'       => $memberId > 0 && $pointsEnabled && (bool) ($phase['is_voting_open'] ?? false) && $memberPoints >= PointsService::pointsPerVote(),
            'member_logged_in' => $memberId > 0,
            'points_enabled'   => $pointsEnabled,
            'member'           => \AfricaGates\Services\UserAccountService::memberForForms(),
            // Paid voting (admin-toggleable) — the ballot leads with Buy Votes
            // when enabled; the free OTP path hides when the admin disables it.
            'paid_voting'        => PaidVoteService::enabled(),
            'paid_free_disabled' => PaidVoteService::freeVotingDisabled(),
            'vote_price'         => PaidVoteService::pricePerVote(),
            // The quantity ladder, sent WHOLE rather than as a rendered list of chips.
            // The page has to price a quantity the buyer types by hand as well as one
            // they tap, so the browser needs the same rule the server prices with — not
            // a set of pre-computed totals it can only look up. Any chip the template
            // draws comes out of this same array.
            'vote_tiers'         => PaidVoteService::tiers(),
            // The form's `max` comes from the SAME function the checkout rejects on, so
            // the page can never offer a quantity the next request refuses.
            'max_qty'            => PaidVoteService::maxQtyForOrder(),
            'pay_providers'      => (PaidVoteService::enabled() && $this->payments) ? $this->payments->enabledProviders() : [],
            // The member's community return, offered as a way to pay (WalletVotes).
            'wallet_sources'     => \AfricaGates\Services\WalletVotes::sources($memberId),
            // Supporters who ASKED to be named. Empty for every nominee until someone
            // ticks the box — the reader publishes consent, not names it happens to hold.
            'supporters'         => $supporters = \AfricaGates\Services\SupportersService::forNominee((int) $nom->id),
            'supporter_count'    => $supporterCount = \AfricaGates\Services\SupportersService::countForNominee((int) $nom->id),
            // The tail is phrased by the service, not the template: exact while the
            // number is small enough to be information, rounded to "100+" once it
            // is just a big number that changes on every reload.
            'supporters_more'    => \AfricaGates\Services\SupportersService::overflowLabel(
                                        max(0, $supporterCount - count($supporters))),
            // ── The celebration ──────────────────────────────────────────────
            //
            // Set only once this nominee has actually been promoted, so the whole
            // block is absent for everybody else rather than sitting there empty.
            // 'winner' and 'runner_up' are written by CycleMaterialiser at the moment
            // the standings are sealed — this READS that decision, it does not make
            // one of its own.
            'award_kind'         => in_array((string) ($nom->status ?? ''), ['winner', 'runner_up'], true)
                                        ? (string) $nom->status : '',
            // The named supporters again, but more of them. The wall further down is
            // a taste; on the day somebody wins, the roll of honour is the page.
            'roll_of_honour'     => in_array((string) ($nom->status ?? ''), ['winner', 'runner_up'], true)
                                        ? \AfricaGates\Services\SupporterHonours::rollOfHonour((int) $nom->id)
                                        : [],
            // Everybody behind them, named or not — the honest size of the crowd,
            // which the consented list always understates.
            'backer_count'       => \AfricaGates\Services\CommunityReturnService::supporterCount((int) $nom->id),
            // ── What voters SAID ─────────────────────────────────────────────
            //
            // Approved messages only, resolved against each voter's naming consent
            // inside the service — the template never sees a name it is not allowed
            // to print. The count is of approved messages too, so the "showing the N
            // most recent" line cannot imply held-back messages that a reader would
            // then wonder about.
            // Six on the ballot, not twelve. This is a VOTING page — the wall is
            // evidence that other people showed up, and past about half a dozen it
            // becomes a scroll between the reader and the ballot they came for. The
            // rest live at their own URL.
            'messages'           => \AfricaGates\Services\VoteMessageService::wall((int) $nom->id, 6),
            'first_backers'      => \AfricaGates\Services\SupporterSpotlight::firstBackers((int) $nom->id),
            'poster_url'         => $nomPath . '/poster',
            'voice_url'          => $nomPath . '/voice',
            // The answer to "hear how they are doing" (NomineeMilestones::follow).
            'follow_msg'         => (static function () { $f = $_SESSION['vote_follow'] ?? null; unset($_SESSION['vote_follow']); return $f; })(),
            'message_count'      => \AfricaGates\Services\VoteMessageService::countForNominee((int) $nom->id),
            'messages_url'       => $nomPath . '/messages',
            // "and 40 more" used to lead nowhere. Every one of those people ticked a
            // box asking to be named in public.
            'supporters_url'     => $nomPath . '/supporters',
            // The ceiling comes from the service, not the textarea: the server
            // truncates at this number, so a `maxlength` that disagreed would either
            // silently cut a voter's words or promise room that does not exist.
            'msg_max'            => \AfricaGates\Services\VoteMessageService::MAX_LEN,
        ] + array_filter([
            // Social card: the nominee's own photo when they have one.
            /**
             * A PURPOSE-BUILT CARD IS THE LINK PREVIEW.
             *
             * Two steps got here. It was originally the nominee's bare photo, which
             * previews as a face with no context — no name, no category, no standing, no
             * reason to tap — on what is the single highest-intent share on the platform.
             * That was replaced by the flier, which persuades but is 4:5, and Facebook and
             * LinkedIn crop an og:image to 1.91:1 while WhatsApp crops to roughly square.
             * So the bottom third went missing in every preview, and the bottom third of
             * the flier is the vote URL, the rally copy and the jury footnote.
             *
             * {@see \AfricaGates\Services\FlierService::ogCard()} is 1200×630 — the shape
             * the platforms want — with the face in a column beside the text instead of
             * behind it. The flier is unchanged and remains what a nominee downloads.
             *
             * It has to be a RASTER at a URL: no major chat app renders SVG in a preview
             * and a crawler cannot run JavaScript.
             */
            'og_image'      => $cardPng,
            'og_image_w'    => \AfricaGates\Services\FlierService::OG_W,
            'og_image_h'    => \AfricaGates\Services\FlierService::OG_H,
            'og_image_type' => 'image/png',
            'og_image_alt'  => 'Vote for ' . $nom->name . ' in ' . $nom->category
                . ' — ' . \AfricaGates\Services\StandingsService::headline($standing),

        ], fn($v) => $v !== null));
    }
}
