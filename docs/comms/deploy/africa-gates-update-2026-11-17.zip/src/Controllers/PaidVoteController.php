<?php
declare(strict_types=1);

namespace AfricaGates\Controllers;

use AfricaGates\Support\Env;
use AfricaGates\Support\OptionalColumn;
use AfricaGates\Services\CheckoutThrottle;
use AfricaGates\Services\PaidVoteService;
use AfricaGates\Services\PaymentService;
use AfricaGates\Services\RateLimitService;
use Illuminate\Database\Capsule\Manager as DB;
use Illuminate\Support\Carbon;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\Views\Twig;

/**
 * Paid voting checkout — mirrors DonationController's audited shape exactly:
 *
 *   1. POST /vote/paid/start — validate, price SERVER-SIDE, write a PENDING
 *      gates_donations row (tier 'paid-vote', bonus_votes = qty,
 *      intent_nominee_id = target), leave for the gateway.
 *   2. Gateway → GET /vote/paid/callback — server-to-server re-verify, the
 *      idempotent status flip, then PaidVoteService::mint() (also idempotent;
 *      the /pay/webhook path mints too, whichever lands first wins).
 *   3. GET /vote/paid/success — read-only confirmation.
 *
 * Only live when the superadmin enables paid voting in Settings.
 */
final class PaidVoteController
{
    public function __construct(
        private readonly PaymentService    $payments,
        private readonly Twig              $view,
        private readonly ?RateLimitService $rateLimit = null,
        private readonly ?LoggerInterface  $log = null,
    ) {}

    /**
     * Absolute site base. Via SiteUrl, which falls back to the REQUEST when APP_URL is
     * unset — this used to return '' and every gateway callback URL built from it was
     * relative, which a payment provider cannot redirect a browser to. See SiteUrl.
     */
    private function base(?Request $req = null): string
    {
        return \AfricaGates\Support\SiteUrl::base($req);
    }
    private function redirect(Response $res, string $url): Response { return $res->withHeader('Location', $url)->withStatus(302); }

    /**
     * POST /vote/paid/start
     *
     * ── ORDER OF CHECKS IS PART OF THE BEHAVIOUR ─────────────────────────────
     *
     * The throttle is consulted LAST, immediately before the pending row is written.
     * It used to run second, before the nominee, the phase, the provider or the email
     * had been validated, so every rejected attempt spent a slot: a supporter who
     * mistyped their address three times had burned three of ten hourly attempts on
     * requests that never reached a gateway. Only a request that is about to create a
     * pending order and a gateway session costs anything, so only that request is
     * counted. See {@see CheckoutThrottle} for why the caps themselves changed.
     *
     * And a refusal is never a dead end: the buyer's quantity, email and name are
     * flashed back so the re-rendered ballot arrives filled in, with the reason and —
     * when it is a throttle — when to try again.
     */
    public function start(Request $req, Response $res): Response
    {
        $b         = (array)$req->getParsedBody();
        $provider  = strtolower(trim((string)($b['provider'] ?? '')));
        $email     = strtolower(trim((string)($b['email'] ?? '')));
        // Title-cased on the way in. This name is PUBLISHED — it appears on the
        // nominee's supporters list and on the receipt — and buyers type it into a
        // phone at checkout, so it arrives as often in block capitals as not.
        $name      = \AfricaGates\Support\Name::title((string)($b['name'] ?? ''));
        $nomineeId = (int)($b['nominee_id'] ?? 0);
        // CONSENT TO BE NAMED PUBLICLY = the buyer typed a name.
        //
        // The field is optional and the ballot says plainly what filling it in does
        // ("Shown on … public supporters list … leave it blank to give anonymously"),
        // so a second tickbox would be the same question asked twice.
        //
        // This still cannot be inferred at READ time from `donor_name` being non-empty,
        // which is why the flag is stored. Orders taken before the ballot said any of
        // this have names typed under a label that named no audience; reading consent
        // off those rows would publish every one of them retroactively. The column
        // defaults to 0, so only orders placed from here on can carry a yes.
        $showName  = $name !== '';
        // NOT clamped. `min(MAX_QTY, …)` silently reduced an over-large request, so a
        // supporter who asked for 5,000 votes was charged for 1,000 and told nothing —
        // they found out by looking at the tally. An over-large order is now refused with
        // the actual maximum, which is a conversation the buyer can act on.
        $qty       = max(1, (int)($b['qty'] ?? 1));
        $maxQty    = PaidVoteService::maxQtyForOrder();

        // Back to the nominee's ballot with a reason chip on any failure.
        $nominee = $nomineeId > 0 ? DB::table('gates_nominees')->where('id', $nomineeId)->first() : null;
        $backUrl = $this->ballotUrl($nominee, $req);
        $bail    = function (string $why, string $detail = '') use ($res, $backUrl, $qty, $email, $name): Response {
            $this->rememberOrder($qty, $email, $name, $detail);
            return $this->redirect($res, $backUrl . (str_contains($backUrl, '?') ? '&' : '?') . 'paid=' . urlencode($why));
        };

        if (!PaidVoteService::enabled())                                     return $bail('off');
        // Allowlist + merge check, matching every other vote path. The old
        // denylist-of-one accepted rejected/withdrawn nominees and merged-away
        // duplicates, i.e. took money for votes on a nominee the public pages
        // no longer show and whose tally is no longer read.
        if (!$nominee
            || !in_array((string)$nominee->status, ['approved', 'winner', 'runner_up'], true)
            || !empty($nominee->merged_into ?? null))                         return $bail('nominee');
        if (!$this->votingOpenFor($nominee))                                 return $bail('closed');
        // ── DO NOT SELL INTO THE CLOSING BELL ────────────────────────────────
        // A payment started in the last minutes cannot reliably reach a bank and
        // back before the ballot shuts, and taking money we might not be able to
        // honour is the whole problem. Refusing here is a sentence the buyer can
        // act on; a mint refused four minutes later is money gone and nothing to
        // show for it. Free OTP voting is untouched and runs to the bell.
        if (!PaidVoteService::checkoutOpenFor((int) $nominee->category_id)) {
            // Stopped by a voting extension's paid cutoff: say THAT, with both dates
            // (VotingExtension::paidClosedSentence), not the closing-bell sentence.
            return $bail(\AfricaGates\Services\VotingExtension::paidClosedFor((int) $nominee->category_id) ? 'extended' : 'cutoff');
        }
        // Paying from the member's wallet (WalletVotes) rather than a gateway: the same
        // checks above and below, with the account's own address for the terms record.
        $fromWallet = str_starts_with($provider, 'wallet:');
        if ($fromWallet) {
            $acct = \AfricaGates\Services\UserAccountService::memberForForms();
            $email = strtolower(trim((string) ($acct['email'] ?? '')));
        } elseif (!$this->payments->isEnabled($provider))                    return $bail('unavailable');
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL))     return $bail('email');
        // The award's terms, where it has published any (Phase 5, §8.3, AwardTerms): asked
        // before the gateway is, and recorded at the moment of the act — the buyer ticked it
        // before paying, whatever the gateway then does.
        $termsProgramme = (int) (DB::table('gates_award_categories as c')
            ->join('gates_award_cycles as cy', 'cy.id', '=', 'c.cycle_id')
            ->where('c.id', (int) $nominee->category_id)->value('cy.programme_id') ?? 0);
        if ($termsProgramme > 0 && \AfricaGates\Services\AwardTerms::required($termsProgramme)) {
            if (empty($b['accept_terms']))                                    return $bail('terms');
            \AfricaGates\Services\AwardTerms::accept($termsProgramme, \AfricaGates\Services\AwardTerms::KIND_PAID_VOTE, $email, $nomineeId);
        }
        if ($qty > $maxQty) {
            return $bail('toomany', number_format($maxQty) . ' votes');
        }

        if ($fromWallet) {
            $r = \AfricaGates\Services\WalletVotes::buy((int) ($_SESSION['user_id'] ?? 0), substr($provider, 7), $nomineeId, $qty, $showName);
            // The whole sentence, not a reason code: it carries the figures (what is left,
            // what it cost, the reference), which a fixed chip cannot.
            $_SESSION['wallet_vote_notice'] = (string) $r['message'];
            if (!$r['ok']) $this->rememberOrder($qty, $email, $name, '');
            return $this->redirect($res, $backUrl . (str_contains($backUrl, '?') ? '&' : '?') . 'paid=wallet');
        }

        $gate = (new CheckoutThrottle($this->rateLimit))->allow($req, 'paid_vote');
        if (!$gate['ok']) {
            return $bail('rate', CheckoutThrottle::retryPhrase((int) $gate['retry_after']));
        }

        // Price is ALWAYS computed server-side from the admin's settings.
        $amount    = PaidVoteService::price($qty);
        $reference = 'AFG-PVOTE-' . bin2hex(random_bytes(6));
        // ONE timestamp for both `created_at` and the checkout deadline derived from
        // it. Calling Carbon::now() twice can straddle a second boundary, and a
        // deadline computed from a different instant than the row it lives on is a
        // discrepancy that only ever shows up in the logs of a real incident.
        $placedAt  = Carbon::now();
        try {
            // `show_name` is DROPPED when the database has not been migrated yet.
            //
            // Not belt and braces — a fix for a total outage. Writing the column
            // unconditionally threw on every deployment whose migrations had not been
            // applied, the catch below turned that into a generic error chip, and paid
            // voting stopped working with nothing on the page saying why. On this
            // platform a pulled-but-not-yet-migrated database is a normal state.
            //
            // Losing the buyer's naming preference costs them a line on a supporters
            // list. Losing this INSERT costs them the ability to pay at all.
            DB::table('gates_donations')->insert(OptionalColumn::filter('gates_donations', [
                'donor_name'        => $name !== '' ? mb_substr($name, 0, 120) : 'Supporter',
                'donor_email'       => $email,
                'donor_phone'       => null,
                'donor_location'    => null,
                'amount_naira'      => $amount,
                'tier'              => 'paid-vote',
                'bonus_votes'       => $qty,
                'votes_used'        => 0,
                'intent_nominee_id' => $nomineeId,
                'payment_ref'       => $reference,
                'status'            => 'pending',
                // WHICH gateway took the money. Dropped on an unmigrated database
                // like `show_name`. Without it the reconciler asks every gateway
                // about every reference, and a refund has to GUESS where to send
                // money — see PaymentReconciler::providersFor.
                'provider'          => $provider,
                // Stored on the ORDER, not applied yet: the vote does not exist until
                // the gateway confirms, and PaidVoteService::mint() copies this onto it.
                'show_name'         => $showName ? 1 : 0,
                'created_at'        => $placedAt->toDateTimeString(),
                // WHEN THIS CHECKOUT DIES — the earlier of our patience and the bell.
                //
                // Recorded rather than re-derived, because the close time is editable
                // and every reader must get the same answer months later. Without it a
                // checkout started near the bell stayed "in flight" for two hours past
                // the ballot, and a payment landing in that stretch was confirmed for
                // votes that could no longer be delivered — which is where the refunds
                // come from. See PaidVoteService::checkoutDeadline().
                'checkout_expires_at' => PaidVoteService::checkoutDeadline(
                    (int) $nominee->category_id, $placedAt)?->toDateTimeString(),
            ], ['show_name', 'provider', 'checkout_expires_at']));
        } catch (\Throwable $e) {
            $this->log?->error('[paid-vote] could not persist pending order', ['err' => $e->getMessage()]);
            return $bail('error');
        }

        // Started from somebody's "bring your people" link: held by reference and credited
        // when the votes are minted, never now — an abandoned checkout brought nobody.
        \AfricaGates\Services\VoteRecruit::pend($reference, \AfricaGates\Services\VoteRecruit::fromSession());

        // ── THE BUYER'S MESSAGE, HELD IN THE SESSION ─────────────────────────
        //
        // Not written to the database here, and that is the whole design. A message
        // stored before the gateway confirms is an open door: start a checkout,
        // abandon it, and the words are already published on a real person's page —
        // with no payment, no OTP and nothing to rate-limit against. So it waits in
        // the session, keyed to this reference, and `confirm()` stores it only once the
        // money is verified. See rememberMessage()/storeMessage().
        //
        // If the session does not survive the trip to the bank and back, nothing is
        // lost that matters: the receipt page carries the same box.
        $this->rememberMessage($reference, (string) ($b['message'] ?? ''));

        $callbackUrl = $this->base($req) . '/vote/paid/callback?provider=' . urlencode($provider) . '&ref=' . urlencode($reference);
        $init = $this->payments->initialize($provider, $amount, $email, $reference, $callbackUrl, [
            'reference' => $reference, 'purpose' => 'paid-vote',
        ]);
        if (!$init['ok'] || empty($init['checkout_url'])) {
            DB::table('gates_donations')->where('payment_ref', $reference)->where('status', 'pending')->update(['status' => 'failed']);
            // The provider's OWN message, at error level. It was discarded, so an
            // operator debugging "checkout does not start" had the reason
            // ("Invalid key", "Currency not supported", a TLS failure) thrown away and
            // only a generic chip on the page to work from.
            $this->log?->error('[paid-vote] gateway would not start a transaction', [
                'ref' => $reference, 'provider' => $provider, 'reason' => (string) ($init['message'] ?? ''),
            ]);
            return $bail('start');
        }

        // NOT a 302 straight to the gateway. That redirect is part of a form submission,
        // so `form-action` governs it — and a policy without the gateway hosts blocks the
        // POST in the browser before any PHP runs at all. See GatewayHandoff.
        return $this->redirect($res, \AfricaGates\Services\GatewayHandoff::remember(
            $reference, (string) $init['checkout_url'], $this->base($req) . '/vote/paid/redirect', $provider
        ));
    }

    /**
     * Flash the buyer's order back so the re-rendered ballot arrives filled in.
     *
     * In the SESSION, not the query string. The obvious implementation appends
     * `&email=…&name=…` to the redirect, which writes the supporter's address and
     * their real name into the server access log, into any proxy log in front of it,
     * and into the `Referer` of every asset the ballot then loads — including the
     * third-party ad and font hosts the page embeds. A retry convenience is not worth
     * leaking PII to a CDN.
     *
     * Read once by {@see \AfricaGates\Controllers\VoteController::nomineeBallot()},
     * which clears it, so a later visit to the same ballot is not pre-filled from a
     * checkout the supporter has since abandoned.
     */
    /**
     * Hold the buyer's message of support until the payment is verified.
     *
     * In the SESSION rather than the database, for the reason given at the call site:
     * writing it at checkout would publish words paid for by a checkout that was never
     * completed. Keyed by reference so a buyer who starts two orders cannot have the
     * first one's message attached to the second.
     */
    private function rememberMessage(string $reference, string $body): void
    {
        if (!isset($_SESSION) || !is_array($_SESSION)) return;
        $body = trim($body);
        if ($body === '') { unset($_SESSION['paid_vote_message']); return; }
        $_SESSION['paid_vote_message'] = [
            'ref'  => $reference,
            // Capped here as well as in the service: no reason to carry more than can
            // ever be stored across a gateway round trip.
            'body' => mb_substr($body, 0, \AfricaGates\Services\VoteMessageService::MAX_LEN),
        ];
    }

    /**
     * Store the held message, now that the money has arrived.
     *
     * Read-and-clear, so a second callback (a refresh, the gateway's webhook arriving
     * behind the browser) cannot re-post it — and so a later, unrelated order does not
     * inherit it.
     *
     * NEVER throws. This runs on the payment confirmation path; a message that cannot
     * be saved must not turn a successful purchase into an error page.
     *
     * @return bool whether something was stored, for the receipt page's benefit
     */
    private function storeMessage(string $reference, object $don): bool
    {
        if (!isset($_SESSION) || !is_array($_SESSION)) return false;
        $held = $_SESSION['paid_vote_message'] ?? null;
        unset($_SESSION['paid_vote_message']);
        if (!is_array($held) || ($held['ref'] ?? '') !== $reference) return false;

        try {
            $r = \AfricaGates\Services\VoteMessageService::submit([
                'nominee_id'  => (int) ($don->intent_nominee_id ?? 0),
                'donation_id' => (int) $don->id,
                // From the ORDER, never from a request parameter — the same rule the
                // API endpoint follows. See VoteMessageController::post().
                'email'       => (string) $don->donor_email,
                'body'        => (string) $held['body'],
                'name'        => (string) ($don->donor_name ?? ''),
                'show_name'   => (int) ($don->show_name ?? 0) === 1,
                'source'      => 'paid',
            ]);
            return (bool) ($r['ok'] ?? false);
        } catch (\Throwable $e) {
            $this->log?->error('[paid-vote] could not store the buyer\'s message', [
                'ref' => $reference, 'err' => $e->getMessage(),
            ]);
            return false;
        }
    }

    private function rememberOrder(int $qty, string $email, string $name, string $detail): void
    {
        // `$_SESSION` as an array, not session_status() — the convention everywhere
        // else in this codebase, and the only version that is testable.
        if (!isset($_SESSION) || !is_array($_SESSION)) return;
        $_SESSION['paid_vote_retry'] = [
            'qty'    => $qty,
            'email'  => $email,
            'name'   => $name,
            'detail' => $detail,
            // `name` carries the consent with it: the field IS the choice, so repopulating
            // the field repopulates the decision. Nothing extra to flash.
        ];
    }

    /**
     * GET /vote/paid/redirect — the same-origin hop to the gateway.
     *
     * Exists so the browser never sees a form submission that ends on a third-party host.
     * See {@see \AfricaGates\Services\GatewayHandoff} for the console message that made
     * this necessary and why `form-action 'self'` blocked every paid vote.
     *
     * A missing or expired handoff is not an error state worth a stack trace: the buyer is
     * simply returned to the ballot with a reason, because the most likely cause is a
     * back-button or a bookmarked handoff URL.
     */
    public function handoff(Request $req, Response $res): Response
    {
        $reference = \AfricaGates\Services\GatewayHandoff::reference($req);
        $url = \AfricaGates\Services\GatewayHandoff::take($reference);
        if ($url === null) {
            return $this->redirect($res, $this->base($req) . '/vote?paid=start');
        }

        return \AfricaGates\Services\GatewayHandoff::page(
            $res, $url, \AfricaGates\Services\GatewayHandoff::providerLabel(), $reference
        );
    }

    /** GET /vote/paid/callback — browser return; re-verified server-to-server. */
    public function callback(Request $req, Response $res): Response
    {
        $q         = $req->getQueryParams();
        $reference = trim((string)($q['ref'] ?? $q['reference'] ?? $q['tx_ref'] ?? ''));
        $provider  = strtolower(trim((string)($q['provider'] ?? '')));
        if ($reference === '' || !$this->payments->isKnownProvider($provider)) {
            return $this->redirect($res, $this->base($req) . '/vote?paid=error');
        }
        $don = DB::table('gates_donations')->where('payment_ref', $reference)->where('tier', 'paid-vote')->first();
        if (!$don) return $this->redirect($res, $this->base($req) . '/vote?paid=error');

        $result = $this->confirm($provider, $reference, $don);
        if ($result === 'confirmed' || $result === 'already') {
            try { PaidVoteService::mint((int)$don->id); }
            catch (\Throwable $e) { $this->log?->error('[paid-vote] mint on callback failed', ['ref' => $reference, 'err' => $e->getMessage()]); }
            // The buyer's receipt. AFTER mint, because which of the two receipts they
            // get is decided by whether the votes actually landed — and this path used
            // to send nothing at all, so someone who paid for votes had no record that
            // the purchase existed. Claimed once per order, so the gateway webhook
            // arriving a second later does not send a duplicate. Never throws.
            \AfricaGates\Services\CheckoutMailer::receipt((int) $don->id);
            // AFTER the mint, so a message is never attached to a purchase whose votes
            // were refused. Re-read from the database: `$don` predates the confirm and
            // does not carry donor_name/show_name as they now stand.
            $stored = $this->storeMessage($reference,
                DB::table('gates_donations')->where('id', $don->id)->first() ?? $don);
            return $this->redirect($res, $this->base($req) . '/vote/paid/success?ref=' . urlencode($reference)
                . ($stored ? '&msg=1' : ''));
        }
        return $this->redirect($res, $this->base($req) . '/vote?paid=failed');
    }

    /**
     * GET /vote/paid/success — read-only confirmation.
     *
     * THREE states, not two. `confirmed` used to mean only "the donation row is
     * confirmed", and the page then told the buyer their votes were "already in
     * the public tally" and a receipt was on its way. Since mint() gained its
     * phase gate that can be false: a payment initiated while voting was open but
     * CONFIRMED after it closed is deliberately refused, leaving votes_used = 0.
     * The old copy would have thanked that buyer for votes that do not exist.
     *
     * So the truthful question is whether the votes MINTED, not whether the money
     * arrived — and the "paid but not minted" case gets its own honest state
     * telling the buyer they are owed a refund, with the reference they need to
     * claim it. `cycles:audit` reports the same population to the operator, so
     * both sides of that conversation see the same fact.
     */
    public function success(Request $req, Response $res): Response
    {
        $reference = trim((string)($req->getQueryParams()['ref'] ?? ''));
        $don = $reference !== ''
            ? DB::table('gates_donations')->where('payment_ref', $reference)->where('tier', 'paid-vote')->where('status', 'confirmed')->first()
            : null;
        $nominee = ($don && !empty($don->intent_nominee_id))
            ? DB::table('gates_nominees')->where('id', (int)$don->intent_nominee_id)->first()
            : null;

        // votes_used is the mint claim flag: 0 on a confirmed order means the
        // votes were never added. Same signal ops queries for a refund.
        $minted = $don !== null && (int)$don->votes_used > 0;
        // Their votes landed: this browser now holds their own "bring your people" link for the
        // nominee (VoteRecruit), shown at the top of the ballot when they go back to it. The
        // same link reaches them in the thank-you email, for when this is another device.
        if ($minted && $nominee && trim((string)($don->donor_email ?? '')) !== '') {
            $mine = \AfricaGates\Services\VoteRecruit::forVoter(\AfricaGates\Services\VoteService::voterHash((string)$don->donor_email), (int)$nominee->id);
            if ($mine && isset($_SESSION) && is_array($_SESSION)) $_SESSION['vote_recruit'][(int)$nominee->id] = $mine['code'];
        }

        // A reason to have voted, and to vote again: what THIS order did for the award's named
        // beneficiary, and where this person now stands on the award's own benefits ladder
        // (Support\AwardCampaign). Both only where the host has set them, and only once the
        // votes have landed — a ladder read against an unminted order counts money that may
        // be refunded.
        $own = null;
        if ($minted && $nominee && trim((string) ($don->donor_email ?? '')) !== '') {
            try {
                $campaign = \AfricaGates\Support\AwardCampaign::forProgramme($this->programmeIdFor($nominee));
                $cycleId  = (int) DB::table('gates_award_categories')->where('id', (int) $nominee->category_id)->value('cycle_id');
                $price    = PaidVoteService::pricePerVote();
                $share    = $campaign['beneficiary'] !== '' && $campaign['share_pct'] > 0
                    ? (int) $don->bonus_votes * intdiv($price * $campaign['share_pct'], 100) : 0;
                // Where they now stand among everybody backing their own in this edition — the
                // thing a supporter most wants to hear right after giving, and true: the same
                // count of people, the same order, the board uses.
                $me       = \AfricaGates\Services\SupporterSpotlight::standingOf($cycleId, (string) $don->donor_email);
                $total    = $me['votes'];
                $own = ['share' => $share, 'beneficiary' => $campaign['beneficiary'], 'total' => $total,
                        'rank' => $me['rank'], 'people' => $me['people'], 'place' => $campaign['community'],
                        'standing' => \AfricaGates\Support\AwardCampaign::standing($campaign, $total),
                        'ladder' => $campaign['ladder'] !== [], 'note' => $campaign['ladder_note'],
                        // Their own "what your votes unlock" link (OfferLink), on the address they paid from.
                        'offer_url' => ($slug = (string) (DB::table('gates_award_programmes')->where('id', $this->programmeIdFor($nominee))->where('is_active', 1)->value('slug') ?? '')) !== ''
                            ? \AfricaGates\Services\OfferLink::path($slug, \AfricaGates\Services\VoteService::voterHash((string) $don->donor_email)) : ''];
            } catch (\Throwable) {
                $own = null;
            }
        }

        return $this->view->render($res, 'pages/vote-paid-success.twig', [
            'own'              => $own,
            'page_title'       => $minted ? 'Votes confirmed — Africa GATES' : 'Payment received — Africa GATES',
            'meta_description' => 'Your paid votes have been recorded — thank you for backing African excellence.',
            'gates_page'       => 'awards',
            'confirmed'        => $don !== null,
            'minted'           => $minted,
            'votes'            => $don ? (int)$don->bonus_votes : 0,
            'amount_naira'     => $don ? (int)$don->amount_naira : 0,
            'nominee_name'     => $nominee ? (string)$nominee->name : '',
            'ballot_url'       => $this->ballotUrl($nominee, $req),
            // The supporter's "I backed" card (Services\BackedCard), as a PATH: the ballot URL is
            // absolute on the configured site address, which an image on this page must not
            // depend on (it drew broken wherever the two differ).
            'card_url'         => $nominee && $minted ? \AfricaGates\Support\NomineeUrl::path((int) $nominee->id) . '/backed.png' : '',
            'reference'        => $reference,
            // The jury share, read from the engine rather than typed into the
            // template. This page is the first thing a supporter sees after paying,
            // so a figure here that contradicts /integrity contradicts it at the
            // least forgivable moment.
            'judge_pct'        => (function (): int {
                try { return (int) round((new \AfricaGates\Services\RuleEngine())->weights()['judge'] * 100); }
                catch (\Throwable) { return (int) round(\AfricaGates\Services\RuleEngine::DEFAULTS['judge_weight'] * 100); }
            })(),
            // For the /vote hub's per-device ballot tracker. Only meaningful when
            // votes actually landed, so the template gates the write on `minted`.
            'programme_id'     => $this->programmeIdFor($nominee),
            // The message-of-support box's ceiling, from the service that enforces it
            // rather than typed into the template — a `maxlength` that disagreed with
            // the server would silently cut a buyer's words after they sent them.
            'msg_max'          => \AfricaGates\Services\VoteMessageService::MAX_LEN,
            // Whether the message they wrote on the ballot was already stored by the
            // callback. Set from the query string the callback appends AND verified
            // against the database, so a hand-typed ?msg=1 cannot claim a message that
            // does not exist — and so the receipt does not offer an empty box to
            // somebody who has already written one.
            'msg_posted'       => ($req->getQueryParams()['msg'] ?? '') === '1'
                                  && $don !== null
                                  && \AfricaGates\Services\VoteMessageService::existsForDonation((int) $don->id),
        ]);
    }

    /** The programme a nominee's category belongs to, or 0 when unresolvable. */
    private function programmeIdFor(?object $nominee): int
    {
        if (!$nominee) return 0;
        try {
            return (int) DB::table('gates_award_categories as cat')
                ->join('gates_award_cycles as c', 'c.id', '=', 'cat.cycle_id')
                ->where('cat.id', (int)$nominee->category_id)
                ->value('c.programme_id');
        } catch (\Throwable) {
            return 0;
        }
    }

    /** Idempotent confirm — mirrors DonationController/PaymentController. */
    private function confirm(string $provider, string $reference, object $don): string
    {
        if (($don->status ?? '') === 'confirmed') return 'already';
        $v = $this->payments->verify($provider, $reference);
        if (!$v['ok'] || ($v['status'] ?? '') !== 'success') {
            if (($v['status'] ?? '') === 'failed') {
                DB::table('gates_donations')->where('payment_ref', $reference)->where('status', 'pending')->update(['status' => 'failed']);
            }
            return 'failed';
        }
        // SHORT of the price never confirms. OVER it does — see the long note in
        // PaymentController::confirmByReference for why `!==` was the wrong test and
        // what one gateway-dashboard toggle used to do to every payment on the site.
        $paid     = (int) ($v['amount'] ?? 0);
        $owed     = (int) $don->amount_naira;
        $currency = strtoupper(trim((string) ($v['currency'] ?? '')));
        if ($paid < $owed || !($currency === '' || $currency === 'NGN')) {
            $this->log?->warning('[paid-vote] amount/currency mismatch — refusing to confirm', [
                'ref' => $reference, 'expected' => $owed, 'verified' => $paid, 'currency' => $currency,
            ]);
            return 'failed';
        }
        if ($paid > $owed) {
            $this->log?->warning('[paid-vote] OVERPAID — confirming anyway',
                ['ref' => $reference, 'expected' => $owed, 'paid' => $paid, 'surplus' => $paid - $owed]);
        }
        // `confirmed_at` — the moment money arrived, which nothing recorded before.
        // Dropped on an unmigrated database, like `show_name` and `provider`.
        $changed = DB::table('gates_donations')->where('payment_ref', $reference)->where('status', 'pending')
            ->update(OptionalColumn::filter('gates_donations', [
                'status'       => 'confirmed',
                'confirmed_at' => Carbon::now()->toDateTimeString(),
            ], ['confirmed_at']));

        // ── WRITE DOWN THE GATEWAY'S OWN NUMBERS ─────────────────────────────
        //
        // This is the only moment we hold them. They are what the supporter has in front
        // of them — Paystack's receipt shows its transaction id, not the AFG- reference we
        // minted — and every lookup surface on this platform used to match only ours, so
        // "the number on my receipt" was the one thing guaranteed to fail. See
        // PaymentLookup. Never blocks the confirmation: the money has arrived either way.
        \AfricaGates\Services\PaymentLookup::remember('gates_donations', (int) $don->id, $v);

        return $changed > 0 ? 'confirmed' : 'already';
    }

    /**
     * True when the nominee's cycle is in its voting window, decided by the
     * shared COMPUTED-phase guard rather than this controller's own reading of
     * the stored status column.
     */
    private function votingOpenFor(object $nominee): bool
    {
        return PaidVoteService::votingOpenFor((int) $nominee->category_id);
    }

    /**
     * The nominee's ballot URL (or the vote index as a safe fallback).
     *
     * Delegates to the shared {@see \AfricaGates\Support\NomineeUrl}. This method built
     * the URL itself, VoteController built it a second way, and transactional email now
     * needs it a third time — three copies of one URL shape is how the link in a
     * buyer's receipt ends up differing from the link on the page they came from.
     */
    private function ballotUrl(?object $nominee, ?Request $req = null): string
    {
        if (!$nominee) return $this->base($req) . '/vote';
        return \AfricaGates\Support\NomineeUrl::ballot((int) $nominee->id, $this->base($req));
    }
}
