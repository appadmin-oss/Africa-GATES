# Phase 0: Read, install, reconnoitre (no UI code)

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Understand the rules and the repo before touching templates. The output is a written map, not code.

## Before you start (read in this order)
- `README.md` (this bundle)
- `REFERENCE.md`, all of it
- `skill/app-ux-standards/SKILL.md`: install it as a Claude Code skill
- `design-notes/DESIGN-NOTES.md`
- The repo’s own `CLAUDE.md` (the SQLite/MySQL traps)

## Build (in order)
1. Install the skill.
2. For every row of the gaps table below, find the real code (service, route, template, table). Record EXISTS (with path), PARTIAL (with what is missing) or MISSING.
3. List every current route that renders a page, and map each one to its DC (use the phase files).
4. Confirm the stack facts: CSP nonce helper, asset() helper, the Alpine version, the article.twig macros, gee.js entry points and supportDesk().
5. Write `docs/handoff/GAPS.md` in the repo. Don’t change any other file.

## Spec for this phase (verbatim, authoritative)

### 15. Gaps (verify in the repo; if missing, build end to end)

| Feature | Expected status |
|---|---|
| Recognitions + verified issuers | NEW |
| Award terms versioning + acceptance | NEW |
| Coming-soon awards + notify (double opt-in) | NEW |
| Overall edition winner + top 3 | NEW (compute) |
| Wall of recognition | NEW |
| Search API + palette | NEW |
| DisplayReading persistence + first-paint apply | NEW |
| Quick settings sheet + first-visit language prompt | NEW |
| Celebrations (partial + boot + seen keys) | NEW; the JS/CSS is supplied |
| Gee restyle + privacy note + `--ag-bottom-ui` clearance | EXTEND `gee.js` |
| Pulse post kinds + guest banner | EXTEND |
| Event tier colours, glow, states, waitlist | EXTEND `events/detail.twig` |
| Shop multi-select filters, load more, restock alerts, order page | EXTEND |
| Status by country, maintenance, subscribe | NEW |
| Two-link mega nav | EXTEND `nav.twig` |
| Nominee race, ballot, winner state | EXISTS; restyle |

---

## Done when
- [ ] `docs/handoff/GAPS.md` exists, covering every gaps row with a status and paths.
- [ ] A route → DC map is included.
- [ ] No template, CSS or JS was changed.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
