# Phase 3: Gee (guide + help desk) and celebrations

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Build the two shared behaviours that later pages call.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-3/`: 7 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- **Snippets:** `snippets/` (see `snippets/README.md`). Start from the ones marked for Phase 3.
- `design/Gee.dc.html`: mode guide/support × signedIn true/false × layout phone/desktop. Click **Check now** and walk the whole flow: work card → result → No → handoff → Pass to a person.
- `design/Celebration.dc.html`: every kind × full/inline × phone/desktop
- `skill/app-ux-standards/SKILL.md` §24
- Repo: `gee.css`, `gee.js`, `pages/support-assistant.twig`

## Build (in order)
1. Restyle Gee guide mode (§7.7).
2. Build Gee help-desk mode (§8.22), wired to the real `supportDesk()` actions.
3. Add the `/support/assistant` 301.
4. Expose `window.AGGee.open()`.
5. Copy `celebration.js` and `celebration.css` **verbatim**, then build `partials/celebration.twig` and the boot code.

## Spec for this phase (verbatim, authoritative)

### 7.7 Gee (`design/Gee.dc.html` → restyle the existing `gee.css`/`gee.js`)

- On every page **except Pulse**.
- **FAB:** a dark pill "G · Ask Gee" on desktop; icon only on phone.
- **Clearance (strict):**
  - The FAB is always ≥16px above any bottom-fixed element.
  - Bottom offset: tab bar 96px · sticky buy/give/vote/ticket bars 108px · no bar 40px.
  - Implement as `bottom: calc(var(--ag-bottom-ui, 0px) + 16px + env(safe-area-inset-bottom))`. Each fixed bar sets `--ag-bottom-ui` on `<body>` when it mounts and clears it when it unmounts.
- **Panel:** 400×580 on desktop. On phone it fills the page inset by 12px, and its height is capped to the page (never `vh`).
- **Panel order:**
  1. Header ("Online").
  2. **Dismissible privacy note:** retention period + "Don't share card numbers or passwords" + policy link.
  3. Greeting and 4 starter chips.
  4. Bubbles.
  5. Help-link chips.
  6. Pill composer.
  7. Footer: "Gee can make mistakes · Privacy · Talk to a person".
- Support mode shows the amber dot.

### 8.22 Gee help desk (support mode) replaces `/support/assistant` (strict)
- **Redirects:** `/support/assistant` (and `?q=`) returns **301 → `/help?gee=support`** (keeping `q`). The Help Centre opens Gee on load when `gee=support` is present. Programmatic API: `window.AGGee.open({mode:'support', q})`. The design prop `openSignal` stands in for this.
- **Where support mode is used:** the Help Centre, "No, ask Gee", payment-failure pages, and Status "Get help". Everywhere else Gee is `guide`.
- **The launcher in support mode** is a pill labelled "Help desk" with an **amber dot** on the G avatar.
- **Header:**
  - a 34px G avatar with an amber status dot, "Gee · Help desk" and "Usually fixes payments in a minute";
  - a tickets icon button with a live dot when a person has replied;
  - new conversation and close buttons;
  - a hairline under the header.
- **Empty state, in this order:**
  1. Greeting "Hi {first}. What’s gone wrong?" (Playfair 25) + one sentence.
  2. **From your account** (signed in): up to 2 rows inside one bordered card:
     - the most recent unresolved payment: amount · method · amber "Pending for N min", with the mono reference on its own line (`white-space:nowrap`; never break a reference) · an ink **Check now** pill;
     - the newest open ticket: "#id · subject" · "A person replied N ago" · chevron.

     The data comes from the member's own payments and tickets (the route already knows `can_see_payments`).
  3. **Signed out:** a reference card instead. The label reads "Have a reference? I’ll check it now." The input uses mono 16px, auto-uppercase and no spellcheck, with a **Check** button, then "It’s in your payment email or SMS. Sign in to see everything you’ve paid."
  4. **Quick fixes:** a 2×2 grid of 84px tiles (tinted 32px icon + label): Check a payment · Resend a receipt · Code didn’t arrive · A result looks wrong.
  5. The privacy note (dismissible; kept 30 days; never share card numbers or passwords).
- **Resolution flow** (Check now / Check / "Check a payment"):
  1. The member's bubble.
  2. A **live work card** (`role="status"`) with 3 steps: "Found your order {ref}" → "Asking {provider} about the payment" → "Adding your votes". Each step shows pending (grey ring), active (spinning ring) or done (green check). These are the real steps from `supportDesk()`; don't fake the timing in production.
  3. The **result card** (`#f4faf4` with a `#cfe6ce` border): "Fixed. {n} votes added to {nominee}."; a receipt table (Amount · Paid · Receipt sent to); "See the race" + "View receipt".
  4. "Did that fix it?" Yes / No. **No** opens the handoff card.
- **Handoff card:**
  - "A person can take it from here" · "A person usually replies within 2 hours" (from the SLA setting) · **Pass this to a person**.
  - Once passed, it reads "Ticket #{id} opened", followed by "This conversation is attached… We’ll email {email}".
  - "Talk to a person" in the footer opens the same card at any time.
- **Composer:** an attach-screenshot button (36px paperclip; images only, ≤5MB) + the input "Describe the problem, or paste a reference" + send. Footer: "A person sees every unresolved message · Talk to a person".
- **Keep every behaviour of `support-assistant.twig`:**
  - the `supportDesk()` store;
  - the `ai_on` fallback: the status line becomes "Answering from the written help. A person still gets your message.";
  - the tickets link;
  - the sign-in note;
  - the reference "forget" control.
- `/support` ("Reach a person", appeal form, tickets) stays a page.
- **Reduced motion:** no spinning; the active step shows a static half ring.

### 7.8 Celebration (`design/Celebration.dc.html` + `assets/celebration/*`: SHIP VERBATIM)

The full spec is skill §24; these are the build rules.

- **Kinds and moments:** `win` (the winner's nominee page and the overall result) · `vote` (vote done) · `nominate` (nomination sent) · `give` (gift done) · `ticket` (ticket confirmed).
- **Sizes:**
  - `full`: phone stacked, desktop a 2-column split with the stage (360×320) on the left and left-aligned text on the right.
  - `inline`: a card (88px stage + text, two 48px buttons) that replaces a form in place.
- **Partial:** `partials/celebration.twig`, args `kind, size, layout, kicker, title, sub, stats[], primary, secondary, seen_key`.
  - Copy markup and styles exactly from the DC.
  - The stage is an empty `<div class="ag-cel__stage" data-agc-kind data-agc-size data-agc-seen-key>`.
  - Stats render their **final** value server-side in `<b data-agc-count="18402">18,402</b>`.
- **Boot:** in the page module, nonce'd.
  ```js
  document.querySelectorAll('[data-agc-kind]').forEach(el => {
    const card = el.closest('.ag-cel');
    const fx = AGCelebrate.mount(el, { kind: el.dataset.agcKind, size: el.dataset.agcSize,
      layout: matchMedia('(min-width:1024px)').matches ? 'desktop' : 'phone', seenKey: el.dataset.agcSeenKey });
    AGCelebrate.countUp(card, fx.calm);
    card.querySelector('[data-agc-replay]')?.addEventListener('click', () => { fx.replay(); AGCelebrate.countUp(card); });
  });
  ```
- **`seen_key`** = `{kind}-{edition_slug}-{subject_slug}`, plus `-{user_id}` when signed in. The first view plays the burst; later views go straight to the ambient loop with final numbers.
- **Headline defaults** (used when the route passes no title): "Your vote is in" · "{First} won." · "Nomination sent" · "Thank you for giving" · "You’re going".
- **Buttons (primary / secondary):**

| Kind | Primary | Secondary |
|---|---|---|
| vote | Share your vote | Vote in another category |
| win | Share the win | See how it was decided |
| nominate | Let them know | Nominate someone else |
| give | Share the campaign | See where it goes |
| ticket | Add to calendar | View ticket |

- **Never celebrate** saving drafts, settings, sign-in, add to cart or subscribe.

### 9.3 Celebrations

Follow skill §24 exactly: the choreography, the ambient loop, pausing off-screen, play-once and reduced motion. The ambient budget is ≤40 nodes in the DOM and ≤12 visible at once (skill §24.6). The shipped file measures win 39, nominate 15–17 and the others ≤8, which passes; don't "optimise" it. The shipped JS already implements all of this. **Your job is the markup, the boot code and the `seen_key`.**

## Done when
- [ ] A real stuck payment in staging is fixed through the help-desk flow, with a recording attached.
- [ ] Gee clears every fixed bar by ≥16px on every page type (measured).
- [ ] The celebration files are byte-identical to the bundle (diff attached).
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
