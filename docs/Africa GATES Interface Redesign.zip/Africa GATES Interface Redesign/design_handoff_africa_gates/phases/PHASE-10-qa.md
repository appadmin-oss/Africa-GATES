# Phase 10: Final QA sweep

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Prove the whole site meets the contract before release.

## Build (in order)
1. Run REFERENCE §17 on **every** route at 360, 390, 834, 1024 and 1440, in LTR and RTL.
2. Run an accessibility audit (axe + manual) and fix every violation.
3. Lighthouse mobile: ≥90 performance and 100 accessibility on Home, Vote, Event detail and Shop item.
4. Check the redirects: `/activity` and `/support/assistant`.
5. Measure Gee clearance on every page with a fixed bar.
6. Check reduced motion on every animated surface.

## Done when
- [ ] `docs/handoff/QA.md` lists every route with pass/fail and evidence.
- [ ] Zero open deviations.
