# Phase 9: Documents, Help Centre, blog, status

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Every long-form and support surface.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-9/`: 14 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- `design/DocPage.dc.html`: doc = integrity / philosophy / terms / privacy / cookies / programme-terms × layouts
- `design/HelpCentre.dc.html` (index / article; search "code")
- `design/BlogPage.dc.html`, `design/StatusPageV2.dc.html`
- Repo: `partials/article.twig`, `pages/integrity.twig`, `pages/legal.twig`, `pages/help*.twig`

## Build (in order)
1. Restyle the `article.twig` macros to DocPage (one template family).
2. Help Centre + article; every "Ask Gee" opens the Gee help desk in place.
3. Blog.
4. Status.

## Spec for this phase (verbatim, authoritative)

### 8.20 Documents: Integrity Centre, Philosophy, Terms, Privacy, Cookies, Award terms (`DocPage.dc.html`, prop `doc`)
One template for every long document: `pages/integrity.twig`, `pages/philosophy.twig`, `pages/legal.twig` and `pages/programme-terms.twig`, all via the existing `partials/article.twig` macros. Restyle the macros; don't fork them.

- **Colour tier 0** (as the twigs declare):
  - no green anywhere in the document;
  - links are ink, underlined (1px, offset 3px, 2px on hover);
  - the focus ring is ink;
  - toggles on /cookies are the only control and use ink when on.
- **Masthead:** eyebrow (13.5/600) → Playfair title (32/40/46) → subtitle → standfirst (16.5–18) → byline (author · version · updated · read time) → tools (Listen, which toggles to Pause · Cite or Download; 44px outlined pills).
- **Layout:**
  - **≥1200:** `240px | ≤680px | 280px`, gap 48. Left: sticky contents with the current section highlighted (white pill, 700) + "Also filed here". Right: sticky **Live settings** (integrity) or **This document** (legal).
  - **1024–1199:** 2 columns; the right card moves inline under the masthead.
  - **Tablet and phone:** a single column (max 680). A sticky 48px **Contents bar** ("Contents · 02 · The score") opens a bottom-sheet contents list with 52px rows. A 2px ink reading-progress bar sits at the top of `<main>`.
- **Sections:** a numbered Playfair h2 (22/26), `scroll-margin-top:64px`. Body 16/17, line-height 1.7, max 680.
- **Tables:** real `<table>` on tablet and desktop. **On phone, each row becomes a stacked card row** (label + value on one line, description below). There's no horizontal scroll.
- **Blocks:** asides are white hairline cards (no coloured left border). The can/cannot columns use ✓/✕ in ink circles. "Further reading" is an ink link list. The handover card links to the next document (integrity ↔ philosophy).
- **Figures:** every figure (45/55, quorum, bonus cap, return threshold, risk bands) comes from RuleEngine route variables, never typed. Keep the twig's `default()` guards.
- **/cookies:** the "Your choices, right now" control card sits **above** the body (Essential locked "Always on"; Preferences, Analytics, Marketing switches). Honour GPC.
- **Cite block:** the citation text + Copy citation + Download/Share + the effective-date note. The footer carries the contact email and a Help Centre link.

### 8.21 Help Centre: `HelpCentre.dc.html` → `pages/help.twig`, `pages/help-article.twig`, `pages/help-category.twig`
- **Keep:**
  - "How can we help?" / "Results for “q”";
  - the "Who is asking" audience nav (`?for=`);
  - the 4 "Most people are here for one of these" answers;
  - the category directory with article links + "All N in {category}";
  - search results with "Clear search";
  - on the article page: breadcrumb, copy-link, body blocks and steps, "Did this answer it?", prev/next, related, "This is a general answer", siblings.
- **Search:** a sticky 52px (phone) / 58px (desktop, centred, max 680) search + audience chips. Results are a white list; below them a "Gee can probably help" card with **Ask Gee about this** (green) + "Browse every topic".
- **Top answers:** 76px cards with a 44px tinted icon tile, 2 columns on tablet and desktop. The directory is a 3/2/1-column grid of category cards (36px icon, name, count, 3 × 48px links, "All N").
- **"Still stuck" band:** "An article can’t look up your payment. Gee can." + **Ask Gee** + "Contact a person" (→ `/support`).
- **Article:** "No, ask Gee" and "Ask Gee about my case" **open Gee in help-desk mode in place**, seeded with the article title (`?q=`). They never navigate.

### 8.14 Blog: `BlogPage.dc.html` → `pages/blog/*`

An editorial index + article with Listen, a reading-progress bar, `read_minutes` and people tags.

### 8.15 Status: `StatusPageV2.dc.html` → `pages/status.twig`

- Keep every rule in the current twig header comment.
- **Add:** a live incident timeline, a maintenance banner, status by country, and subscribe. Subscribe is shown only when an email sender is configured.

## Done when
- [ ] No green anywhere in a tier-0 document (grep + screenshot).
- [ ] On phone, the contents sheet jumps to each section with the heading visible under the bar.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
