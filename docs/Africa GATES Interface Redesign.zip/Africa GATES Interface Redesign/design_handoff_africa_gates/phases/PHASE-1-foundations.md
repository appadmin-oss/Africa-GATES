# Phase 1: Tokens, page shell, base components

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Create the single source of truth for colour, type, spacing, motion and the page shell, so every later phase only composes.

## Before you start (read in this order)
- **Snippets:** `snippets/` (see `snippets/README.md`). Start from the ones marked for Phase 1.
- REFERENCE §4, §5, §6 (all), §9.4, §9.5, §13
- `design/ShopPage.dc.html` and `design/DocPage.dc.html`, to see the tokens in context

## Build (in order)
1. `public/assets/css/tokens.css`: every §6 token as a CSS custom property, **exact names and values**.
2. The page shell: `html,body{margin:0;height:100%;overflow:hidden}` plus root `height:100dvh;max-height:100%`. Only `<main>` scrolls (it has `position:relative`), and `--ag-bottom-ui` is on `<body>`.
3. Base component CSS (BEM): button (primary green, secondary outlined, text), chip (outlined; selected = 2px ink border), input and search field (≥16px, 48–54px), card, list row (56px), bottom sheet (grabber, scrim), switch, segmented control, skeleton.
4. A scroll-state helper (one passive listener on `<main>`, `scrolled` threshold 8) and a collapsing-search controller (the states below).
5. Reduced-motion and focus-visible rules (3px outline).
6. A dev-only style page `/_dev/ui` showing every component in every state.

## Spec for this phase (verbatim, authoritative)

### 9.1 Scroll-linked chrome

- The page's `<main>` is the scroll container. Use one passive scroll listener per page and compute booleans only (`scrolled = scrollTop > 8`).
- **Never** call `setState`/re-render on every scroll event. Compare with the previous boolean first.

### 9.2 Collapsing sticky search + filters (Awards index; reused by Discover, Shop, Events)

- **The sticky block:** `top:0`, ground background, 10px vertical padding at rest and 8px once scrolled. A 1px `--ag-line` hairline shows only when `scrollTop > 8`.
- **Search row:** always in the DOM.
  - Wrapper: `display:grid; grid-template-rows: 1fr ↔ 0fr`, with an inner `min-height:0; overflow:hidden`.
  - Animate `grid-template-rows` + `margin-bottom` (10 ↔ 0) over 260ms `--ag-ease`, and opacity over 200ms ease.
  - **Never** use `display:none` for this.
- **Search button:** at the start of the chip row, always in the DOM. Width 0 ↔ 44px (40 on desktop), `margin-inline-end` −8 ↔ 0, opacity; same easing.
- **States:**
  1. `scrollTop ≤ 8`: open, button hidden.
  2. Scrolled with an empty query: collapsed, button shown.
  3. The button opens the row and records `y0`.
  4. While open with an empty query, scrolling more than 24px from `y0` collapses it.
  5. A non-empty query keeps it open.
  6. Back at the top resets to state 1.
- **Accessibility:**
  - Collapsed = `aria-hidden="true"` + input `tabindex="-1"`; the hidden button mirrors this.
  - The button moves focus to the input. Esc collapses the row and returns focus to the button.
  - Reduced motion = instant swap.

## Done when
- [ ] `/_dev/ui` renders every component and state; screenshots at 390 and 1440.
- [ ] Contrast is checked for every text/background pair used.
- [ ] There are no hard-coded hex values outside `tokens.css`.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
