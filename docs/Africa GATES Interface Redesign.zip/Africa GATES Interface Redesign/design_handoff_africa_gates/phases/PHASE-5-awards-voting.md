# Phase 5: Awards, voting, nominee, results

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
The whole edition lifecycle: award → edition → vote → nominee → results.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-5/`: 18 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- REFERENCE §12 (voting rules) and §11 (cycles, terms)
- `design/AwardsPage.dc.html` (index / detail / soon)
- `design/VoteHub.dc.html`, `design/VotePage.dc.html`
- `design/NomineePage.dc.html` + `VoteBallot.dc.html` (phase voting/won; signedIn)
- `design/ResultsPage.dc.html`

## Build (in order)
1. Migrations: `edition_number`, `gates_award_terms` + acceptance.
2. Awards index, detail (Overview | Award details | Terms) and coming-soon.
3. Vote hub → edition vote page → nominee page + ballot → the won state with a celebration.
4. Results with the overall edition winner first.

## Spec for this phase (verbatim, authoritative)

### 8.3 Awards: `AwardsPage.dc.html` → `awards/index.twig`, `awards/programme.twig`

- **`view=index`:**
  - A collapsing sticky search (§9.2).
  - Phase chips with mono counts (All, Nominations, Voting, Judging, Results, Coming soon), each with a coloured phase dot.
  - A card grid.
- **`view=detail`:** tabs **Overview | Award details | Terms**.
  - Award details is the long, platform-generated description.
  - Terms is versioned, shows the effective date and a changelog, and requires acceptance before nominating or voting.
  - The hierarchy is Organisation → Award → Edition → Category.
- **`view=soon`:** a "Coming soon" page for an award with no open phase, with a notify-me email (double opt-in).

### 8.4 Vote hub: `VoteHub.dc.html` → `pages/vote.twig`

- **Layout:** a light list, a live total with a pulsing dot, filters, and rows with live counts. Desktop has a rail.
- **Phone:**
  - The filter chip row is sticky at `top:0` (10px vertical padding, 44px chips).
  - **Rows are 88px** (60px thumb · text · count · 18px chevron) and the whole row is the target. There's no inline Vote button.

### 8.5 Vote (edition): `VotePage.dc.html` → `pages/vote-program.twig`

- **Phone:**
  - Child AppBar ("Kenya Creative Economy Awards" / "11th Edition · voting open").
  - **Light hero:** a 16:9 radius-18 photo with a white "Voting open" chip (live dot, `--ag-live-ink` text).
  - A countdown card: white, radius 16, three 42px-min tiles on ground (mono 17 value + 10.5 label), with `role="timer"`.
  - The meta line.
  - Full-width tabs **Vote | About the award**, 52px.
  - A sticky category chip row under the tabs (`top:52px`).
  - Race cards: headline, rank, live count, gap to the leader, bar versus the leader. Vote buttons are 44px.
  - **Bottom bar** (`rgba(251,251,250,.96)` + blur 14, padding `12 16 28`): "N of 6 categories voted" + a 5px progress bar + **Review votes** (52px, radius 16; disabled `--ag-tint` / `--ag-mute` until ≥1 vote). Gee moves to 108px.
  - The side "ballot" rail is hidden on phone.
- **Desktop:** the dark hero band + a two-column layout with a sticky ballot rail.
- **About the award tab:** host, what it celebrates, editions, who can vote, support rules, judges, the edition timeline (Nominations → Community voting → **Judging after voting** → Results & ceremony), weighting, FAQ and the ceremony link.

### 8.6 Nominee: `NomineePage.dc.html` + `VoteBallot.dc.html` → `pages/vote-nominee.twig`

- **Order:** race block → "Support for {first}" → reviewed evidence (read-only) → other nominees.
- **Ballot** (the existing flow, restyled): points → paid contribution tiers (outlined chips) → "or vote free" → **name, phone, email and message all required; the public display name is optional** → rules → email OTP → done (inline `vote` celebration).
- **`phase=won`:** a full `win` celebration + a roll of honour (named supporters only) replace the ballot. The bottom bar reads "See the result".
- **Signed out:** "Have points? Sign in to redeem them. You can still vote without an account."

### 8.7 Results: `ResultsPage.dc.html` → `pages/results.twig`

- **The overall edition winner comes first,** with the top 3. Then the summary. Then the category winners.
- An edition that is still running shows "Overall winner announced {date}" in the same slot.

## Done when
- [ ] An edition can be walked end to end in staging: nominate → vote (free and paid) → judging → results.
- [ ] Nothing says buy, cart or pay for votes.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
