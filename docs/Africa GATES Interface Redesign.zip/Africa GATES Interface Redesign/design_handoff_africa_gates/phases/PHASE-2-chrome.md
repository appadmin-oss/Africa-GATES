# Phase 2: Shared chrome: header, app bar, tab bar, menu, reading settings, language, cookies

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Every page gets the same navigation and settings on every breakpoint.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-2/`: 3 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- **Snippets:** `snippets/` (see `snippets/README.md`). Start from the ones marked for Phase 2.
- REFERENCE §6.7, §10, §13
- `design/SiteHeader.dc.html` (signedIn true/false; open Participate, Explore, Aa, language)
- `design/AppBar.dc.html` (root and child)
- `design/MobileMenu.dc.html` (signedIn true/false; open Display & reading and Language)
- `design/DisplayReading.dc.html`, `design/CookieConsent.dc.html`
- Repo: `partials/nav.twig`, footer, cookie partial

## Build (in order)
1. SiteHeader + mega panels + the search palette (the `/search` JSON endpoint).
2. AppBar partial (root and child) with scroll fill and quick settings.
3. The phone tab bar + the Menu bottom sheet with pushed sub-views.
4. The DisplayReading store (`ag-a11y`) + the first-paint `<head>` script.
5. Language switching, including RTL.
6. The cookie banner, preferences and GPC.

## Spec for this phase (verbatim, authoritative)

### 7.1 SiteHeader: tablet and desktop (`design/SiteHeader.dc.html` → `partials/nav.twig`)

- **Bar:** 64px tall, horizontal padding 28, `rgba(251,251,250,.9)` + `backdrop-filter: blur(16px)`, bottom hairline `--ag-line`. The hairline is removed while a mega panel is open.
- **Left:** logo, a 32×32 mark in a white 9px-radius tile with a 1px `--ag-line-2` border and 3px padding. Beside it, the wordmark "Africa" (Playfair 700 16) over "GATES" (DM Sans 700 9.5, letter-spacing .26em, `--ag-green`).
- **Two top links only:** **Participate ▾** and **Explore ▾**. Each is a 40px button with 14px horizontal padding, DM Sans 600 14.5. Open state: `--ag-tint` background and the chevron rotated 180°.
- **Right:**
  - A toolbar pill: 40px tall, 1px `--ag-line`, white, radius 999, containing Search (icon, 40px) | divider | **Aa** (Display & reading) | divider | 🌐 + language code.
  - Then the avatar (40px, ink) when signed in, or an outlined **"Sign in"** pill (40px, 1px ink) when signed out.
  - On shop routes, or whenever the cart isn't empty, a cart **icon button with a count badge** comes before the avatar. There's no subtotal text.
- **Mega panel:**
  - Hangs from the bar with no gap or border; full width, `rgba(251,251,250,.9)` + blur 18.
  - Bottom radii 24, the mega shadow (§6.5), inner max-width 1180 and padding `26px 40px 30px`.
  - A 3-column grid of items. Each is: a 40px tinted icon tile (radius 12) + title (DM Sans 700 15) + one line (13, `--ag-soft`). Rows are 12px padded, radius 14, hover `--ag-ground`. **There are no pictures.**
  - **Participate:** Nominate, Vote, Awards, Giving, Register a profile, Integrity Center.
  - **Explore:** Discover, Pulse, Events, Legacy Vault, Blog, Status.
- **Behaviour:**
  - Click toggles. Opening one panel closes the other panels and popovers. Esc closes; so does clicking the transparent scrim below the panel.
  - `aria-expanded`/`aria-haspopup`, `role="menu"`, focus returns to the trigger.
  - Keep the repo's `data-ag-mega*` controller.
- **Search palette:** opened by the Search icon or `/`.
  - 680px wide, 84px from the top, scrim behind.
  - Input → scope chips (All, People, Awards, Events, Pages) → grouped results (≤6 per group). The empty query shows trending, open-now and coming-soon.
  - Keyboard hints. ↑↓ / Enter / Esc. Focus is trapped and restored.
  - Data from `GET /search?q=&scope=` (JSON).
- **Aa and language popovers:** 360px (Aa) / 210px (language), `top:70px`, radius 20 / 16, popover shadow.

### 7.2 AppBar: phone (`design/AppBar.dc.html` → `partials/app-bar.twig`)

- **root** (Home, Discover, Nominate, Vote hub, Events, Awards index, Pulse):
  - A 52px row: 44px search icon · centred small title (DM Sans 700 17, opacity 0 at rest) · avatar button (34px in a 44px target, aria-label "Account, language and display").
  - Below that, a large-title row: Playfair 700 26–32, 16px gutter.
- **child** (VotePage, Nominee, Results, Award detail/soon): 44px back · title (DM Sans 700 16, truncates) + sub (12.5 `--ag-soft`, truncates) · 44px share. The height is 56.
- **Scroll:**
  - When `<main>.scrollTop > 8`, the bar fills to `--ag-bar` with a bottom hairline, the large title hides and the small title fades in (200ms).
  - Scrolling back to ≤8 reverses it.
  - Reduced motion: instant swap.
- **Avatar → Quick settings bottom sheet:**
  - profile row + Profile link;
  - text size (3-step segmented control, 48px);
  - High contrast and Reduce motion switches;
  - language chips, each written in its own language with a `lang` attribute, scrolling horizontally;
  - "All display & reading settings" → DisplayReading;
  - a 52px **Done** button.

  It writes to the same `ag-a11y` store. **There are no separate Aa or language buttons in the phone app bar.**
- **First-visit language prompt:**
  - Shown when `navigator.languages[0]` is a supported non-English language and there's no `ag_lang` cookie.
  - One dismissible row under the root AppBar, written in that language (e.g. "Voir Africa GATES en français ?" · Oui · Keep English).
  - Either answer sets the cookie. It hides on scroll and never returns.

### 7.3 Phone tab bar

- 5 tabs: **Home · Discover · Nominate · Pulse · Menu**.
- Each tab is ≥52px tall with a 23px icon over a 12px 600 label. Active = `--ag-green` icon and label.
- Background `--ag-bar` with a top hairline, bottom padding 22 plus the safe area.
- **Flow pages** (vote, checkout, event detail, nominee, product) have **no tab bar**: they have a back button and a bottom action bar.

### 7.4 Phone Menu (`design/MobileMenu.dc.html`)

- **The sheet:**
  - Bottom sheet from `top:52px`, radius 24 on top, a 38×5 grabber in `#c9c4b8`, a scrim of `rgba(16,41,44,.32)` and the sheet shadow. Background `--ag-ground`.
  - Header grid `44px 1fr 44px`: back (sub-views only) · centred title (700 16.5) · close (a 30px `--ag-tint` circle inside a 44px target).
- **Main view order:**
  1. Profile card: 52px avatar, name 700 17, "View your profile", and a points figure on the right. When signed out, a join card with a 50px ink "Sign in or join" button.
  2. 4 quick tiles in a grid: Nominate, Vote, Awards, Events. Each has a 44px tinted icon (radius 14) over a 13px 600 label, in a white radius-18 tile.
  3. **Explore** list: Discover, Pulse, Giving, Shop, Legacy Vault, Blog, Register.
  4. **Settings** list: Display & reading → pushed sub-view, showing the current value; Language → pushed radio list, with names in their own language and English below; Notifications (signed in).
  5. **Help** list: Help Centre, Integrity Center, Status (a live dot + "Working").
  6. Legal links, **Sign out** (`--ag-error` text, signed in only) and the wordmark line.
- **Lists:** white, radius 18. Rows are 56px with a 34px tinted icon tile (radius 10), label 500 16, a chevron in `#b3b9ba` and separators in `#eeece6`.
- **Sub-views push inside the sheet.** There are no accordions.

### 7.5 DisplayReading (`design/DisplayReading.dc.html`)

- **Controls:** text size (100/125/150% of root), high contrast, easy-read font (Atkinson Hyperlegible), line spacing 1.8, underline links, reduce motion, data saver (no auto images or video), read pages aloud (adds Listen), language.
- **Persistence:** `localStorage["ag-a11y"]` (JSON) plus the member profile when signed in.
- **Applying it:** as classes on `<html>` (`ag-t125`, `ag-hc`, `ag-easy`, `ag-ls`, `ag-ul`, `ag-rm`, `ag-saver`). This happens in an **inline nonce'd script in `<head>` before first paint.** No flash.

### 7.6 Language

- EN, FR, AR (sets `dir="rtl"` on `<html>`), SW, PT, HA, YO, IG.
- Stored as `?lang=` + the `ag_lang` cookie. Every string goes through the translation layer. Test RTL at 390.

### 7.9 CookieConsent (`design/CookieConsent.dc.html`)

- Essential is always on, plus 3 optional categories.
- Honour Global Privacy Control (`navigator.globalPrivacyControl` → optional categories off, shown as "Respected your browser’s privacy signal").
- Re-openable from the footer and Menu → Cookies.

---

## Done when
- [ ] Every item works with keyboard only; focus returns to the trigger on close.
- [ ] Arabic at 390 mirrors correctly.
- [ ] The header shows no green button, in either signed-in state.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
