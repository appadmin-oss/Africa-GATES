# Phase 6: Leaderboard, Legacy Vault, Profile

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
The permanent record: rankings, archive and verifiable profiles.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-6/`: 10 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- REFERENCE §11 (recognitions, issuers)
- `design/Leaderboard.dc.html` (live / empty × layouts)
- `design/LegacyVault.dc.html` (index / edition; full / empty)
- `design/ProfilePage.dc.html`
- Repo: `pages/leaderboard.twig`, `pages/legacy/*`, `pages/profile.twig`

## Build (in order)
1. Leaderboard.
2. Legacy Vault index + edition.
3. Profile, with owner and visitor views and locked evidence.
4. The recognitions and issuers migrations and read models.

## Spec for this phase (verbatim, authoritative)

### 8.19 Leaderboard: `Leaderboard.dc.html` → `pages/leaderboard.twig`
- **Keep:**
  - the CPI title and the "{N} verified profiles… recomputed every 6 hours" line;
  - the podium (top 3);
  - category filter;
  - rows linking to `/registry/{slug}`, the first 40 plus "Show 20 more";
  - the note "Showing X of N · How scoring works";
  - the `aria-label` per row;
  - names wrap, never truncate.
- **Changed:**
  - The #1 card is the **gold wash**, not a dark gradient.
  - **No emoji flags:** use the ISO code in the meta line.
  - The tier appears in the meta line.
  - A movement indicator (▲ n in `--ag-green-deep` / ▼ n in `--ag-error` / – in `--ag-mute`) is carried in words in the `aria-label`.
  - Desktop columns: `56px 1fr 120px 150px 64px` (Rank · Profile · Category · Community·Judges mini split bar · CPI). The rail (280) holds search, a tier legend and the verification note.
  - "How the index works" card with the 45/55 bar (tablet and desktop).
  - Updated / next-update line.
  - Region select + category chips in a sticky row.
- **Empty (`state=empty`), deliberately minimal:** a section with no card, just hairlines above and below, centred. Padding 40/8 on phone and 56/24 on desktop.
  - The DM Sans 700 19 heading "No ranking yet".
  - One sentence: "The first board goes live 6 hours after voting opens on {date}."
  - **Nominate someone** (green, 50px; full width on phone) plus the text button "Email me when it’s live", underlined ink, which becomes "We’ll email you when it’s live".
  - No countdown, ghost podium, steps or illustration.

### 8.18 Legacy Vault: `LegacyVault.dc.html` → `pages/legacy/index.twig`, `pages/legacy/event.twig`
- **Keep:**
  - the 3 metrics (editions, awards conferred, delegates);
  - the edition cards (cover, date badge, location, title, "delegates · awards", "View edition");
  - the empty state "The vault opens after the first edition" + "See upcoming events";
  - the manifesto quote;
  - on the edition page: tagline, fact chips, recap, gallery, "All editions".
- **Index:**
  - Editions are grouped by **year** (newest first), with a count per year and "Show all N from {year}".
  - **Phone:** rows of 88px (an 84×63 thumbnail, radius 10) inside one white card. A sticky toolbar holds a 48px search, a native Region select and year chips (44px, outlined).
  - **Desktop:** a sticky 260px rail (search 44, Year radio list with counts, Region checkboxes, a sealed-record note) + a card grid (3 columns at ≥1200, 2 below).
  - Filters live in the URL (`?year=&region[]=&q=`).
- **Edition (`view=edition`):**
  - Phone: a full-bleed 4:3 cover + floating 44px back/share + a content sheet (radius 22, −22px overlap).
  - Order: breadcrumb → title → tagline → fact chips → **overall winner of the edition** (gold card, jury quote) → category winners (68px rows, 2 columns at ≥1200) → "The night" recap → gallery (4:3 tiles) → sealed record → earlier/later edition.
  - Desktop: a sticky 340px rail with the facts list, sealed record (with the mono fingerprint), every edition of this award (the current one ringed; the live one with a `--ag-live` dot) and "Cite this edition".

### 8.8 Profile: `ProfilePage.dc.html` → `pages/profile.twig`

- Owner view: Share + Edit profile in the header.
- Evidence is locked and shows a "Reviewed" state.
- Listen (read aloud).
- Recognitions come from verified issuers, and a recognition can only be withdrawn, with a public log.

## Done when
- [ ] Evidence has no edit or delete path anywhere (grep attached).
- [ ] Leaderboard names wrap and never truncate at 360px.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
