# Phase 4: Home and Discover (Activity retired)

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
The two front doors, with the Activity timeline moved into Discover.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-4/`: 6 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- **Snippets:** `snippets/` (see `snippets/README.md`). Start from the ones marked for Phase 4.
- `design/HomePageV3.dc.html`, `design/WeAreAfrica.dc.html`
- `design/DiscoverPage.dc.html`: tabs All and Live, plus the facets sheet
- Repo: `pages/home.twig`, `pages/discover.twig`, `pages/activity.twig`, `partials/find-band.twig`

## Build (in order)
1. Home, in section order.
2. Discover, including the Live tab.
3. Add the `/activity` 301 and remove Activity from the navs and the sitemap.

## Spec for this phase (verbatim, authoritative)

### 8.1 Home: `HomePageV3.dc.html` → `pages/home.twig`

- **Order:**
  1. Hero.
  2. Live stats.
  3. "Who recognises" (tabs + photo stage + record card).
  4. Wall of recognition (masonry, faded cut-off + "Show more").
  5. We Are Africa (`WeAreAfrica.dc.html`: an interactive map using `assets/countries-110m.json`).
  6. Happening now.
  7. Giving (1 featured campaign).
  8. Recognise band.
  9. Footer (the codebase footer, restyled as in the DC).
- **Phone hero:** the photo comes **first**, full-bleed (margin −16), 380px tall with radius 0, with the recognition card over it. Then the H1 (32) and the lead. Then **two stacked full-width CTAs**: "Nominate someone" (green) and "Recognise with Africa GATES" (1px ink outline), each 54px, radius 16, 16px text.
- **Desktop hero:** a two-column grid. CTAs are 50px pills side by side.
- **Wall:** max height 640px on phone until "Show more".

### 8.2 Discover: `DiscoverPage.dc.html` → `pages/discover.twig`

- The search and filters bar sticks.
- On scroll, the tabs **dock beside Filters** (skill §6b, strict).
- Facets open in a bottom sheet on phone and a side rail on desktop.

### 8.23 Activity retired → Discover (strict)
- **`/activity` → 301 → `/discover?tab=live`** (keep `q` and `literal`). Remove Activity from every nav, the footer and the sitemap. Add `/discover?tab=live` to the sitemap.
- **Discover gains a "Live" tab** (second, after All):
  - **All tab:** a compact "Happening now" block (4 newest) + "See everything".
  - **Live tab:** "Everything happening now", a `role="status"` count line, the kind chips (Everything, Results, Nominations, Voting, Events, Stories, Recognitions), the timeline, and "Show older updates".
  - **Row:** kind dot + label · `<time datetime>` relative time · title (15/600) · detail (13).
  - The **"Understood as"** line (chips + "Search these words literally instead") and the **Literal** line ("Let the search interpret it") come from activity.twig.
  - Also from activity.twig: the partial-sources warning "Some activity sources are unavailable on this deployment ({n} of 7 responded)".
  - The search field is Discover’s own (the site find-band); there is no second field.
- Keep activity.twig's a11y rules:
  - `aria-activedescendant` for the live combobox;
  - the live region on the status line only, **never** on the list;
  - every item is a real link.

## Done when
- [ ] `/activity?q=x` lands on `/discover?tab=live&q=x`.
- [ ] The Live status line announces the count; the list itself is never a live region.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
