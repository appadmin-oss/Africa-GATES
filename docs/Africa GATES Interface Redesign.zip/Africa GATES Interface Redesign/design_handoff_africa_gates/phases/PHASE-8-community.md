# Phase 8: Pulse, nominate, sign in

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
How people join, nominate and talk.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-8/`: 6 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- `design/PulsePage.dc.html` (signedIn)
- `design/NominateHub.dc.html`, `design/NominationFlow.dc.html`
- `design/SignIn.dc.html`

## Build (in order)
1. Pulse (no Gee on this page).
2. Nominate hub + flow: 2–3 categories, each reason ≥40 characters, optional evidence.
3. Passwordless sign-in with WhatsApp and voice fallbacks.

## Spec for this phase (verbatim, authoritative)

### 8.9 Pulse: `PulsePage.dc.html` → `pages/pulse.twig`

- **Desktop:** a single left rail and no top bar.
- **Post kinds:** post, photo, recognition, vote, give. 4 reactions.
- **Signed out:** a guest banner "Join Africa GATES to post, react and follow the people you care about." + an outlined "Sign in or join".
- There is no Gee on this page.

### 8.16 Nominate: `NominateHub.dc.html`, `NominationFlow.dc.html` → `pages/nominate*.twig`

- **Nominee type:** a person, an organisation or a business.
- **Categories:** 2 minimum, 3 maximum.
- **Reason:** required for **each** chosen category, **≥40 characters**, with a live counter "N/40" that turns green at 40. Error copy: "Tell us a little more (at least 40 characters)."
- **Evidence** is optional: links and files (PDF/JPG/PNG, ≤10MB each, ≤5 files).
- **No AI wording.** Category-fit analysis runs server-side for admins and judges only.
- **Done:** an inline `nominate` celebration.

### 8.17 Sign in: `SignIn.dc.html` → auth templates

Passwordless: a code by phone or email, with WhatsApp and voice-call fallbacks. Then profile basics, then interests.

---

## Done when
- [ ] Nomination validation matches the spec exactly (tests attached).
- [ ] No AI wording anywhere public (grep attached).
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
