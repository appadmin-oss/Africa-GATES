# Phase 7: Events, tickets, shop, giving

> **How to use this phase.** Work only on this phase. Read the files under *Before you start* **fully**; don't skim. Build every item under *Build* in order. Tick every *Done when* box with evidence before you stop. If something can't be matched, stop and ask; never approximate, never leave a TODO, never "simplify". Every value not written here comes from the named `.dc.html` (REFERENCE §5).

## Goal
Everything that takes money, with mobile money first.

## Before you start (read in this order)
- **Screenshots:** `screenshots/phase-7/`: 14 images at 1:1 (listed in `screenshots/INDEX.md`). Compare your build to them at the same size before you ask for review.
- `design/EventsPage.dc.html` (index / detail × every state)
- `design/TicketPage.dc.html`
- `design/ShopPage.dc.html` (every view and state)
- `design/GivingPage.dc.html`
- Repo: `events/*`, `shop/*`, giving templates

## Build (in order)
1. Events index and detail with the tier colours and glow.
2. The ticket page polish.
3. Shop index, item, cart, order and success.
4. Giving: campaign → checkout → done.

## Spec for this phase (verbatim, authoritative)

### 8.10 Events: `EventsPage.dc.html` → `pages/events.twig`, `events/detail.twig`

- **Index:**
  - Phone: root AppBar; sticky filter chips (44px).
  - Featured-event buttons are stacked full width on phone (50px, radius 14); pills on desktop.
  - Event rows are ≥76px.
- **Phone detail:**
  - A full-bleed 4:3 photo with floating 44px round buttons (back, calendar, share).
  - A content sheet (radius 22) overlapping the photo by 22px, containing: the date line (mono 12.5, `--ag-live-ink`, letter-spacing .1em), the title (Playfair 26), venue + host, and the early-bird row (48px, `--ag-gold-wash`).
- **Detail order on phone:** tickets card → About → Agenda (track filter) → Venue → Access → Good to know → Vendor call → Share/save → Earn → Livestream. There's also a fixed bottom bar: "From {lowest} · Get tickets".
- **Desktop detail:** a main column + a sticky 380px rail.
- **Tier colours:**
  - Each tier row supplies `accent`, `accent_light`, `wash`, `deep` and `glow` as CSS custom properties.
  - Picking a tier re-tints **only** the accents inside the ticket card: eyebrow, fundraising figure, selected tier border and wash, "Only N left", Apply, total and CTA.
  - **Radios stay neutral.**
- **Tier glow:**
  - `@property --ev-a` animated 0→360° over 3.2s, linear.
  - A blurred halo (inset −10px, blur 22px, opacity .55, breathing) + a 2px conic ring (`padding-box` white + `border-box` conic).
  - It replays on each pick and settles to .35. Fallback: a static gradient border.
- **States (`state`):** open · waitlist ("N waiting", 24h hold) · soldout · closed · ended (results + recording).
- **Keep every existing feature:** discount check, seats, flier, .ics + Google Calendar, earn link, appeals, stands.

### 8.11 Ticket: `TicketPage.dc.html` → `events/ticket.twig`

A light polish of the existing template. Keep all of its rules: QR + printed code always, 190×86mm print, PDF, no scannable ticket unless confirmed.

**Add:**
- a status chip (Valid · admits N / Checked in);
- a countdown in the kicker;
- tear notches and a tier-coloured dot ring;
- 2×2 actions: Wallet, Calendar, Save/print, Directions;
- a collapsed "Manage this ticket" (transfer, name change, refund);
- an offline note.

### 8.12 Shop: `ShopPage.dc.html` → `shop/index.twig`, `shop/item.twig`, `shop/order.twig`, `shop/success.twig`, `shop/alert-stopped.twig`

- **Phone markup is separate from desktop.**
- **Phone index:**
  - A sticky 56px app bar ("Shop" + cart icon with badge), then a one-line intro and a 52px search.
  - A **sticky chip toolbar** at `top:56px`: Filters (count of non-category filters) · All · categories (single-select) · a native Sort `<select>`. All controls are 44px and outlined.
  - Removable filter chips (outlined, not dark).
  - A compact gold "Frame your recognition" row, then the count.
  - A **2-column grid**: 4:5 image, a 48px quick-add hit area (34px visual), a 2-line name, "N colours · maker", price + low stock.
  - A full-width 52px "Load more" (+4 per step, "Showing X of N").
- **Phone item:**
  - A full-bleed 4:5 scroll-snap gallery (keyboard-focusable) with decorative dots and floating 44px back, share and cart buttons.
  - A content sheet (radius 22) overlapping by 22px, containing in order:
    1. maker;
    2. name (Playfair 28);
    3. price (22) + "Gives back 40%";
    4. colour: 48px targets with 36px swatches and a selected ring `0 0 0 3px #fbfbfa, 0 0 0 5px --ag-ink`;
    5. size: a 5-column grid of 52px chips; selected = 2px ink border; sold out = struck through on ground, still selectable;
    6. 44px "Size guide";
    7. quantity stepper (48px buttons);
    8. restock alert when sold out;
    9. delivery row;
    10. description;
    11. 56px accordions;
    12. perks;
    13. horizontal "You may also like".
  - **Sticky buy bar:** total + "Colour · Size · Qty N" + a 54px **Add to cart** (radius 16). It's hidden when the chosen size is sold out. Gee sits at 108px while it shows.
- **Desktop:** a 264px sticky filter rail + the grid.
  - Filters: category checkboxes with counts, named colour swatches, size chips, price min/max + Apply, In stock, Featured, Deliver-to region, display currency (cookies `ag_region` / `ag_currency`).
  - All filters live in the URL (`?c[]=&col[]=&sz[]=&min=&max=&stock=1&feat=1&sort=&q=`) and survive Back.
- **Card action:** "Add" when there are no options, "Choose size" when there are, a disabled "Sold out" when nothing is left. **Never "Add" for something that needs a choice.**
- **Add to cart never navigates.** It shows an "Added to your cart" confirmation that doesn't dismiss itself, with: thumbnail, name, options and qty, price, count and subtotal, **View cart** (outline), **Checkout** (green) and "Keep shopping".
  - Desktop: a 380px popover under the header, 24px from the right.
  - Phone: a bottom card inset 8px.
  - `role="status"`.
- **Cart drawer (desktop):** floats 12px from the edges, radius 20, light scrim.
- **Currency:** prices show in the display currency, with "Charged in Naira · ₦X" when it isn't NGN.
- **Delivery:** free over ₦50,000 or at a pickup point.
- **Order page:** reachable by reference alone and noindex. It has 5 states, payment and delivery cards, 4-step progress, the receipt and support. `notfound` doesn't reveal whether the reference exists.

### 8.13 Giving: `GivingPage.dc.html`

- Campaign → checkout (mobile money: M-Pesa, MTN MoMo, Airtel; card; bank; USSD) → done (`give` celebration).
- On phone, the Give bar is fixed at the bottom (Gee at 108px).

## Done when
- [ ] Each payment method is tested in the sandbox.
- [ ] A failed payment never removes a free vote and never takes money.
- [ ] Everything in REFERENCE §17 is attached for each screen in this phase (screenshots at 390 / 834 / 1024 / 1440 for every prop combination, RTL at 390, keyboard + screen reader notes, reduced-motion check, deviations list: target 0).

## Report back (paste into the PR description)
- Files created and changed (paths).
- Each DC prop combination → screenshot file name.
- Deviations: what, why, approved by. Target: none.
- Blocked questions (if any). Don't guess the answers.
