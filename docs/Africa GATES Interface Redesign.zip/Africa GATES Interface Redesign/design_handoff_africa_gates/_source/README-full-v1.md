# Handoff: Africa GATES platform redesign (public site, all breakpoints)

> **Precision handoff.** Every statement here is a requirement. Where a value is given, it is exact. Where it is not, the value is whatever the named `.dc.html` file renders, read from its inline style. **Nothing is approximate, and nothing is "inspired by".**

---

## 0. Order of authority (read first)

When two sources disagree, the higher one wins. Record every conflict you find in the PR.

1. **This README.** §18 lists the conflicts already resolved.
2. `skill/app-ux-standards/SKILL.md`. It governs phone UX and celebrations, and it wins over this README only on phone behaviour and §24 celebrations.
3. `design-notes/DESIGN-NOTES.md`: the standing design rules taken from the product owner's feedback.
4. The `.dc.html` design files in `design/`: exact visual values.
5. The repo's existing Twig templates. They keep every feature they already have, unless a rule above removes it.

Anything under the repo's `archive/`, and `HomePage.dc.html`, `HomePageV2.dc.html`, `StatusPage.dc.html` (v1) and `AdminAwards.dc.html`, is **not** a spec. Don't build from them.

---

## 1. Overview

Africa GATES is a continental recognition platform with these parts:

- **Awards.** Organisation → Award → Edition → Category → Nominee. Awards have versioned Terms.
- **Nominations.** 2–3 categories per nomination, a written reason for each, optional evidence.
- **Community voting.** One free vote plus optional paid contributions. Judging happens *after* voting.
- **Results.** The overall edition winner is shown first.
- **Events and ticketing.**
- **Giving, the Shop and Pulse** (a social feed).
- **Profiles.** Profiles are verifiable records: evidence is immutable once reviewed.
- **Gee.** The on-site assistant.

This redesign unifies the whole public site into one system. Each of phone, tablet and desktop is designed on purpose, not scaled.

**Stack (unchanged):** PHP 8.4 · Slim 4 · Twig 3 · vanilla JS (Alpine where already used) · nonce-based CSP · SQLite (dev) / MySQL (prod).

---

## 2. About the design files

- The `.dc.html` files in `design/` are **design references built in HTML**. Open any of them directly in a browser; `support.js` must sit next to them.
- They are **not production code.** Recreate them in the existing Twig + CSS + JS codebase using its patterns:
  - BEM classes in `public/assets/css/components/*.css`;
  - Twig partials in `templates/partials/`;
  - page templates in `templates/pages/`.
- **The one exception:** `design/assets/celebration/celebration.js` and `celebration.css` **are production code.**
  - Copy them byte-for-byte to `public/assets/js/celebration.js` and `public/assets/css/components/celebration.css`.
  - The designs execute these same files, so what you see is what ships.
  - Don't reformat them, "improve" them or port them to a framework.
- Inside a DC:
  - the markup between `<x-dc>` tags is the layout, and each element's inline `style` is the spec;
  - the `class Component` at the bottom holds demo data and the per-breakpoint values (`renderVals()` / `vals()`);
  - `{{ name }}` holes are filled from `renderVals()`.

  **All data is fake;** replace it with real queries.
- **The props matrix.** Each DC exposes props in the Tweaks panel: `layout` (phone/tablet/desktop), plus `view`, `state`, `signedIn`, `mode` and `phase` where present. **Open every combination before writing code.** Each combination is a required state. When `layout` is unset, the DC measures its own width: phone <600, tablet 600–1023, desktop ≥1024.
- **Canvas.** `design/Nominate.dc.html` is the review canvas holding every screen, grouped by turn, newest on top.
  - Turn 12 (build set) and Turn 13 (celebrations) are current.
  - Earlier turns are history; use them only to understand intent.

---

## 3. Fidelity

**High-fidelity.** Final colours, type, spacing, radii, shadows, copy, states and motion.

- **Tolerance:** ±1px on sizes and spacing, 0 on colour (exact hex), 0 on copy (exact strings, including curly apostrophes ’ and the middle dot ·), ±10ms on durations.
- **Verification viewports:** 390×844, 834×1194 and 1440×900, plus 1024×768 (the narrowest desktop) and 360×740 (a small Android).

---

## 4. Precision contract (non-negotiable)

1. **Match, don't interpret.** Keep the element order, hierarchy, copy, sizes, colours and states of the DC. Don't add, drop, rename, merge or reorder anything.
2. **If something can't be matched,** STOP: don't guess. Write the question in the PR under "Blocked", continue with other work, and never ship a placeholder.
3. **Build what's missing, end to end.** If a DC shows a feature the repo lacks, build migration (both schema files) → service → route → Twig → CSS → JS → test. No stubs and no "coming soon". §15 lists the known gaps.
4. **Reuse first.** Search the repo for an existing service, partial, route or class. Extend it; never fork it.
5. **Design each breakpoint.**
   - Phone has its **own markup branch** where the DC does, e.g. `idxPhone`/`itemPhone` in ShopPage, `phoneHero` in VotePage.
   - Never reach a layout with `zoom`, `transform: scale`, `vw`-based type or by hiding desktop blocks.
   - Switch layouts on the **measured container width** (ResizeObserver or container queries), not only on media queries, whenever a component can be embedded.
6. **Styling.**
   - Only the tokens in §6. No new colours.
   - No inline styles in Twig, **except** data-driven CSS custom properties (event tier colours, progress widths).
   - No `!important` except inside the reduced-motion blocks.
7. **Motion.** Every animation has a `prefers-reduced-motion: reduce` path that shows the final state instantly.
8. **Words.**
   - No AI wording anywhere public. "Gee" is just the name.
   - The nomination category-fit assistant is admin/judge only.
   - Never use shopping language for voting ("buy", "cart", "pay for votes").
9. **Evidence is immutable once reviewed.** There is no edit or delete route, button or API.
10. **One PR per screen.** Include every item in §17.

---

## 5. How to extract a value from a DC (method)

1. Find the element in the template. If its style reads a hole (`{{ padX }}`), look up `padX` in `renderVals()` / `vals()`. The ternary shows the phone, tablet and desktop values, e.g. `isPhone ? '16px' : '32px'`.
2. **Tablet overrides:** some DCs apply `Object.assign(o, {...})` when `L === 'tablet'`. Those values win for 600–1023.
3. `sc-if value="{{ x }}"` blocks are conditional; `x` tells you when they render. `sc-for` repeats over demo data, and the item fields show which fields the real data needs.
4. Pseudo-states are the `style-hover` / `style-active` / `style-focus` attributes on the same element.
5. **Never measure from a screenshot when the DC has the number.**

---

## 6. Design tokens

### 6.1 Colour (use these names as CSS custom properties on `:root`)

| Token | Hex | Use |
|---|---|---|
| `--ag-ink` | `#10292c` | primary text, dark UI, selected-chip border |
| `--ag-ink-2` | `#3a4a4c` | secondary text |
| `--ag-soft` | `#626a6e` | meta text, captions (4.5:1 on ground, verified) |
| `--ag-mute` | `#8b9295` | disabled text, off-switch track |
| `--ag-ground` | `#f1efe9` | page background |
| `--ag-surface` | `#ffffff` | cards, inputs |
| `--ag-bar` | `#fbfbfa` | app bars and tab bars when filled |
| `--ag-line` | `#e8e5dd` | hairlines, card borders |
| `--ag-line-2` | `#d6d4cc` | input and outlined-chip borders |
| `--ag-tint` | `#e8e5dd` | neutral fills (icon tiles, segmented track) |
| `--ag-green` | `#237b22` | **the** primary action, success |
| `--ag-green-deep` | `#1a6118` | success text |
| `--ag-green-light` | `#7fc87c` | accents on dark, sparks |
| `--ag-green-wash` | `#effaf0` | success wash |
| `--ag-green-edge` | `#cfe6ce` | success borders |
| `--ag-gold` | `#f3b416` | honour, winners |
| `--ag-gold-ink` | `#7a5600` | text on gold wash |
| `--ag-gold-wash` | `#fcf4de` / `#fff8df` | winner cards, early-bird strip |
| `--ag-live` | `#e0245e` | live dot, hearts |
| `--ag-live-ink` | `#b0224f` | live text, dates on events |
| `--ag-live-wash` | `#fdecef` | giving wash |
| `--ag-info` | `#1f6fa3` | tickets, info |
| `--ag-error` | `#b42318` | errors, destructive text ("Sign out") |
| `--ag-stock-low` | `#8a2020` | "Only N left" |
| `--ag-stock-gone` | `#8a5a00` | "Sold out" note |

Rules:
- **One accent per block.**
- **Green is only for the primary action inside the page.** There's never a green button in the header.
- Chips and filter pills are **outlined** (`1px --ag-line-2`, white). Selected = `2px --ag-ink` border, same white fill, weight 700. **Never a dark fill.**
- No dark backgrounds, except the few dark bands a DC shows explicitly (e.g. the "Achieng won" card and the vendor call). Don't add more.

### 6.2 Typography

- **Families:**
  - `Playfair Display` 700 for headlines only.
  - `DM Sans` 400/500/600/700 for everything else, with `font-variant-numeric: tabular-nums` on changing numbers.
  - `JetBrains Mono` 500/700 **only** for references and codes: order refs, ticket codes, receipt codes, times inside ticket stubs.
  - **Never** use mono for labels, stats or kickers.
- **No uppercase labels,** except the ticket-stub "CONFIRMED" stamp (a graphic). Headings are sentence case.
- **Scale** (px; line-height in parentheses):

| Role | Phone | Desktop |
|---|---|---|
| Display / page H1 (Playfair) | 32 (1.1) | 44 (1.06) |
| Celebration title (Playfair) | 34 (1.08) | 48 (1.08) |
| AppBar large title (Playfair) | 26 (1.0) at rest; collapses to 17 DM Sans 700 centred | n/a |
| Section H2 (DM Sans 700) | 19 (1.3) | 19–22 (1.3) |
| Card title | 16–17 / 700 | 17 / 700 |
| Body | 16 (1.6–1.65) | 16–17 (1.65) |
| Secondary | 14.5 (1.5) | 14.5 (1.5) |
| Meta / caption | 13–13.5 | 13–13.5 |
| Micro (badges) | 11.5–12.5 | 11.5–12.5 |
| Buttons | 15–16 / 700 primary, 600 secondary | 14.5–15.5 |
| Inputs | **≥16** always (prevents iOS zoom) | 15–16 |

- **Measure:** body ≤ 62ch; celebration sub ≤ 44ch.
- `text-wrap: balance` on headlines; `pretty` on paragraphs.
- Load fonts with `display=swap` and preconnect.

### 6.3 Spacing

4 · 6 · 8 · 10 · 12 · 14 · 16 · 18 · 20 · 22 · 24 · 28 · 32 · 36 · 40 · 48 · 56 · 64.

- **Phone page gutter 16.** Tablet 28. Desktop 32 (40 inside hero bands).
- Section gap: phone 22–28, desktop 28–40.

### 6.4 Radii

999 (pills, chips, round buttons) · 24 (major cards, sheets, celebration) · 22 (content sheet over a gallery, top corners only) · 20 (cards, drawers, popovers) · 16 (phone CTAs, rows, inline stat tiles) · 14 (inputs, list cards, small buttons) · 12 · 10 (icon tiles) · 7 (mini badges).

### 6.5 Shadows (exact)

| Use | Value |
|---|---|
| Popover / drawer | `0 24px 48px -20px rgba(16,41,44,.30)` |
| Mega panel | `0 24px 48px -28px rgba(16,41,44,.25)` |
| Bottom sheet | `0 -12px 40px rgba(16,41,44,.18)` |
| Floating round button on a photo | `0 2px 10px rgba(16,41,44,.15)` |
| Quick-add dot on a card | `0 3px 10px rgba(16,41,44,.18)` |
| Celebration badge | `0 0 0 2px {ring}, 0 16px 34px -12px {ring}99` |
| Ticket card (celebration) | `0 18px 36px -14px rgba(31,111,163,.55), 0 0 0 1px #d8e6f0` |

### 6.6 Motion

| Token | Value | Use |
|---|---|---|
| `--ag-ease` | `cubic-bezier(.2,0,0,1)` | all UI transitions |
| `--ag-ease-pop` | `cubic-bezier(.2,.9,.3,1.2)` | badges, stars |
| `--ag-dur-1` | 200ms | opacity, colour |
| `--ag-dur-2` | 260ms | collapse and expand, sheets |
| `--ag-dur-3` | 500–550ms | celebration text rise |

Scroll-linked chrome swaps on a threshold (`scrollTop > 8`); it is **never** scrubbed per pixel.

### 6.7 Layout constants

| Constant | Value |
|---|---|
| Breakpoints | phone <600 · tablet 600–1023 · desktop ≥1024. The 3-column desktop layouts start at ≥1200 |
| Touch targets | ≥44×44 everywhere, 48–54 for primary phone actions. Never hover-only |
| Z-index | sticky toolbars 4–6 · app bar 20 · buy/vote bars 30 · header 40 · Gee 60 · scrim 79 · sheets 80 |
| Page shell | root `height:100dvh; max-height:100%`; **only `<main>` scrolls**, so bars and floating buttons stay pinned |

---

## 7. Shared components (build these first; they're used everywhere)

### 7.1 SiteHeader: tablet and desktop (`design/SiteHeader.dc.html` → `partials/nav.twig`)

- **Bar:** 64px tall, horizontal padding 28, `rgba(251,251,250,.9)` + `backdrop-filter: blur(16px)`, bottom hairline `--ag-line`. The hairline is removed while a mega panel is open.
- **Left:** logo, a 32×32 mark in a white 9px-radius tile with a 1px `--ag-line-2` border and 3px padding. Beside it, the wordmark "Africa" (Playfair 700 16) over "GATES" (DM Sans 700 9.5, letter-spacing .26em, `--ag-green`).
- **Two top links only:** **Participate ▾** and **Explore ▾**. Each is a 40px button with 14px horizontal padding, DM Sans 600 14.5. Open state: `--ag-tint` background and the chevron rotated 180°.
- **Right:**
  - A toolbar pill: 40px tall, 1px `--ag-line`, white, radius 999, containing Search (icon, 40px) | divider | **Aa** (Display & reading) | divider | 🌐 + language code.
  - Then the avatar (40px, ink) when signed in, or an outlined **"Sign in"** pill (40px, 1px ink) when signed out.
  - On shop routes, or whenever the cart isn't empty, a cart **icon button with a count badge** comes before the avatar. There's no subtotal text.
- **Mega panel:**
  - Hangs from the bar with no gap or border; full width, `rgba(251,251,250,.9)` + blur 18.
  - Bottom radii 24, the mega shadow (§6.5), inner max-width 1180 and padding `26px 40px 30px`.
  - A 3-column grid of items. Each is: a 40px tinted icon tile (radius 12) + title (DM Sans 700 15) + one line (13, `--ag-soft`). Rows are 12px padded, radius 14, hover `--ag-ground`. **There are no pictures.**
  - **Participate:** Nominate, Vote, Awards, Giving, Register a profile, Integrity Center.
  - **Explore:** Discover, Pulse, Events, Legacy Vault, Blog, Status.
- **Behaviour:**
  - Click toggles. Opening one panel closes the other panels and popovers. Esc closes; so does clicking the transparent scrim below the panel.
  - `aria-expanded`/`aria-haspopup`, `role="menu"`, focus returns to the trigger.
  - Keep the repo's `data-ag-mega*` controller.
- **Search palette:** opened by the Search icon or `/`.
  - 680px wide, 84px from the top, scrim behind.
  - Input → scope chips (All, People, Awards, Events, Pages) → grouped results (≤6 per group). The empty query shows trending, open-now and coming-soon.
  - Keyboard hints. ↑↓ / Enter / Esc. Focus is trapped and restored.
  - Data from `GET /search?q=&scope=` (JSON).
- **Aa and language popovers:** 360px (Aa) / 210px (language), `top:70px`, radius 20 / 16, popover shadow.

### 7.2 AppBar: phone (`design/AppBar.dc.html` → `partials/app-bar.twig`)

- **root** (Home, Discover, Nominate, Vote hub, Events, Awards index, Pulse):
  - A 52px row: 44px search icon · centred small title (DM Sans 700 17, opacity 0 at rest) · avatar button (34px in a 44px target, aria-label "Account, language and display").
  - Below that, a large-title row: Playfair 700 26–32, 16px gutter.
- **child** (VotePage, Nominee, Results, Award detail/soon): 44px back · title (DM Sans 700 16, truncates) + sub (12.5 `--ag-soft`, truncates) · 44px share. The height is 56.
- **Scroll:**
  - When `<main>.scrollTop > 8`, the bar fills to `--ag-bar` with a bottom hairline, the large title hides and the small title fades in (200ms).
  - Scrolling back to ≤8 reverses it.
  - Reduced motion: instant swap.
- **Avatar → Quick settings bottom sheet:**
  - profile row + Profile link;
  - text size (3-step segmented control, 48px);
  - High contrast and Reduce motion switches;
  - language chips, each written in its own language with a `lang` attribute, scrolling horizontally;
  - "All display & reading settings" → DisplayReading;
  - a 52px **Done** button.

  It writes to the same `ag-a11y` store. **There are no separate Aa or language buttons in the phone app bar.**
- **First-visit language prompt:**
  - Shown when `navigator.languages[0]` is a supported non-English language and there's no `ag_lang` cookie.
  - One dismissible row under the root AppBar, written in that language (e.g. "Voir Africa GATES en français ?" · Oui · Keep English).
  - Either answer sets the cookie. It hides on scroll and never returns.

### 7.3 Phone tab bar

- 5 tabs: **Home · Discover · Nominate · Pulse · Menu**.
- Each tab is ≥52px tall with a 23px icon over a 12px 600 label. Active = `--ag-green` icon and label.
- Background `--ag-bar` with a top hairline, bottom padding 22 plus the safe area.
- **Flow pages** (vote, checkout, event detail, nominee, product) have **no tab bar**: they have a back button and a bottom action bar.

### 7.4 Phone Menu (`design/MobileMenu.dc.html`)

- **The sheet:**
  - Bottom sheet from `top:52px`, radius 24 on top, a 38×5 grabber in `#c9c4b8`, a scrim of `rgba(16,41,44,.32)` and the sheet shadow. Background `--ag-ground`.
  - Header grid `44px 1fr 44px`: back (sub-views only) · centred title (700 16.5) · close (a 30px `--ag-tint` circle inside a 44px target).
- **Main view order:**
  1. Profile card: 52px avatar, name 700 17, "View your profile", and a points figure on the right. When signed out, a join card with a 50px ink "Sign in or join" button.
  2. 4 quick tiles in a grid: Nominate, Vote, Awards, Events. Each has a 44px tinted icon (radius 14) over a 13px 600 label, in a white radius-18 tile.
  3. **Explore** list: Discover, Pulse, Giving, Shop, Legacy Vault, Blog, Register.
  4. **Settings** list: Display & reading → pushed sub-view, showing the current value; Language → pushed radio list, with names in their own language and English below; Notifications (signed in).
  5. **Help** list: Help Centre, Integrity Center, Status (a live dot + "Working").
  6. Legal links, **Sign out** (`--ag-error` text, signed in only) and the wordmark line.
- **Lists:** white, radius 18. Rows are 56px with a 34px tinted icon tile (radius 10), label 500 16, a chevron in `#b3b9ba` and separators in `#eeece6`.
- **Sub-views push inside the sheet.** There are no accordions.

### 7.5 DisplayReading (`design/DisplayReading.dc.html`)

- **Controls:** text size (100/125/150% of root), high contrast, easy-read font (Atkinson Hyperlegible), line spacing 1.8, underline links, reduce motion, data saver (no auto images or video), read pages aloud (adds Listen), language.
- **Persistence:** `localStorage["ag-a11y"]` (JSON) plus the member profile when signed in.
- **Applying it:** as classes on `<html>` (`ag-t125`, `ag-hc`, `ag-easy`, `ag-ls`, `ag-ul`, `ag-rm`, `ag-saver`). This happens in an **inline nonce'd script in `<head>` before first paint.** No flash.

### 7.6 Language

- EN, FR, AR (sets `dir="rtl"` on `<html>`), SW, PT, HA, YO, IG.
- Stored as `?lang=` + the `ag_lang` cookie. Every string goes through the translation layer. Test RTL at 390.

### 7.7 Gee (`design/Gee.dc.html` → restyle the existing `gee.css`/`gee.js`)

- On every page **except Pulse**.
- **FAB:** a dark pill "G · Ask Gee" on desktop; icon only on phone.
- **Clearance (strict):**
  - The FAB is always ≥16px above any bottom-fixed element.
  - Bottom offset: tab bar 96px · sticky buy/give/vote/ticket bars 108px · no bar 40px.
  - Implement as `bottom: calc(var(--ag-bottom-ui, 0px) + 16px + env(safe-area-inset-bottom))`. Each fixed bar sets `--ag-bottom-ui` on `<body>` when it mounts and clears it when it unmounts.
- **Panel:** 400×580 on desktop. On phone it fills the page inset by 12px, and its height is capped to the page (never `vh`).
- **Panel order:**
  1. Header ("Online").
  2. **Dismissible privacy note:** retention period + "Don't share card numbers or passwords" + policy link.
  3. Greeting and 4 starter chips.
  4. Bubbles.
  5. Help-link chips.
  6. Pill composer.
  7. Footer: "Gee can make mistakes · Privacy · Talk to a person".
- Support mode shows the amber dot.

### 7.8 Celebration (`design/Celebration.dc.html` + `assets/celebration/*`: SHIP VERBATIM)

The full spec is skill §24; these are the build rules.

- **Kinds and moments:** `win` (the winner's nominee page and the overall result) · `vote` (vote done) · `nominate` (nomination sent) · `give` (gift done) · `ticket` (ticket confirmed).
- **Sizes:**
  - `full`: phone stacked, desktop a 2-column split with the stage (360×320) on the left and left-aligned text on the right.
  - `inline`: a card (88px stage + text, two 48px buttons) that replaces a form in place.
- **Partial:** `partials/celebration.twig`, args `kind, size, layout, kicker, title, sub, stats[], primary, secondary, seen_key`.
  - Copy markup and styles exactly from the DC.
  - The stage is an empty `<div class="ag-cel__stage" data-agc-kind data-agc-size data-agc-seen-key>`.
  - Stats render their **final** value server-side in `<b data-agc-count="18402">18,402</b>`.
- **Boot:** in the page module, nonce'd.
  ```js
  document.querySelectorAll('[data-agc-kind]').forEach(el => {
    const card = el.closest('.ag-cel');
    const fx = AGCelebrate.mount(el, { kind: el.dataset.agcKind, size: el.dataset.agcSize,
      layout: matchMedia('(min-width:1024px)').matches ? 'desktop' : 'phone', seenKey: el.dataset.agcSeenKey });
    AGCelebrate.countUp(card, fx.calm);
    card.querySelector('[data-agc-replay]')?.addEventListener('click', () => { fx.replay(); AGCelebrate.countUp(card); });
  });
  ```
- **`seen_key`** = `{kind}-{edition_slug}-{subject_slug}`, plus `-{user_id}` when signed in. The first view plays the burst; later views go straight to the ambient loop with final numbers.
- **Headline defaults** (used when the route passes no title): "Your vote is in" · "{First} won." · "Nomination sent" · "Thank you for giving" · "You’re going".
- **Buttons (primary / secondary):**

| Kind | Primary | Secondary |
|---|---|---|
| vote | Share your vote | Vote in another category |
| win | Share the win | See how it was decided |
| nominate | Let them know | Nominate someone else |
| give | Share the campaign | See where it goes |
| ticket | Add to calendar | View ticket |

- **Never celebrate** saving drafts, settings, sign-in, add to cart or subscribe.

### 7.9 CookieConsent (`design/CookieConsent.dc.html`)

- Essential is always on, plus 3 optional categories.
- Honour Global Privacy Control (`navigator.globalPrivacyControl` → optional categories off, shown as "Respected your browser’s privacy signal").
- Re-openable from the footer and Menu → Cookies.

---

## 8. Screens

For each screen: open the DC, go through every prop combination, and build every one. The values below are the ones most often got wrong; everything else comes from the DC.

### 8.1 Home: `HomePageV3.dc.html` → `pages/home.twig`

- **Order:**
  1. Hero.
  2. Live stats.
  3. "Who recognises" (tabs + photo stage + record card).
  4. Wall of recognition (masonry, faded cut-off + "Show more").
  5. We Are Africa (`WeAreAfrica.dc.html`: an interactive map using `assets/countries-110m.json`).
  6. Happening now.
  7. Giving (1 featured campaign).
  8. Recognise band.
  9. Footer (the codebase footer, restyled as in the DC).
- **Phone hero:** the photo comes **first**, full-bleed (margin −16), 380px tall with radius 0, with the recognition card over it. Then the H1 (32) and the lead. Then **two stacked full-width CTAs**: "Nominate someone" (green) and "Recognise with Africa GATES" (1px ink outline), each 54px, radius 16, 16px text.
- **Desktop hero:** a two-column grid. CTAs are 50px pills side by side.
- **Wall:** max height 640px on phone until "Show more".

### 8.2 Discover: `DiscoverPage.dc.html` → `pages/discover.twig`

- The search and filters bar sticks.
- On scroll, the tabs **dock beside Filters** (skill §6b, strict).
- Facets open in a bottom sheet on phone and a side rail on desktop.

### 8.3 Awards: `AwardsPage.dc.html` → `awards/index.twig`, `awards/programme.twig`

- **`view=index`:**
  - A collapsing sticky search (§9.2).
  - Phase chips with mono counts (All, Nominations, Voting, Judging, Results, Coming soon), each with a coloured phase dot.
  - A card grid.
- **`view=detail`:** tabs **Overview | Award details | Terms**.
  - Award details is the long, platform-generated description.
  - Terms is versioned, shows the effective date and a changelog, and requires acceptance before nominating or voting.
  - The hierarchy is Organisation → Award → Edition → Category.
- **`view=soon`:** a "Coming soon" page for an award with no open phase, with a notify-me email (double opt-in).

### 8.4 Vote hub: `VoteHub.dc.html` → `pages/vote.twig`

- **Layout:** a light list, a live total with a pulsing dot, filters, and rows with live counts. Desktop has a rail.
- **Phone:**
  - The filter chip row is sticky at `top:0` (10px vertical padding, 44px chips).
  - **Rows are 88px** (60px thumb · text · count · 18px chevron) and the whole row is the target. There's no inline Vote button.

### 8.5 Vote (edition): `VotePage.dc.html` → `pages/vote-program.twig`

- **Phone:**
  - Child AppBar ("Kenya Creative Economy Awards" / "11th Edition · voting open").
  - **Light hero:** a 16:9 radius-18 photo with a white "Voting open" chip (live dot, `--ag-live-ink` text).
  - A countdown card: white, radius 16, three 42px-min tiles on ground (mono 17 value + 10.5 label), with `role="timer"`.
  - The meta line.
  - Full-width tabs **Vote | About the award**, 52px.
  - A sticky category chip row under the tabs (`top:52px`).
  - Race cards: headline, rank, live count, gap to the leader, bar versus the leader. Vote buttons are 44px.
  - **Bottom bar** (`rgba(251,251,250,.96)` + blur 14, padding `12 16 28`): "N of 6 categories voted" + a 5px progress bar + **Review votes** (52px, radius 16; disabled `--ag-tint` / `--ag-mute` until ≥1 vote). Gee moves to 108px.
  - The side "ballot" rail is hidden on phone.
- **Desktop:** the dark hero band + a two-column layout with a sticky ballot rail.
- **About the award tab:** host, what it celebrates, editions, who can vote, support rules, judges, the edition timeline (Nominations → Community voting → **Judging after voting** → Results & ceremony), weighting, FAQ and the ceremony link.

### 8.6 Nominee: `NomineePage.dc.html` + `VoteBallot.dc.html` → `pages/vote-nominee.twig`

- **Order:** race block → "Support for {first}" → reviewed evidence (read-only) → other nominees.
- **Ballot** (the existing flow, restyled): points → paid contribution tiers (outlined chips) → "or vote free" → **name, phone, email and message all required; the public display name is optional** → rules → email OTP → done (inline `vote` celebration).
- **`phase=won`:** a full `win` celebration + a roll of honour (named supporters only) replace the ballot. The bottom bar reads "See the result".
- **Signed out:** "Have points? Sign in to redeem them. You can still vote without an account."

### 8.7 Results: `ResultsPage.dc.html` → `pages/results.twig`

- **The overall edition winner comes first,** with the top 3. Then the summary. Then the category winners.
- An edition that is still running shows "Overall winner announced {date}" in the same slot.

### 8.8 Profile: `ProfilePage.dc.html` → `pages/profile.twig`

- Owner view: Share + Edit profile in the header.
- Evidence is locked and shows a "Reviewed" state.
- Listen (read aloud).
- Recognitions come from verified issuers, and a recognition can only be withdrawn, with a public log.

### 8.9 Pulse: `PulsePage.dc.html` → `pages/pulse.twig`

- **Desktop:** a single left rail and no top bar.
- **Post kinds:** post, photo, recognition, vote, give. 4 reactions.
- **Signed out:** a guest banner "Join Africa GATES to post, react and follow the people you care about." + an outlined "Sign in or join".
- There is no Gee on this page.

### 8.10 Events: `EventsPage.dc.html` → `pages/events.twig`, `events/detail.twig`

- **Index:**
  - Phone: root AppBar; sticky filter chips (44px).
  - Featured-event buttons are stacked full width on phone (50px, radius 14); pills on desktop.
  - Event rows are ≥76px.
- **Phone detail:**
  - A full-bleed 4:3 photo with floating 44px round buttons (back, calendar, share).
  - A content sheet (radius 22) overlapping the photo by 22px, containing: the date line (mono 12.5, `--ag-live-ink`, letter-spacing .1em), the title (Playfair 26), venue + host, and the early-bird row (48px, `--ag-gold-wash`).
- **Detail order on phone:** tickets card → About → Agenda (track filter) → Venue → Access → Good to know → Vendor call → Share/save → Earn → Livestream. There's also a fixed bottom bar: "From {lowest} · Get tickets".
- **Desktop detail:** a main column + a sticky 380px rail.
- **Tier colours:**
  - Each tier row supplies `accent`, `accent_light`, `wash`, `deep` and `glow` as CSS custom properties.
  - Picking a tier re-tints **only** the accents inside the ticket card: eyebrow, fundraising figure, selected tier border and wash, "Only N left", Apply, total and CTA.
  - **Radios stay neutral.**
- **Tier glow:**
  - `@property --ev-a` animated 0→360° over 3.2s, linear.
  - A blurred halo (inset −10px, blur 22px, opacity .55, breathing) + a 2px conic ring (`padding-box` white + `border-box` conic).
  - It replays on each pick and settles to .35. Fallback: a static gradient border.
- **States (`state`):** open · waitlist ("N waiting", 24h hold) · soldout · closed · ended (results + recording).
- **Keep every existing feature:** discount check, seats, flier, .ics + Google Calendar, earn link, appeals, stands.

### 8.11 Ticket: `TicketPage.dc.html` → `events/ticket.twig`

A light polish of the existing template. Keep all of its rules: QR + printed code always, 190×86mm print, PDF, no scannable ticket unless confirmed.

**Add:**
- a status chip (Valid · admits N / Checked in);
- a countdown in the kicker;
- tear notches and a tier-coloured dot ring;
- 2×2 actions: Wallet, Calendar, Save/print, Directions;
- a collapsed "Manage this ticket" (transfer, name change, refund);
- an offline note.

### 8.12 Shop: `ShopPage.dc.html` → `shop/index.twig`, `shop/item.twig`, `shop/order.twig`, `shop/success.twig`, `shop/alert-stopped.twig`

- **Phone markup is separate from desktop.**
- **Phone index:**
  - A sticky 56px app bar ("Shop" + cart icon with badge), then a one-line intro and a 52px search.
  - A **sticky chip toolbar** at `top:56px`: Filters (count of non-category filters) · All · categories (single-select) · a native Sort `<select>`. All controls are 44px and outlined.
  - Removable filter chips (outlined, not dark).
  - A compact gold "Frame your recognition" row, then the count.
  - A **2-column grid**: 4:5 image, a 48px quick-add hit area (34px visual), a 2-line name, "N colours · maker", price + low stock.
  - A full-width 52px "Load more" (+4 per step, "Showing X of N").
- **Phone item:**
  - A full-bleed 4:5 scroll-snap gallery (keyboard-focusable) with decorative dots and floating 44px back, share and cart buttons.
  - A content sheet (radius 22) overlapping by 22px, containing in order:
    1. maker;
    2. name (Playfair 28);
    3. price (22) + "Gives back 40%";
    4. colour: 48px targets with 36px swatches and a selected ring `0 0 0 3px #fbfbfa, 0 0 0 5px --ag-ink`;
    5. size: a 5-column grid of 52px chips; selected = 2px ink border; sold out = struck through on ground, still selectable;
    6. 44px "Size guide";
    7. quantity stepper (48px buttons);
    8. restock alert when sold out;
    9. delivery row;
    10. description;
    11. 56px accordions;
    12. perks;
    13. horizontal "You may also like".
  - **Sticky buy bar:** total + "Colour · Size · Qty N" + a 54px **Add to cart** (radius 16). It's hidden when the chosen size is sold out. Gee sits at 108px while it shows.
- **Desktop:** a 264px sticky filter rail + the grid.
  - Filters: category checkboxes with counts, named colour swatches, size chips, price min/max + Apply, In stock, Featured, Deliver-to region, display currency (cookies `ag_region` / `ag_currency`).
  - All filters live in the URL (`?c[]=&col[]=&sz[]=&min=&max=&stock=1&feat=1&sort=&q=`) and survive Back.
- **Card action:** "Add" when there are no options, "Choose size" when there are, a disabled "Sold out" when nothing is left. **Never "Add" for something that needs a choice.**
- **Add to cart never navigates.** It shows an "Added to your cart" confirmation that doesn't dismiss itself, with: thumbnail, name, options and qty, price, count and subtotal, **View cart** (outline), **Checkout** (green) and "Keep shopping".
  - Desktop: a 380px popover under the header, 24px from the right.
  - Phone: a bottom card inset 8px.
  - `role="status"`.
- **Cart drawer (desktop):** floats 12px from the edges, radius 20, light scrim.
- **Currency:** prices show in the display currency, with "Charged in Naira · ₦X" when it isn't NGN.
- **Delivery:** free over ₦50,000 or at a pickup point.
- **Order page:** reachable by reference alone and noindex. It has 5 states, payment and delivery cards, 4-step progress, the receipt and support. `notfound` doesn't reveal whether the reference exists.

### 8.13 Giving: `GivingPage.dc.html`

- Campaign → checkout (mobile money: M-Pesa, MTN MoMo, Airtel; card; bank; USSD) → done (`give` celebration).
- On phone, the Give bar is fixed at the bottom (Gee at 108px).

### 8.14 Blog: `BlogPage.dc.html` → `pages/blog/*`

An editorial index + article with Listen, a reading-progress bar, `read_minutes` and people tags.

### 8.15 Status: `StatusPageV2.dc.html` → `pages/status.twig`

- Keep every rule in the current twig header comment.
- **Add:** a live incident timeline, a maintenance banner, status by country, and subscribe. Subscribe is shown only when an email sender is configured.

### 8.16 Nominate: `NominateHub.dc.html`, `NominationFlow.dc.html` → `pages/nominate*.twig`

- **Nominee type:** a person, an organisation or a business.
- **Categories:** 2 minimum, 3 maximum.
- **Reason:** required for **each** chosen category, **≥40 characters**, with a live counter "N/40" that turns green at 40. Error copy: "Tell us a little more (at least 40 characters)."
- **Evidence** is optional: links and files (PDF/JPG/PNG, ≤10MB each, ≤5 files).
- **No AI wording.** Category-fit analysis runs server-side for admins and judges only.
- **Done:** an inline `nominate` celebration.

### 8.17 Sign in: `SignIn.dc.html` → auth templates

Passwordless: a code by phone or email, with WhatsApp and voice-call fallbacks. Then profile basics, then interests.

---

### 8.18 Legacy Vault: `LegacyVault.dc.html` → `pages/legacy/index.twig`, `pages/legacy/event.twig`
- **Keep:**
  - the 3 metrics (editions, awards conferred, delegates);
  - the edition cards (cover, date badge, location, title, "delegates · awards", "View edition");
  - the empty state "The vault opens after the first edition" + "See upcoming events";
  - the manifesto quote;
  - on the edition page: tagline, fact chips, recap, gallery, "All editions".
- **Index:**
  - Editions are grouped by **year** (newest first), with a count per year and "Show all N from {year}".
  - **Phone:** rows of 88px (an 84×63 thumbnail, radius 10) inside one white card. A sticky toolbar holds a 48px search, a native Region select and year chips (44px, outlined).
  - **Desktop:** a sticky 260px rail (search 44, Year radio list with counts, Region checkboxes, a sealed-record note) + a card grid (3 columns at ≥1200, 2 below).
  - Filters live in the URL (`?year=&region[]=&q=`).
- **Edition (`view=edition`):**
  - Phone: a full-bleed 4:3 cover + floating 44px back/share + a content sheet (radius 22, −22px overlap).
  - Order: breadcrumb → title → tagline → fact chips → **overall winner of the edition** (gold card, jury quote) → category winners (68px rows, 2 columns at ≥1200) → "The night" recap → gallery (4:3 tiles) → sealed record → earlier/later edition.
  - Desktop: a sticky 340px rail with the facts list, sealed record (with the mono fingerprint), every edition of this award (the current one ringed; the live one with a `--ag-live` dot) and "Cite this edition".

### 8.19 Leaderboard: `Leaderboard.dc.html` → `pages/leaderboard.twig`
- **Keep:**
  - the CPI title and the "{N} verified profiles… recomputed every 6 hours" line;
  - the podium (top 3);
  - category filter;
  - rows linking to `/registry/{slug}`, the first 40 plus "Show 20 more";
  - the note "Showing X of N · How scoring works";
  - the `aria-label` per row;
  - names wrap, never truncate.
- **Changed:**
  - The #1 card is the **gold wash**, not a dark gradient.
  - **No emoji flags:** use the ISO code in the meta line.
  - The tier appears in the meta line.
  - A movement indicator (▲ n in `--ag-green-deep` / ▼ n in `--ag-error` / – in `--ag-mute`) is carried in words in the `aria-label`.
  - Desktop columns: `56px 1fr 120px 150px 64px` (Rank · Profile · Category · Community·Judges mini split bar · CPI). The rail (280) holds search, a tier legend and the verification note.
  - "How the index works" card with the 45/55 bar (tablet and desktop).
  - Updated / next-update line.
  - Region select + category chips in a sticky row.
- **Empty (`state=empty`):**
  - A white radius-24 card: "First board" kicker → the Playfair headline "The first ranking goes live 6 hours after voting opens." → a 3-tile countdown to voting opening (`role="timer"`).
  - A **ghost podium**: dashed outlines 2 · 1 · 3, with the #1 on a gold hairline.
  - 3 steps: "Nominations are reviewed" · "Voting opens {date}" · "The board goes live".
  - **Nominate someone** (green) + "Tell me when it goes live" (outlined; becomes "We’ll email you when it’s live").
  - **No illustration and no mascot.**

### 8.20 Documents: Integrity Centre, Philosophy, Terms, Privacy, Cookies, Award terms (`DocPage.dc.html`, prop `doc`)
One template for every long document: `pages/integrity.twig`, `pages/philosophy.twig`, `pages/legal.twig` and `pages/programme-terms.twig`, all via the existing `partials/article.twig` macros. Restyle the macros; don't fork them.

- **Colour tier 0** (as the twigs declare):
  - no green anywhere in the document;
  - links are ink, underlined (1px, offset 3px, 2px on hover);
  - the focus ring is ink;
  - toggles on /cookies are the only control and use ink when on.
- **Masthead:** eyebrow (13.5/600) → Playfair title (32/40/46) → subtitle → standfirst (16.5–18) → byline (author · version · updated · read time) → tools (Listen, which toggles to Pause · Cite or Download; 44px outlined pills).
- **Layout:**
  - **≥1200:** `240px | ≤680px | 280px`, gap 48. Left: sticky contents with the current section highlighted (white pill, 700) + "Also filed here". Right: sticky **Live settings** (integrity) or **This document** (legal).
  - **1024–1199:** 2 columns; the right card moves inline under the masthead.
  - **Tablet and phone:** a single column (max 680). A sticky 48px **Contents bar** ("Contents · 02 · The score") opens a bottom-sheet contents list with 52px rows. A 2px ink reading-progress bar sits at the top of `<main>`.
- **Sections:** a numbered Playfair h2 (22/26), `scroll-margin-top:64px`. Body 16/17, line-height 1.7, max 680.
- **Tables:** real `<table>` on tablet and desktop. **On phone, each row becomes a stacked card row** (label + value on one line, description below). There's no horizontal scroll.
- **Blocks:** asides are white hairline cards (no coloured left border). The can/cannot columns use ✓/✕ in ink circles. "Further reading" is an ink link list. The handover card links to the next document (integrity ↔ philosophy).
- **Figures:** every figure (45/55, quorum, bonus cap, return threshold, risk bands) comes from RuleEngine route variables, never typed. Keep the twig's `default()` guards.
- **/cookies:** the "Your choices, right now" control card sits **above** the body (Essential locked "Always on"; Preferences, Analytics, Marketing switches). Honour GPC.
- **Cite block:** the citation text + Copy citation + Download/Share + the effective-date note. The footer carries the contact email and a Help Centre link.

### 8.21 Help Centre: `HelpCentre.dc.html` → `pages/help.twig`, `pages/help-article.twig`, `pages/help-category.twig`
- **Keep:**
  - "How can we help?" / "Results for “q”";
  - the "Who is asking" audience nav (`?for=`);
  - the 4 "Most people are here for one of these" answers;
  - the category directory with article links + "All N in {category}";
  - search results with "Clear search";
  - on the article page: breadcrumb, copy-link, body blocks and steps, "Did this answer it?", prev/next, related, "This is a general answer", siblings.
- **Search:** a sticky 52px (phone) / 58px (desktop, centred, max 680) search + audience chips. Results are a white list; below them a "Gee can probably help" card with **Ask Gee about this** (green) + "Browse every topic".
- **Top answers:** 76px cards with a 44px tinted icon tile, 2 columns on tablet and desktop. The directory is a 3/2/1-column grid of category cards (36px icon, name, count, 3 × 48px links, "All N").
- **"Still stuck" band:** "An article can’t look up your payment. Gee can." + **Ask Gee** + "Contact a person" (→ `/support`).
- **Article:** "No, ask Gee" and "Ask Gee about my case" **open Gee in help-desk mode in place**, seeded with the article title (`?q=`). They never navigate.

### 8.22 Gee help desk replaces `/support/assistant` (strict)
- `/support/assistant` becomes **`301 → /help?gee=support`**, and so does `/support/assistant?q=…` → `/help?gee=support&q=…`. The Help Centre opens Gee on load when `gee=support` is present.
- Gee gets a **`mode`**: `guide` (default everywhere) | `support` (Help Centre, "No, ask Gee", payment-failure pages, Status "Get help").
- **Support mode renders:**
  - header "Gee · Help desk" + an **amber dot** + "Help desk · reading live records";
  - greeting "Hi {first}. What has gone wrong?" + the capability sentence;
  - **capability chips:** Repair a stuck payment · Resend a receipt · Read your payments and votes. When signed out, the last one shows ✕ "needs sign-in";
  - a **Reference field** (mono, auto-uppercase, "AFG-…", with a forget ×);
  - support starters: paid but no votes · code didn’t arrive · resend receipt · result is wrong;
  - footer "A person still gets every unresolved message · Your support tickets · Talk to a person".
- Keep every behaviour of `support-assistant.twig`: the supportDesk() Alpine store, the `ai_on` fallback copy ("Answering from the written help. A person still gets your message"), tickets link and sign-in note.
- Open API: `window.AGGee.open({mode:'support', q})`. The design prop `openSignal` is the stand-in for this.
- `/support` ("Reach a person", appeal form, tickets) stays a page.

### 8.23 Activity retired → Discover (strict)
- **`/activity` → 301 → `/discover?tab=live`** (keep `q` and `literal`). Remove Activity from every nav, the footer and the sitemap. Add `/discover?tab=live` to the sitemap.
- **Discover gains a "Live" tab** (second, after All):
  - **All tab:** a compact "Happening now" block (4 newest) + "See everything".
  - **Live tab:** "Everything happening now", a `role="status"` count line, the kind chips (Everything, Results, Nominations, Voting, Events, Stories, Recognitions), the timeline, and "Show older updates".
  - **Row:** kind dot + label · `<time datetime>` relative time · title (15/600) · detail (13).
  - The **"Understood as"** line (chips + "Search these words literally instead") and the **Literal** line ("Let the search interpret it") come from activity.twig.
  - Also from activity.twig: the partial-sources warning "Some activity sources are unavailable on this deployment ({n} of 7 responded)".
  - The search field is Discover’s own (the site find-band); there is no second field.
- Keep activity.twig's a11y rules:
  - `aria-activedescendant` for the live combobox;
  - the live region on the status line only, **never** on the list;
  - every item is a real link.

## 9. Interactions & behaviour

### 9.1 Scroll-linked chrome

- The page's `<main>` is the scroll container. Use one passive scroll listener per page and compute booleans only (`scrolled = scrollTop > 8`).
- **Never** call `setState`/re-render on every scroll event. Compare with the previous boolean first.

### 9.2 Collapsing sticky search + filters (Awards index; reused by Discover, Shop, Events)

- **The sticky block:** `top:0`, ground background, 10px vertical padding at rest and 8px once scrolled. A 1px `--ag-line` hairline shows only when `scrollTop > 8`.
- **Search row:** always in the DOM.
  - Wrapper: `display:grid; grid-template-rows: 1fr ↔ 0fr`, with an inner `min-height:0; overflow:hidden`.
  - Animate `grid-template-rows` + `margin-bottom` (10 ↔ 0) over 260ms `--ag-ease`, and opacity over 200ms ease.
  - **Never** use `display:none` for this.
- **Search button:** at the start of the chip row, always in the DOM. Width 0 ↔ 44px (40 on desktop), `margin-inline-end` −8 ↔ 0, opacity; same easing.
- **States:**
  1. `scrollTop ≤ 8`: open, button hidden.
  2. Scrolled with an empty query: collapsed, button shown.
  3. The button opens the row and records `y0`.
  4. While open with an empty query, scrolling more than 24px from `y0` collapses it.
  5. A non-empty query keeps it open.
  6. Back at the top resets to state 1.
- **Accessibility:**
  - Collapsed = `aria-hidden="true"` + input `tabindex="-1"`; the hidden button mirrors this.
  - The button moves focus to the input. Esc collapses the row and returns focus to the button.
  - Reduced motion = instant swap.

### 9.3 Celebrations

Follow skill §24 exactly: the choreography, the ambient loop, pausing off-screen, play-once and reduced motion. The ambient budget is ≤40 nodes in the DOM and ≤12 visible at once (skill §24.6). The shipped file measures win 39, nominate 15–17 and the others ≤8, which passes; don't "optimise" it. The shipped JS already implements all of this. **Your job is the markup, the boot code and the `seen_key`.**

### 9.4 Loading / empty / error (required on every data view)

- **Loading:** skeletons that match the final layout (same heights), with no spinners for content. Buttons that submit show a pressed + disabled state within 50ms and keep their label ("Sending…").
- **Empty:** one sentence built from the active filters + one action (e.g. "Nothing matched 'kente' in Size L. Clear filters"). Never an empty page.
- **Error:** inline, next to the field, in `--ag-error` with an icon, announced with `aria-live="polite"`. Form values are kept. Network failures show "We couldn’t reach Africa GATES. Your details are saved. Try again."
- **Payments:** a failed contribution or gift never removes the free vote and never takes money. Say so in the copy.

### 9.5 Forms

- Labels always visible (no placeholder-only labels). Inputs ≥16px font, 48–54px tall, radius 14.
- Use the correct `inputmode` / `autocomplete` / `enterkeyhint`. Native `<select>` on phone.
- Validate on blur and on submit, never on every keystroke. The exception is the reason counter (§8.16).

---

## 10. State management

| State | Where | Notes |
|---|---|---|
| Filters, sort, query, page | URL query | every listing survives Back |
| Region, currency | cookies `ag_region`, `ag_currency` | never query params |
| Language | `?lang=` + cookie `ag_lang` | sets `lang` and `dir` on `<html>` |
| Display & reading | `localStorage["ag-a11y"]` + profile | applied before first paint |
| Celebration seen | `localStorage["ag-cel-{seen_key}"]` | written by the engine |
| Cookie consent | cookie `ag_consent` (JSON, versioned) | GPC respected |
| Gee privacy note dismissed | `localStorage["ag-gee-privacy"]` | |
| Vote progress | server (session + OTP) | the phone bottom bar reads the server count |
| Cart | server session + badge count in the header/app bar | |
| Bottom UI height | `--ag-bottom-ui` on `<body>` | set and cleared by each fixed bar |

---

## 11. Data model changes (migrations + BOTH schema files)

- `gates_award_cycles.edition_number` (INT). Categories belong to a cycle.
- `gates_award_terms` (id, award_id, version, effective_at, body, changelog), plus `gates_award_terms_acceptance` (terms_id, profile_id or email, accepted_at, context nominate|vote).
- `gates_recognitions`:
  - columns: id, issuer_id, recipient_profile_id, kind (`award|honour|commendation|staff|certificate`), title, citation, issued_at, reference, visibility, evidence_ids (JSON), withdrawn_at, withdrawn_reason;
  - immutable apart from the withdrawal fields;
  - every withdrawal is logged publicly.
- Issuers: `issuer_type` (`community|organisation|business|government`) + `verified_at`. Government verification is manual.
- `gates_testimonials` (approved only) · blog `read_minutes`, `people` · event tier colour columns (`accent`, `accent_light`, `wash`, `deep`, `glow`) · event waitlist (email, tier_id, hold_expires_at) · `maintenance` windows · status probes by country · shop restock alerts (email, sku, created_at, stopped_at, token).
- Mind the repo `CLAUDE.md` SQLite/MySQL traps: ENUM truncation, TINYINT 255, `CREATE INDEX IF NOT EXISTS`, the datetime `T`.

---

## 12. Voting rules (from the code; don't change them)

- **One free vote** per verified person per category (email OTP).
- **Paid contributions:**
  - tiers from `vote_tiers`, shown as outlined chips with provider radios and a receipt email;
  - capped per person per category;
  - they count the same as free votes, and points can be redeemed for a vote.
- **Required fields:** name, phone, email, message. The public display name is optional.
- **Edition order:** nominations → community voting → **judging after voting** → results and ceremony.
- **Weights:** community 45 / jury 55, locked when voting opens.
- Live totals and the race are public.

---

## 13. Accessibility (ships with each screen, not later)

- WCAG 2.2 AA. Targets ≥44px (WCAG 2.5.8 asks for 24; we require 44).
- Visible focus: a 3px `--ag-green` outline, 2px offset.
- Landmarks. Tab/radio/switch/dialog roles with correct `aria-*`. Dialogs and sheets trap focus and restore it.
- Colour is never the only signal (winners also say "Winner", stock notes carry words).
- Text contrast 4.5:1 (3:1 only for headlines ≥24px).
- Alt text on every photo; decorative particles are `aria-hidden`.
- Events carry caption, sign-language and audio-description flags. Articles and profiles have Listen.
- **Test:** 200% zoom, RTL (Arabic) at 390, VoiceOver iOS, TalkBack, keyboard-only.

---

## 14. Assets

| Asset | Source | Notes |
|---|---|---|
| `design/assets/logo-mark.png` | the Africa GATES codebase | use the repo's own logo file |
| `design/assets/countries-110m.json` | the codebase's `public/assets/geo` | Natural Earth 110m TopoJSON |
| `design/assets/africa-silhouette.svg` | derived from the TopoJSON | We Are Africa fallback |
| `design/assets/celebration/celebration.js` / `.css` | written for this project | **production files; ship verbatim** |
| Photography | Unsplash URLs in the DCs | **placeholders only.** Replace with real licensed images of real people and places. Keep the aspect ratios (4:5 products, 4:3 event detail, 16:9 phone hero, 380px home hero) |
| Icons | inline SVG paths in the DCs (24×24 grid, stroke 1.9–2.2, round caps and joins) | copy the paths into the repo's icon partial; don't substitute another icon set |
| Fonts | Google Fonts: Playfair Display 700, DM Sans 400–700, JetBrains Mono 500/700 | self-host if the CSP requires |

---

## 15. Gaps (verify in the repo; if missing, build end to end)

| Feature | Expected status |
|---|---|
| Recognitions + verified issuers | NEW |
| Award terms versioning + acceptance | NEW |
| Coming-soon awards + notify (double opt-in) | NEW |
| Overall edition winner + top 3 | NEW (compute) |
| Wall of recognition | NEW |
| Search API + palette | NEW |
| DisplayReading persistence + first-paint apply | NEW |
| Quick settings sheet + first-visit language prompt | NEW |
| Celebrations (partial + boot + seen keys) | NEW; the JS/CSS is supplied |
| Gee restyle + privacy note + `--ag-bottom-ui` clearance | EXTEND `gee.js` |
| Pulse post kinds + guest banner | EXTEND |
| Event tier colours, glow, states, waitlist | EXTEND `events/detail.twig` |
| Shop multi-select filters, load more, restock alerts, order page | EXTEND |
| Status by country, maintenance, subscribe | NEW |
| Two-link mega nav | EXTEND `nav.twig` |
| Nominee race, ballot, winner state | EXISTS; restyle |

---

## 16. Build order (one PR each, in this order)

1. Tokens (§6) + page shell + base component CSS.
2. SiteHeader + mega + search palette.
3. Phone AppBar + tab bar + Menu + Quick settings + DisplayReading + language.
4. Gee.
5. Celebration (partial + boot).
6. Home.
7. Awards (index, detail, soon, terms).
8. Vote hub → Vote → Nominee + ballot.
9. Results.
10. Events + ticket.
11. Shop.
12. Giving.
13. Profile, Pulse, Discover.
14. Nominate.
15. Blog, Status, Sign-in, Cookie consent.

---

## 17. Acceptance protocol (every PR must include all of these)

- [ ] **Screenshots** at 390, 834, 1024 and 1440 next to the DC at the same size, for **every** prop combination the DC exposes.
- [ ] **Overlay diff:** the DC screenshot at 50% opacity over the build at 390 and 1440. Any visible offset over 1px is a defect.
- [ ] RTL (Arabic) screenshot at 390.
- [ ] Keyboard-only walkthrough (the tab order is written in the PR) + VoiceOver and TalkBack notes.
- [ ] Reduced-motion recording, and a normal-motion recording of every animation.
- [ ] Lighthouse mobile: Accessibility 100, CLS < 0.05; no layout shift from fonts or sticky chrome.
- [ ] Low-end check: 60fps scroll and celebration on a 2GB Android (or DevTools 4× CPU throttle).
- [ ] Gee clearance measured on every page with a fixed bar (≥16px).
- [ ] **Deviations list** (target: zero). Every entry must include what, why, and approval.
- [ ] Skill checklists passed: §14 (phone) and §24.8 (celebrations).

**PR prompt to use:**

> Implement `<DC file>` for all `layout`/`view`/`state`/`signedIn` props in `<template path>`. Read README §0–§7, the skill, and `design-notes/DESIGN-NOTES.md` first. Reuse existing services; build anything missing per §4.3. Extract every value from the DC (§5); don't estimate. Attach everything in §17.

---

## 18. Conflicts already resolved (these override older notes)

1. **Desktop cart:** an icon button with a count badge, **no subtotal text**. The drawer floats 12px from the edges, radius 20, light scrim. (Overrides "pill with subtotal".)
2. **Applied-filter chips:** **outlined**, not dark. (Overrides "removable dark chips".)
3. **Monospace:** only for references and codes, never for stats or labels. Celebrations use no mono.
4. **Uppercase:** none in labels or kickers; sentence case everywhere.
5. **Phone app bar:** Aa and language live in the avatar Quick settings sheet, not as bar buttons.
6. **Judging always comes after voting,** in copy, timelines and data.
7. **Admin screens are not designed.** Build them inside the existing admin UI from the repo notes. The nomination category-fit assistant is admin/judge only.

---

## 19. Files in this bundle

```
design_handoff_africa_gates/
├── README.md                          ← this file (authoritative)
├── skill/app-ux-standards/SKILL.md    ← install as a Claude Code skill
├── design-notes/DESIGN-NOTES.md             ← standing design rules
├── design-notes/HANDOFF-CLAUDE-CODE.md← previous working handoff (history; README wins)
└── design/
    ├── support.js                     ← runtime for opening the DCs in a browser
    ├── Nominate.dc.html               ← review canvas (all screens; Turns 12–13 current)
    ├── HomePageV3 · WeAreAfrica · DiscoverPage · AwardsPage · VoteHub · VotePage
    ├── NomineePage · VoteBallot · ResultsPage · ProfilePage · PulsePage
    ├── EventsPage · TicketPage · ShopPage · GivingPage · BlogPage · StatusPageV2
    ├── NominateHub · NominationFlow · SignIn · CookieConsent        (.dc.html)
    ├── SiteHeader · AppBar · MobileMenu · DisplayReading · Gee · Celebration (.dc.html)
    ├── LegacyVault · Leaderboard · DocPage (integrity/philosophy/terms/privacy/cookies/programme-terms) · HelpCentre (.dc.html)
    ├── assets/ (logo-mark.png, countries-110m.json, africa-silhouette.svg, celebration/)
    └── _archived/ (HomePage, HomePageV2, StatusPage v1, AdminAwards): canvas history only. NOT a spec; don't build.
```

Note: the canvas (`Nominate.dc.html`) imports the archived files for its old turns. Open it from `design/` after copying `_archived/*` up one level if you want those old turns to render. The current turns (12–13) render without them.
