# Snippets: start from these, don't re-invent them

| File | Phase | Use |
|---|---|---|
| `css/tokens.css` | 1 | The only file with hex values. Copy to `public/assets/css/tokens.css`. |
| `css/shell.css` | 1 | The page shell (only `<main>` scrolls), focus, reduced motion, DisplayReading classes. |
| `css/components.css` | 1–2 | Buttons, chips, fields, lists, sheet, switch, segmented control, skeleton, app bar, tab bar, action bar. |
| `js/a11y-head.js` | 2 | Inline in `<head>` with the CSP nonce. |
| `js/scroll-state.js` | 1 | `watchScroll` (app bar fill) + `collapsingSearch` (§9.2 states 1–6). |
| `js/bottom-ui.js` | 3 | Keeps Gee clear of fixed bars. |
| `js/sheet.js` | 2 | Bottom sheets and dialogs with focus trap and restore. |
| `twig/page-shell.twig` | 1 | The required shell order. |
| `twig/app-bar.twig` | 2 | The phone app bar partial. |
| `twig/celebration.twig` | 3 | Pairs with `design/assets/celebration/*` (ship those verbatim). |
| `php/redirects.php` | 3–4 | The `/activity` and `/support/assistant` 301s. |

These are **starting points written against the tokens**. If a snippet and a DC disagree, the DC wins. Fix the snippet and note it in the PR.
