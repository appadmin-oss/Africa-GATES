/* Inline this in <head> with the CSP nonce, BEFORE any stylesheet paints. Applies DisplayReading choices with no flash. */
(function(){try{var d=document.documentElement,c=d.classList,s=JSON.parse(localStorage.getItem('ag-a11y')||'{}');
var t={1:'ag-t125',2:'ag-t150'}[s.size]; if(t) c.add(t);
['hc','easy','ls','ul','rm','saver'].forEach(function(k){ if(s[k]) c.add('ag-'+k); });
if(s.lang){ d.lang=s.lang; if(s.lang==='ar') d.dir='rtl'; }
}catch(e){}})();
