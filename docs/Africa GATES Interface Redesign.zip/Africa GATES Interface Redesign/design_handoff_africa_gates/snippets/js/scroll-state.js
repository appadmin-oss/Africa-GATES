/* One passive listener per page. Sets [data-scrolled] on .ag-shell and on .ag-sticky blocks when main.scrollTop > 8. Never re-renders per pixel. */
export function watchScroll(main, { threshold = 8, onChange } = {}) {
  const shell = main.closest('.ag-shell'); let state = null;
  const tick = () => { const v = main.scrollTop > threshold; if (v === state) return; state = v;
    shell && shell.toggleAttribute('data-scrolled', v);
    main.querySelectorAll('.ag-sticky').forEach(el => el.toggleAttribute('data-scrolled', v));
    onChange && onChange(v); };
  main.addEventListener('scroll', tick, { passive: true }); tick();
  return () => main.removeEventListener('scroll', tick);
}

/* Collapsing sticky search (REFERENCE/phase-1 §9.2). Markup:
   <div class="ag-sticky" data-cs><div class="ag-cs__row"><div><label class="ag-field">…<input data-cs-input></label></div></div>
   <div class="ag-chip-row"><button class="ag-cs__btn" data-cs-btn aria-label="Search">…</button> chips…</div></div>
   CSS: .ag-cs__row{display:grid;grid-template-rows:1fr;margin-bottom:10px;transition:grid-template-rows var(--ag-dur-2) var(--ag-ease),margin-bottom var(--ag-dur-2) var(--ag-ease),opacity var(--ag-dur-1) ease}
        .ag-cs__row>div{min-height:0;overflow:hidden} [data-cs][data-collapsed] .ag-cs__row{grid-template-rows:0fr;margin-bottom:0;opacity:0}
        .ag-cs__btn{width:0;margin-inline-end:-8px;opacity:0;overflow:hidden;transition:width var(--ag-dur-2) var(--ag-ease),margin var(--ag-dur-2) var(--ag-ease),opacity var(--ag-dur-1) ease}
        [data-cs][data-collapsed] .ag-cs__btn{width:44px;margin-inline-end:0;opacity:1} @media(min-width:1024px){[data-cs][data-collapsed] .ag-cs__btn{width:40px}} */
export function collapsingSearch(main, block) {
  const input = block.querySelector('[data-cs-input]'), btn = block.querySelector('[data-cs-btn]'), row = block.querySelector('.ag-cs__row');
  let open = true, y0 = 0;
  const set = (o) => { open = o; block.toggleAttribute('data-collapsed', !o);
    row.setAttribute('aria-hidden', String(!o)); input.tabIndex = o ? 0 : -1;
    btn.setAttribute('aria-hidden', String(o)); btn.tabIndex = o ? -1 : 0; };
  const onScroll = () => { const y = main.scrollTop, q = input.value.trim();
    if (y <= 8) { if (!open) set(true); return; }          // state 1 / 6
    if (q) return;                                          // state 5
    if (open && Math.abs(y - y0) > 24) set(false);           // states 2 / 4
  };
  btn.addEventListener('click', () => { y0 = main.scrollTop; set(true); input.focus(); }); // state 3
  input.addEventListener('keydown', e => { if (e.key === 'Escape' && main.scrollTop > 8 && !input.value.trim()) { set(false); btn.focus(); } });
  main.addEventListener('scroll', onScroll, { passive: true });
  set(main.scrollTop <= 8); if (!open) y0 = main.scrollTop;
}
