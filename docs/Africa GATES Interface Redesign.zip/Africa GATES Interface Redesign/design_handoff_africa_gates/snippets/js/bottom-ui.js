/* Every fixed bottom element carries [data-bottom-ui]. Its height feeds --ag-bottom-ui so Gee clears it by 16px (DESIGN-NOTES: 96 tab bar / 108 action bar / 40 none). */
export function trackBottomUI() {
  const set = () => { let h = 0; document.querySelectorAll('[data-bottom-ui]').forEach(el => { if (el.offsetParent !== null) h = Math.max(h, el.getBoundingClientRect().height); });
    document.body.style.setProperty('--ag-bottom-ui', h + 'px'); };
  const ro = new ResizeObserver(set); document.querySelectorAll('[data-bottom-ui]').forEach(el => ro.observe(el));
  new MutationObserver(set).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden', 'class', 'data-open'] });
  set();
}
/* Gee launcher CSS: .gee-fab{position:fixed;right:12px;bottom:calc(var(--ag-bottom-ui) + 16px + env(safe-area-inset-bottom))} @media(min-width:1024px){.gee-fab{right:24px}} */
