/* Bottom sheet / dialog: open, trap focus, Esc, scrim click, restore focus. */
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])';
export function openSheet(sheet, scrim, trigger) {
  sheet.setAttribute('data-open', ''); scrim && scrim.setAttribute('data-open', ''); sheet.removeAttribute('inert');
  trigger && trigger.setAttribute('aria-expanded', 'true');
  const els = () => [...sheet.querySelectorAll(FOCUSABLE)].filter(e => e.offsetParent !== null);
  (els()[0] || sheet).focus();
  const key = e => { if (e.key === 'Escape') close();
    if (e.key === 'Tab') { const f = els(); if (!f.length) return; const a = f[0], z = f[f.length - 1];
      if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } } };
  const close = () => { sheet.removeAttribute('data-open'); scrim && scrim.removeAttribute('data-open'); sheet.setAttribute('inert', '');
    document.removeEventListener('keydown', key); scrim && scrim.removeEventListener('click', close);
    trigger && (trigger.setAttribute('aria-expanded', 'false'), trigger.focus()); };
  document.addEventListener('keydown', key); scrim && scrim.addEventListener('click', close);
  return close;
}
