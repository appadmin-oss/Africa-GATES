<?php
// Slim 4 routes: permanent redirects for retired pages (phase 3 + phase 4). Preserve the listed query keys only.
use Psr\Http\Message\ResponseInterface as Res; use Psr\Http\Message\ServerRequestInterface as Req;
$redirect = static function (string $to, array $keep, array $fixed = []) {
    return static function (Req $req, Res $res) use ($to, $keep, $fixed): Res {
        $q = array_intersect_key($req->getQueryParams(), array_flip($keep));
        return $res->withHeader('Location', $to . '?' . http_build_query($fixed + $q))->withStatus(301);
    };
};
$app->get('/activity', $redirect('/discover', ['q', 'literal'], ['tab' => 'live']));
$app->get('/support/assistant', $redirect('/help', ['q'], ['gee' => 'support']));
