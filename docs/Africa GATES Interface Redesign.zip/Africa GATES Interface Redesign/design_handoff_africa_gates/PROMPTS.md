# Prompts for Claude Code (one phase per session)

## Phase 0
> Read `README.md`, then `phases/PHASE-0-recon.md` **fully**, then every file it lists under “Before you start”. Do only Phase 0. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 1
> Read `README.md`, then `phases/PHASE-1-foundations.md` **fully**, then every file it lists under “Before you start”. Do only Phase 1. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 2
> Read `README.md`, then `phases/PHASE-2-chrome.md` **fully**, then every file it lists under “Before you start”. Do only Phase 2. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 3
> Read `README.md`, then `phases/PHASE-3-gee-celebrations.md` **fully**, then every file it lists under “Before you start”. Do only Phase 3. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 4
> Read `README.md`, then `phases/PHASE-4-home-discover.md` **fully**, then every file it lists under “Before you start”. Do only Phase 4. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 5
> Read `README.md`, then `phases/PHASE-5-awards-voting.md` **fully**, then every file it lists under “Before you start”. Do only Phase 5. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 6
> Read `README.md`, then `phases/PHASE-6-records.md` **fully**, then every file it lists under “Before you start”. Do only Phase 6. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 7
> Read `README.md`, then `phases/PHASE-7-commerce.md` **fully**, then every file it lists under “Before you start”. Do only Phase 7. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 8
> Read `README.md`, then `phases/PHASE-8-community.md` **fully**, then every file it lists under “Before you start”. Do only Phase 8. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 9
> Read `README.md`, then `phases/PHASE-9-docs-help.md` **fully**, then every file it lists under “Before you start”. Do only Phase 9. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.

## Phase 10
> Read `README.md`, then `phases/PHASE-10-qa.md` **fully**, then every file it lists under “Before you start”. Do only Phase 10. Build every numbered item in order. Don't summarise, stub or skip. When done, tick every “Done when” box with evidence and post the “Report back” block. If anything can't be matched exactly, stop and ask.
