# Handoff: Africa GATES platform redesign

**Start here.** This bundle is split into **phases** so each piece of work is small, complete and checkable. Do them in order, **one phase per session / branch**. Don't read ahead and don't combine phases.

## Overview
A high-fidelity redesign of the whole public Africa GATES site (PHP 8.4 · Slim 4 · Twig 3 · vanilla JS/Alpine · nonce CSP). Every screen is designed separately for phone (<600), tablet (600–1023) and desktop (≥1024).

## About the design files
- `design/*.dc.html` are **design references built in HTML**. Open them in a browser (with `support.js` beside them), and use the **Tweaks** panel to switch every prop (layout, view, state, signedIn, mode…).
- **Recreate** them in the existing Twig/CSS/JS codebase with its patterns. Don't ship the HTML.
- **Exception:** `design/assets/celebration/celebration.js` + `.css` are production files. Ship them verbatim.

## Fidelity
**High.** Exact hex, ±1px, exact copy. Values not written in a phase file come from the DC's inline styles (REFERENCE §5).

## How to work
0. **Read `AUDIT-2026-10-05.md` first.** The current build branch does not render; fix its P0 list before any phase work.
1. Do **Phase 0** first. It writes `docs/handoff/GAPS.md` and changes no UI.
2. For each phase, open its file in `phases/`. It says exactly what to read, what to build (numbered), gives the verbatim spec, and ends with a **Done when** checklist.
3. Start each session with the matching prompt from `PROMPTS.md`.
4. A phase is finished only when every box is ticked with evidence. Only then open the next one.

## The 10 rules for every phase
1. The DC is the spec; match it and don't interpret it.
2. Can't match? Stop and ask. No placeholders, no TODOs.
3. Build what's missing end to end (migration → service → route → Twig → CSS → JS → test).
4. Reuse existing services and partials; extend them, never fork them.
5. Phone has its own markup where the DC does. Never scale or zoom. **`LAYOUT-BRANCHES.md` decides which markup renders at which width; read it before every screen.**
6. Only the tokens in `REFERENCE.md` §6. No inline styles in Twig (except data-driven custom properties).
7. Every animation has a reduced-motion path.
8. No AI wording in public. "Gee" is just the name.
9. Reviewed evidence is immutable.
10. Voting is never shopping ("buy", "cart", "pay for votes").

## Phases
| # | Phase | Scope |
|---|---|---|
| 0 | [Recon (no code)](phases/PHASE-0-recon.md) | GAPS.md, route map |
| 1 | [Foundations](phases/PHASE-1-foundations.md) | tokens, shell, base components |
| 2 | [Shared chrome](phases/PHASE-2-chrome.md) | header, app bar, tab bar, menu, reading settings, language, cookies |
| 3 | [Gee + celebrations](phases/PHASE-3-gee-celebrations.md) | guide + help desk, celebration engine |
| 4 | [Home + Discover](phases/PHASE-4-home-discover.md) | incl. the Live tab (Activity retired) |
| 5 | [Awards + voting](phases/PHASE-5-awards-voting.md) | awards, vote hub, vote, nominee, results |
| 6 | [Records](phases/PHASE-6-records.md) | leaderboard, legacy vault, profile |
| 7 | [Commerce](phases/PHASE-7-commerce.md) | events, ticket, shop, giving |
| 8 | [Community](phases/PHASE-8-community.md) | pulse, nominate, sign in |
| 9 | [Docs + help](phases/PHASE-9-docs-help.md) | integrity, legal, help centre, blog, status |
| 10 | [QA sweep](phases/PHASE-10-qa.md) | whole-site acceptance |

## Files
- `REFERENCE.md`: order of authority, contract, tokens, interactions, state, data model, voting rules, a11y, assets, acceptance protocol, resolved conflicts.
- `AUDIT-2026-10-05.md`: what the build branch got wrong, in fix order, plus answers to GAPS Q4–Q19.
- `LAYOUT-BRANCHES.md`: phone <600 · tablet 600–1023 · desktop ≥1024, which chrome and which markup render where, how to ship both branches without duplicating forms, and a per-DC branch map.
- `EVENTS-INDEX.md`: the events front page (spotlight carousel, sticky filters, type tiles, carousel rows, results grid).
- `HOLIDAY-THEMES.md`: seasonal greetings on member pages only (banner + a 3px line), the theme table, scheduling and dismissal.
- `DEFAULT-GRAPHICS.md`: the cover system for every image slot with no upload (Twig partial, CSS container queries, GD share images).
- `phases/`: one brief per phase.
- `PROMPTS.md`: copy-paste prompts.
- `skill/app-ux-standards/SKILL.md`: install as a Claude Code skill (it wins on phone behaviour and celebrations).
- `design-notes/DESIGN-NOTES.md`: the product owner's standing rules.
- `screenshots/`: 1:1 renders per phase (see `screenshots/INDEX.md`).
- `snippets/`: tokens, shell and component CSS, the scroll/sheet/bottom-bar JS, Twig partials and the redirects (see `snippets/README.md`).
- `design/`: every current DC plus `assets/`. `design/_archived/` is history and must not be built.
- `_source/README-full-v1.md`: the earlier single-file handoff, kept for search only. The phases supersede it.
