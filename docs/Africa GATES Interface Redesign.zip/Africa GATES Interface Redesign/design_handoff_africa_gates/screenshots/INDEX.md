# Screenshots

**1:1 renders of the DCs** (phone 390×844, tablet 834×1112, desktop 1440×900; Gee 460×700; celebrations at their card size). They show the **default demo state** of each DC. For every other state, open the DC and switch its props. **The DC wins over any screenshot.** `--further-down` shows the content one screen lower; sticky bars may look slightly different there than when really scrolled.

## Phase 2
- `phase-2/header-mega-desktop.png`
- `phase-2/menu-open-phone.png`
- `phase-2/cookie-consent-phone.png`

## Phase 3
- `phase-3/gee-help-desk-phone.png`
- `phase-3/gee-guide-desktop.png`
- `phase-3/gee-help-desk-signed-out-desktop.png`
- `phase-3/celebration-win-desktop.png`
- `phase-3/celebration-give-phone.png`
- `phase-3/celebration-vote-inline.png`
- `phase-3/celebration-ticket-phone.png`

## Phase 4
- `phase-4/home-phone.png`
- `phase-4/home-phone--further-down.png`
- `phase-4/home-tablet.png`
- `phase-4/home-desktop.png`
- `phase-4/discover-phone.png`
- `phase-4/discover-desktop.png`

## Phase 5
- `phase-5/awards-index-phone.png`
- `phase-5/awards-index-desktop.png`
- `phase-5/award-detail-phone.png`
- `phase-5/award-detail-desktop.png`
- `phase-5/award-coming-soon-phone.png`
- `phase-5/vote-hub-phone.png`
- `phase-5/vote-hub-desktop.png`
- `phase-5/vote-edition-phone.png`
- `phase-5/vote-edition-phone--further-down.png`
- `phase-5/vote-edition-tablet.png`
- `phase-5/vote-edition-desktop.png`
- `phase-5/nominee-phone.png`
- `phase-5/nominee-phone--further-down.png`
- `phase-5/nominee-won-phone.png`
- `phase-5/nominee-desktop.png`
- `phase-5/results-phone.png`
- `phase-5/results-phone--further-down.png`
- `phase-5/results-desktop.png`

## Phase 6
- `phase-6/leaderboard-phone.png`
- `phase-6/leaderboard-desktop.png`
- `phase-6/leaderboard-empty-desktop.png`
- `phase-6/legacy-vault-phone.png`
- `phase-6/legacy-vault-phone--further-down.png`
- `phase-6/legacy-vault-desktop.png`
- `phase-6/legacy-edition-phone.png`
- `phase-6/legacy-edition-desktop.png`
- `phase-6/profile-phone.png`
- `phase-6/profile-desktop.png`

## Phase 7
- `phase-7/events-index-phone.png`
- `phase-7/event-detail-phone.png`
- `phase-7/event-detail-phone--further-down.png`
- `phase-7/event-detail-desktop.png`
- `phase-7/event-waitlist-desktop.png`
- `phase-7/ticket-phone.png`
- `phase-7/shop-index-phone.png`
- `phase-7/shop-tablet.png`
- `phase-7/shop-index-desktop.png`
- `phase-7/shop-item-phone.png`
- `phase-7/shop-item-phone--further-down.png`
- `phase-7/shop-item-desktop.png`
- `phase-7/giving-phone.png`
- `phase-7/giving-desktop.png`

## Phase 8
- `phase-8/pulse-phone.png`
- `phase-8/pulse-desktop.png`
- `phase-8/nominate-hub-phone.png`
- `phase-8/nomination-flow-phone.png`
- `phase-8/sign-in-phone.png`
- `phase-8/sign-in-desktop.png`

## Phase 9
- `phase-9/integrity-phone.png`
- `phase-9/integrity-phone--further-down.png`
- `phase-9/integrity-desktop.png`
- `phase-9/terms-desktop.png`
- `phase-9/cookie-policy-phone.png`
- `phase-9/help-centre-phone.png`
- `phase-9/help-centre-phone--further-down.png`
- `phase-9/help-centre-desktop.png`
- `phase-9/help-article-phone.png`
- `phase-9/help-article-desktop.png`
- `phase-9/blog-phone.png`
- `phase-9/blog-desktop.png`
- `phase-9/status-phone.png`
- `phase-9/status-desktop.png`

Phases 0, 1 and 10 have no screenshots: they produce no new screens (Phase 1 builds `/_dev/ui`).
