# Dynamic favicon: wiring (strict)

1. Copy `favicon.svg` to `public/favicon.svg` and `favicon.js` to `public/assets/js/favicon.js`.
2. In `layout/gates.twig` `<head>`, replace the existing icon links with:
   ```html
   <link rel="icon" id="agFavicon" type="image/svg+xml" href="{{ asset('/favicon.svg') }}">
   <link rel="alternate icon" href="{{ asset('/favicon.ico') }}">
   <link rel="apple-touch-icon" href="{{ asset('/apple-touch-icon.png') }}">
   ```
   Keep `favicon.ico` (32px) and `apple-touch-icon.png` (180px, brand-green disc, no transparency) for old browsers and iOS. They are static.
3. Load `favicon.js` with `defer` and the CSP nonce, after `gee.js`.
4. Call sites (no other code may touch the favicon):
   - Vote, checkout, nomination submit: `agFavicon.set('busy')` before the request; `set('idle')` on success; `set('error')` on failure (cleared on the next successful action or after 30s).
   - Live vote page (voting open), livestream page while the stream is on: render `<body data-favicon="live">`.
   - Notifications poll and Gee: `agFavicon.unread(n)`, where n is the unread count; 0 clears it.
5. Rules:
   - The idle state is the SVG itself: it follows the OS light/dark setting with no JS.
   - No animation while the tab is hidden; reduced motion gives static badges.
   - Never flash or blink faster than 2Hz. The live pulse is about 0.6Hz.
   - The title prefix "(n) " is only added when the tab is hidden and the count went UP, and it's removed on return.
